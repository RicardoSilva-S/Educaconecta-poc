# Roteiro do vídeo — 2ª entrega (meta: 4 min 15 s; limite 3 a 5 min)

**Antes de gravar:** suba o MongoDB (`docker compose up -d`), rode `npm run seed` e `npm start`. Deixe abertos o VS Code com `requests.http`, o terminal e o MongoDB Compass (ou `mongosh`) na base `educaconecta`. Teste o roteiro uma vez sem gravar.

| Tempo | Bloco (critério) | Na tela | Fala sugerida |
|---|---|---|---|
| 0:00–0:20 | **Abertura** | README no GitHub | "Somos a equipe do EducaConecta. Esta é a 2ª entrega da nossa PoC para ONGs de reforço escolar gratuito, alinhada ao ODS 4, Educação de Qualidade." |
| 0:20–0:55 | **Evolução da solução** | Tabela "Evolução" do README + aba de tags/commits do GitHub | "Na 1ª entrega tínhamos uma única coleção, de alunos, com CRUD básico. Agora são quatro coleções relacionadas: alunos, voluntários, turmas e matrículas. Também temos documentos aninhados, listas de subdocumentos e as regras que resolvem o problema original da ONG: saber quantas vagas restam em cada turma. As versões estão marcadas com as tags v1.0.0 e v2.0.0." |
| 0:55–1:40 | **Projeto final / arquitetura** | `docs/ARQUITETURA.md` (diagrama de classes) e pasta `src/` | "A arquitetura é em camadas: rotas, controllers, services com as regras de negócio, repositórios e MongoDB. Para não duplicar código ao passar de uma para quatro coleções, criamos classes base: Entidade, BaseRepository, CrudService e BaseController. Usamos herança, polimorfismo nos erros (cada erro sabe seu status HTTP) e injeção de dependência pelo construtor." |
| 1:40–2:15 | **Banco NoSQL** | `docs/BANCO_DE_DADOS.md` + Compass mostrando um aluno e uma matrícula | "Aqui está um aluno com endereço aninhado e uma lista de responsáveis. A matrícula referencia o aluno e a turma por ObjectId e guarda a lista de frequências. Embutimos o que pertence só ao documento e referenciamos o que é compartilhado. Também temos índices, incluindo um índice único parcial que impede matrícula ativa duplicada, e validação $jsonSchema." |
| 2:15–3:15 | **Demonstração da PoC** | `requests.http` (VS Code) | Execute nesta ordem e narre: (1) `GET /turmas/vagas`: "a turma de Matemática está lotada"; (2) `POST /matriculas` de outro aluno nessa turma → **409 sem vagas**; (3) cadastrar um aluno com endereço e responsáveis → 201; (4) matricular esse aluno em "Leitura e Escrita" → 201; (5) `POST /frequencias` → percentual calculado; (6) `GET /turmas/:id/alunos`: "a agregação com $lookup traz os alunos e o resumo de presença"; (7) `DELETE /alunos/:id` com matrícula ativa → **409**, a integridade entre coleções. |
| 3:15–3:50 | **Testes e cobertura** | Terminal: `npm test` (tabela de cobertura) | "Temos 160 testes automatizados: unitários de cada camada, um teste de fluxo completo que passa por todas as camadas e testes de integração com MongoDB real. A cobertura é de 99,8% das linhas, e o comando falha automaticamente se ficar abaixo de 70%." |
| 3:50–4:15 | **Resultados e encerramento** | Quadro de tarefas (GitHub Projects) + README | "Trabalhamos com Kanban em duas iterações, uma por entrega, e este é o quadro de tarefas. Como resultado, a ONG agora consegue controlar vagas por turno, matrículas e frequência num só lugar, com dados consistentes. Obrigado!" |

**Dicas**
- Grave com o OBS ou com a gravação de tela do Windows (Win+Alt+R) e aumente a fonte do VS Code e do terminal (Ctrl + `+`).
- Para a demonstração, pegue os ids em `GET /alunos` e `GET /turmas` e cole nas variáveis do topo do `requests.http` **antes** de gravar.
- Se passar de 5 minutos, encurte a parte da arquitetura; demonstração e testes valem mais.
