# Entrega 2 — EducaConecta (guia para fechar a nota)

Conteúdo deste pacote:

| Item | O que é |
|---|---|
| `educaconecta/` | Projeto completo da v2.0.0: código, testes, documentação e scripts |
| `publicar-entrega2.js` | Aplica a v2 no seu repositório com histórico de commits incremental e cria as tags `v1.0.0` e `v2.0.0` |
| `_v1/` | Código da 1ª entrega (tirado do zip), usado pelo script para o diff v1 → v2 ficar visível no GitHub |
| `ROTEIRO_VIDEO.md` | Roteiro do vídeo (3 a 5 min) com tempos, telas e falas |

---

## Passo a passo

### 1. Testar na sua máquina (5 min)
```bash
cd educaconecta
npm install
npm test                 # deve mostrar 160 testes passando e cobertura de ~99,8%
```
Para rodar a API: `docker compose up -d`, depois `copy .env.example .env` (Windows) ou `cp .env.example .env`, depois `npm run seed` e por fim `npm start`.
Sem Docker, use um MongoDB instalado ou um cluster grátis do MongoDB Atlas e coloque a URI no `.env`.

Opcional: `npm run test:integration` roda os testes contra um MongoDB real em memória (baixa o MongoDB na primeira vez, ~100 MB).

### 2. Publicar no GitHub com histórico (5 min)
```bash
git clone https://github.com/RicardoSilva-S/Educonecta.git
node publicar-entrega2.js ./Educonecta
cd Educonecta
git push origin main
git push origin v1.0.0 v2.0.0
```
O script cria 8 commits: extração da v1 do zip, depois domínio, banco, regras, API, testes, scripts e documentação. Ele também marca a tag `v1.0.0` no commit atual (a 1ª entrega) e `v2.0.0` no final. Ele **não** faz push sozinho.

Depois, no GitHub: **Releases → Draft a new release →** escolha a tag `v2.0.0`, título "Entrega 2 — versão final", e cole o resumo do `CHANGELOG.md`. Isso deixa a "versão final claramente identificável".

### 3. Criar o quadro de tarefas (10 min) — vale 0,1
1. No repositório: **Projects → New project → Board**, com o nome "EducaConecta — AEP".
2. Crie as colunas: Backlog, A fazer, Em andamento, Em revisão / testes, Concluído.
3. Cadastre as tarefas de `educaconecta/docs/quadro-de-tarefas.csv` (também listadas em `docs/METODOLOGIA.md`). Se preferir Trello, há Power-Ups de importação de CSV.
4. Atribua responsáveis entre os integrantes e deixe o projeto **público**.
5. Cole o link no `README.md` e no `docs/METODOLOGIA.md` (procure por "cole aqui").

### 4. Ajustar o README (2 min)
Procure por `_(integrante 2)_`, `_(integrante 3)_`, "cole aqui o link do quadro" e "cole aqui o link do vídeo" e preencha. Faça commit (`docs: links do quadro e do video`) e push. **Se o commit for feito depois da tag**, mova a tag para ele:
```bash
git tag -f -a v2.0.0 -m "Entrega 2 - versao final da PoC"
git push origin -f v2.0.0
```

### 5. Gravar o vídeo — vale 0,2
Siga o `ROTEIRO_VIDEO.md`. Ele cobre os 6 itens exigidos: evolução, projeto final, demonstração, tecnologias, testes/cobertura e resultados.

---

## Checklist contra os critérios da 2ª entrega

| Critério (0,1 cada; vídeo 0,2) | Onde está a evidência |
|---|---|
| PoC funcional e evolução | `npm run seed` + `npm start`; tabela "Evolução" no README; diff entre as tags `v1.0.0` e `v2.0.0` |
| Banco NoSQL (requisitos do 2º semestre) | 4 coleções, relacionamentos por referência, `endereco` aninhado, `responsaveis[]`, `horarios[]`, `frequencias[]`; `docs/BANCO_DE_DADOS.md` |
| POO e qualidade do código | Classes base, herança, polimorfismo, injeção de dependência e sem duplicação; `docs/ARQUITETURA.md` |
| Metodologia (quadro de tarefas) | GitHub Projects (passo 3) + `docs/METODOLOGIA.md` |
| Testes automatizados | 160 testes: unitários por camada, fluxo completo e integração |
| Cobertura ≥ 70% | `npm test` (falha se < 70%) → 99,8%; `docs/TESTES.md` |
| Documentação técnica | README (instalar, executar, testar, tecnologias, estrutura do banco) + `docs/` |
| GitHub e versionamento | Commits incrementais, tags `v1.0.0`/`v2.0.0` e Release |
| Vídeo (0,2) | `ROTEIRO_VIDEO.md` |

## O que mudou no código (para explicar se o professor perguntar)
- **Novas coleções:** `voluntarios` (com e-mail único), `turmas` (referencia o voluntário e tem lista de horários) e `matriculas` (liga aluno e turma e guarda a lista de frequências).
- **Aluno:** `responsavel` e `telefone` viraram a lista `responsaveis[]`, e entrou o `endereco` aninhado. Dados antigos continuam funcionando (`npm run migrar` converte).
- **Regras:** matrícula só com vaga, no mesmo turno, sem duplicar e com aluno e turma ativos. A capacidade não pode ficar menor que o número de matriculados. Não se remove aluno ou turma com matrícula ativa, nem voluntário que tenha turma.
- **Consultas:** relatório de vagas e alunos da turma usam `$lookup`, que é o "join" do MongoDB.
- Os testes da v1 foram reescritos para a nova estrutura. Todas as regras antigas de validação do aluno continuam testadas.
