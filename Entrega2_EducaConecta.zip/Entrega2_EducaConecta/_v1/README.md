# EducaConecta — PoC (AEP 2026.2 — 6S — Engenharia de Software)

## 1. Problema e contexto

ONGs que oferecem reforço escolar gratuito para crianças e adolescentes em
situação de vulnerabilidade social costumam controlar as inscrições em
planilhas soltas ou papel, o que gera cadastros duplicados, perda de dados de
contato dos responsáveis e dificuldade para saber quantas vagas por turno
ainda estão disponíveis.

O **EducaConecta** é uma PoC de sistema de cadastro de alunos para esse tipo
de programa: permite inscrever, consultar, atualizar e remover alunos, além
de filtrar apenas os que estão ativos no programa.

## 2. ODS atendido

**ODS 4 — Educação de Qualidade**, ao facilitar a gestão de vagas e o
acompanhamento de alunos em iniciativas de reforço escolar gratuito,
ajudando a ONG a manter mais crianças em atividades educacionais.

## 3. Tecnologias utilizadas

| Camada | Tecnologia |
|---|---|
| Linguagem / paradigma | JavaScript (Node.js), Programação Orientada a Objetos |
| Banco de dados NoSQL | MongoDB (driver oficial `mongodb`) |
| API HTTP | Express |
| Testes | Jest (unitários) + Supertest (rotas HTTP) |

## 4. Arquitetura (POO em camadas)

```
src/
  models/Aluno.js            -> entidade de domínio + validações (classe)
  repositories/AlunoRepository.js -> acesso à collection "alunos" no MongoDB
  services/AlunoService.js   -> regras de negócio, usa o repositório
  controllers/alunoController.js -> tradução HTTP <-> service
  routes/alunoRoutes.js      -> definição das rotas Express
  db/database.js             -> conexão real com o MongoDB
  app.js                     -> monta o Express recebendo o service (injeção de dependência)
  server.js                  -> ponto de entrada: conecta no Mongo e sobe o servidor
```

Cada camada depende apenas da interface da camada abaixo (injeção de
dependência via construtor), o que permite testar `Aluno`, `AlunoService`,
`AlunoRepository` e as rotas **sem precisar de um MongoDB real rodando**,
usando dublês (mocks) de repositório/collection/service. A conexão real com
o banco (`db/database.js`, `server.js`) fica isolada e é usada só em
produção/execução manual.

## 5. Modelo de dados (1ª etapa — coleção única, objetos homogêneos)

Coleção `alunos`:

```json
{
  "nome": "Maria Silva",
  "idade": 10,
  "escola": "EM Joao Paulo II",
  "serie": "5o ano",
  "turno": "tarde",
  "responsavel": "Ana Silva",
  "telefone": "44999998888",
  "ativo": true
}
```

## 6. Como rodar

Pré-requisitos: Node.js 18+ e um MongoDB acessível (local ou Atlas).

```bash
npm install
cp .env.example .env   # ajuste MONGODB_URI se necessário
npm start               # sobe a API em http://localhost:3000
```

### Endpoints

| Método | Rota | Descrição |
|---|---|---|
| POST | /alunos | Cadastra um aluno |
| GET | /alunos | Lista alunos (`?ativos=true` filtra só ativos) |
| GET | /alunos/:id | Busca um aluno pelo id |
| PUT | /alunos/:id | Atualiza campos de um aluno |
| DELETE | /alunos/:id | Remove um aluno |

Exemplo:

```bash
curl -X POST http://localhost:3000/alunos \
  -H "Content-Type: application/json" \
  -d '{"nome":"Maria Silva","idade":10,"escola":"EM Joao Paulo II","serie":"5o ano","turno":"tarde","responsavel":"Ana Silva","telefone":"44999998888"}'
```

## 7. Testes e cobertura (evidência reproduzível)

```bash
npm test
```

Isso roda o Jest com `--coverage`. O `package.json` já define
`coverageThreshold` de 70% em statements/branches/functions/lines — o
comando falha automaticamente se a cobertura cair abaixo disso.

Resultado obtido nesta entrega: **98,5% de cobertura** (53 testes, 4 suítes:
modelo, service, repositório e rotas).

## 8. Identificação — 6S

| | |
|---|---|
| Curso | Engenharia de Software |
| Série | 6º semestre |
| RA / Nome (integrante 1) | _preencher_ |
| RA / Nome (integrante 2) | _preencher_ |
| RA / Nome (integrante 3) | _preencher_ |
| Título do PoC | EducaConecta |
| Link do vídeo (YouTube) | _preencher_ |
| Link do GitHub | _preencher_ |

## 9. Próximos passos (2ª entrega)

- Evoluir para múltiplas coleções relacionadas (ex.: `turmas`, `presencas`)
  com pelo menos uma coleção contendo subdocumentos.
- Adicionar quadro de tarefas (Trello ou GitHub Projects) como evidência de
  metodologia de trabalho.
- Ampliar documentação técnica e vídeo final (3 a 5 minutos).
