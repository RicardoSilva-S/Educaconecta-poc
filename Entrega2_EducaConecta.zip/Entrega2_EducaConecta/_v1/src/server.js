require('dotenv').config();
const { conectar } = require('./db/database');
const AlunoRepository = require('./repositories/AlunoRepository');
const { AlunoService } = require('./services/AlunoService');
const criarApp = require('./app');

const PORT = process.env.PORT || 3000;

async function iniciar() {
  const db = await conectar();
  const collection = db.collection('alunos');

  const alunoRepository = new AlunoRepository(collection);
  const alunoService = new AlunoService(alunoRepository);
  const app = criarApp(alunoService);

  app.listen(PORT, () => {
    console.log(`EducaConecta rodando em http://localhost:${PORT}`);
  });
}

iniciar().catch((erro) => {
  console.error('Falha ao iniciar a aplicacao:', erro);
  process.exit(1);
});
