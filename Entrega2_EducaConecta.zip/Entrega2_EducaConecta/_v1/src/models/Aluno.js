class AlunoValidationError extends Error {
  constructor(message) {
    super(message);
    this.name = 'AlunoValidationError';
  }
}

const TURNOS_VALIDOS = ['manha', 'tarde', 'noite'];

/**
 * Representa um aluno inscrito no programa de reforco escolar gratuito.
 * Documento homogeneo e simples, conforme exigido na 1a etapa da PoC.
 */
class Aluno {
  constructor({ nome, idade, escola, serie, turno, responsavel, telefone, ativo = true }) {
    this.validar({ nome, idade, escola, serie, turno, responsavel, telefone });

    this.nome = nome.trim();
    this.idade = idade;
    this.escola = escola.trim();
    this.serie = serie.trim();
    this.turno = turno;
    this.responsavel = responsavel.trim();
    this.telefone = telefone.trim();
    this.ativo = ativo;
  }

  validar({ nome, idade, escola, serie, turno, responsavel, telefone }) {
    if (!nome || typeof nome !== 'string' || !nome.trim()) {
      throw new AlunoValidationError('Nome do aluno e obrigatorio.');
    }
    if (typeof idade !== 'number' || !Number.isInteger(idade) || idade < 4 || idade > 18) {
      throw new AlunoValidationError('Idade deve ser um numero inteiro entre 4 e 18 anos.');
    }
    if (!escola || typeof escola !== 'string' || !escola.trim()) {
      throw new AlunoValidationError('Escola de origem e obrigatoria.');
    }
    if (!serie || typeof serie !== 'string' || !serie.trim()) {
      throw new AlunoValidationError('Serie/ano escolar e obrigatorio.');
    }
    if (!TURNOS_VALIDOS.includes(turno)) {
      throw new AlunoValidationError(`Turno deve ser um dos seguintes: ${TURNOS_VALIDOS.join(', ')}.`);
    }
    if (!responsavel || typeof responsavel !== 'string' || !responsavel.trim()) {
      throw new AlunoValidationError('Nome do responsavel e obrigatorio.');
    }
    if (!telefone || typeof telefone !== 'string' || !/^\d{10,11}$/.test(telefone.replace(/\D/g, ''))) {
      throw new AlunoValidationError('Telefone deve conter 10 ou 11 digitos numericos.');
    }
  }

  inativar() {
    this.ativo = false;
  }

  ativar() {
    this.ativo = true;
  }

  toDocument() {
    return {
      nome: this.nome,
      idade: this.idade,
      escola: this.escola,
      serie: this.serie,
      turno: this.turno,
      responsavel: this.responsavel,
      telefone: this.telefone,
      ativo: this.ativo,
    };
  }

  static fromDocument(doc) {
    const aluno = new Aluno({
      nome: doc.nome,
      idade: doc.idade,
      escola: doc.escola,
      serie: doc.serie,
      turno: doc.turno,
      responsavel: doc.responsavel,
      telefone: doc.telefone,
      ativo: doc.ativo,
    });
    aluno._id = doc._id;
    return aluno;
  }
}

module.exports = { Aluno, AlunoValidationError, TURNOS_VALIDOS };
