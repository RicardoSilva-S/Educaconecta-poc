const express = require('express');

function criarAlunoRoutes(alunoController) {
  const router = express.Router();

  router.post('/', alunoController.criar);
  router.get('/', alunoController.listar);
  router.get('/:id', alunoController.buscar);
  router.put('/:id', alunoController.atualizar);
  router.delete('/:id', alunoController.remover);

  return router;
}

module.exports = criarAlunoRoutes;
