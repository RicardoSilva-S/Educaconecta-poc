const { Aluno } = require('../models/Aluno');

class AlunoNaoEncontradoError extends Error {
  constructor(id) {
    super(`Aluno com id ${id} nao foi encontrado.`);
    this.name = 'AlunoNaoEncontradoError';
  }
}

/**
 * Regras de negocio do cadastro de alunos.
 * Depende apenas da interface do repositorio (injetado), o que permite
 * testar toda a logica sem tocar no MongoDB.
 */
class AlunoService {
  constructor(alunoRepository) {
    this.alunoRepository = alunoRepository;
  }

  async cadastrarAluno(dadosAluno) {
    const aluno = new Aluno(dadosAluno);
    return this.alunoRepository.criar(aluno);
  }

  async listarAlunos(filtros) {
    return this.alunoRepository.listarTodos(filtros);
  }

  async buscarAluno(id) {
    const aluno = await this.alunoRepository.buscarPorId(id);
    if (!aluno) {
      throw new AlunoNaoEncontradoError(id);
    }
    return aluno;
  }

  async atualizarAluno(id, dadosParciais) {
    const alunoExistente = await this.alunoRepository.buscarPorId(id);
    if (!alunoExistente) {
      throw new AlunoNaoEncontradoError(id);
    }

    const dadosCompletos = { ...alunoExistente.toDocument(), ...dadosParciais };
    const alunoValidado = new Aluno(dadosCompletos);

    const atualizado = await this.alunoRepository.atualizar(id, alunoValidado.toDocument());
    if (!atualizado) {
      throw new AlunoNaoEncontradoError(id);
    }
    return atualizado;
  }

  async inativarAluno(id) {
    return this.atualizarAluno(id, { ativo: false });
  }

  async removerAluno(id) {
    const removido = await this.alunoRepository.remover(id);
    if (!removido) {
      throw new AlunoNaoEncontradoError(id);
    }
    return true;
  }
}

module.exports = { AlunoService, AlunoNaoEncontradoError };
