const { MongoClient } = require('mongodb');

const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017';
const DB_NAME = process.env.DB_NAME || 'educaconecta';

let client;

async function conectar() {
  if (!client) {
    client = new MongoClient(MONGODB_URI);
    await client.connect();
  }
  return client.db(DB_NAME);
}

async function desconectar() {
  if (client) {
    await client.close();
    client = undefined;
  }
}

module.exports = { conectar, desconectar };
