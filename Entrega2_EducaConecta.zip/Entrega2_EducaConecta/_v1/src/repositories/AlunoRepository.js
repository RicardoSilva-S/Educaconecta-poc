const { ObjectId } = require('mongodb');
const { Aluno } = require('../models/Aluno');

/**
 * Encapsula todo o acesso a colecao "alunos" no MongoDB.
 * Recebe a collection via injecao de dependencia para permitir testes
 * unitarios sem depender de um banco real.
 */
class AlunoRepository {
  constructor(collection) {
    if (!collection) {
      throw new Error('AlunoRepository requer uma collection valida.');
    }
    this.collection = collection;
  }

  async criar(aluno) {
    const resultado = await this.collection.insertOne(aluno.toDocument());
    return { ...aluno.toDocument(), _id: resultado.insertedId };
  }

  async listarTodos({ apenasAtivos = false } = {}) {
    const filtro = apenasAtivos ? { ativo: true } : {};
    const documentos = await this.collection.find(filtro).toArray();
    return documentos.map(Aluno.fromDocument);
  }

  async buscarPorId(id) {
    if (!ObjectId.isValid(id)) return null;
    const documento = await this.collection.findOne({ _id: new ObjectId(id) });
    return documento ? Aluno.fromDocument(documento) : null;
  }

  async atualizar(id, dadosAtualizados) {
    if (!ObjectId.isValid(id)) return null;
    const resultado = await this.collection.findOneAndUpdate(
      { _id: new ObjectId(id) },
      { $set: dadosAtualizados },
      { returnDocument: 'after' }
    );
    const documento = resultado && resultado.value !== undefined ? resultado.value : resultado;
    return documento ? Aluno.fromDocument(documento) : null;
  }

  async remover(id) {
    if (!ObjectId.isValid(id)) return false;
    const resultado = await this.collection.deleteOne({ _id: new ObjectId(id) });
    return resultado.deletedCount === 1;
  }
}

module.exports = AlunoRepository;
