const express = require('express');
const criarAlunoRoutes = require('./routes/alunoRoutes');
const AlunoController = require('./controllers/alunoController');

/**
 * Monta o app Express recebendo o AlunoService ja pronto.
 * Isso permite testar as rotas com um service mockado (sem MongoDB real)
 * e usar o service real conectado ao banco em producao.
 */
function criarApp(alunoService) {
  const app = express();
  app.use(express.json());

  const alunoController = new AlunoController(alunoService);
  app.use('/alunos', criarAlunoRoutes(alunoController));

  app.get('/health', (req, res) => res.status(200).json({ status: 'ok' }));

  return app;
}

module.exports = criarApp;
