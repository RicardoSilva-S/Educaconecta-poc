const { AlunoValidationError } = require('../models/Aluno');
const { AlunoNaoEncontradoError } = require('../services/AlunoService');

class AlunoController {
  constructor(alunoService) {
    this.alunoService = alunoService;

    this.criar = this.criar.bind(this);
    this.listar = this.listar.bind(this);
    this.buscar = this.buscar.bind(this);
    this.atualizar = this.atualizar.bind(this);
    this.remover = this.remover.bind(this);
  }

  async criar(req, res) {
    try {
      const alunoCriado = await this.alunoService.cadastrarAluno(req.body);
      return res.status(201).json(alunoCriado);
    } catch (erro) {
      return this._tratarErro(erro, res);
    }
  }

  async listar(req, res) {
    try {
      const apenasAtivos = req.query.ativos === 'true';
      const alunos = await this.alunoService.listarAlunos({ apenasAtivos });
      return res.status(200).json(alunos);
    } catch (erro) {
      return this._tratarErro(erro, res);
    }
  }

  async buscar(req, res) {
    try {
      const aluno = await this.alunoService.buscarAluno(req.params.id);
      return res.status(200).json(aluno);
    } catch (erro) {
      return this._tratarErro(erro, res);
    }
  }

  async atualizar(req, res) {
    try {
      const alunoAtualizado = await this.alunoService.atualizarAluno(req.params.id, req.body);
      return res.status(200).json(alunoAtualizado);
    } catch (erro) {
      return this._tratarErro(erro, res);
    }
  }

  async remover(req, res) {
    try {
      await this.alunoService.removerAluno(req.params.id);
      return res.status(204).send();
    } catch (erro) {
      return this._tratarErro(erro, res);
    }
  }

  _tratarErro(erro, res) {
    if (erro instanceof AlunoValidationError) {
      return res.status(400).json({ erro: erro.message });
    }
    if (erro instanceof AlunoNaoEncontradoError) {
      return res.status(404).json({ erro: erro.message });
    }
    return res.status(500).json({ erro: 'Erro interno do servidor.' });
  }
}

module.exports = AlunoController;
