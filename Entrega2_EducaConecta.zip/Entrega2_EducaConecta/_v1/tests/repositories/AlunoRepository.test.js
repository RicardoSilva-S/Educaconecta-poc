const { ObjectId } = require('mongodb');
const AlunoRepository = require('../../src/repositories/AlunoRepository');
const { Aluno } = require('../../src/models/Aluno');

function dadosValidos(overrides = {}) {
  return {
    nome: 'Pedro Lima',
    idade: 9,
    escola: 'EM Sao Jose',
    serie: '4o ano',
    turno: 'tarde',
    responsavel: 'Fabio Lima',
    telefone: '44977776666',
    ...overrides,
  };
}

function criarCollectionMock() {
  return {
    insertOne: jest.fn(),
    find: jest.fn(),
    findOne: jest.fn(),
    findOneAndUpdate: jest.fn(),
    deleteOne: jest.fn(),
  };
}

describe('AlunoRepository', () => {
  let collectionMock;
  let repositorio;

  beforeEach(() => {
    collectionMock = criarCollectionMock();
    repositorio = new AlunoRepository(collectionMock);
  });

  test('lanca erro se instanciado sem collection', () => {
    expect(() => new AlunoRepository()).toThrow();
  });

  test('criar() insere o documento e retorna com o _id gerado', async () => {
    const id = new ObjectId();
    collectionMock.insertOne.mockResolvedValue({ insertedId: id });
    const aluno = new Aluno(dadosValidos());

    const resultado = await repositorio.criar(aluno);

    expect(collectionMock.insertOne).toHaveBeenCalledWith(aluno.toDocument());
    expect(resultado._id).toBe(id);
    expect(resultado.nome).toBe('Pedro Lima');
  });

  test('listarTodos() sem filtro busca todos os documentos', async () => {
    const doc = { ...dadosValidos(), _id: new ObjectId() };
    collectionMock.find.mockReturnValue({ toArray: () => Promise.resolve([doc]) });

    const resultado = await repositorio.listarTodos();

    expect(collectionMock.find).toHaveBeenCalledWith({});
    expect(resultado).toHaveLength(1);
    expect(resultado[0]).toBeInstanceOf(Aluno);
  });

  test('listarTodos() com apenasAtivos filtra por ativo=true', async () => {
    collectionMock.find.mockReturnValue({ toArray: () => Promise.resolve([]) });
    await repositorio.listarTodos({ apenasAtivos: true });
    expect(collectionMock.find).toHaveBeenCalledWith({ ativo: true });
  });

  test('buscarPorId() retorna null para id invalido', async () => {
    const resultado = await repositorio.buscarPorId('id-invalido');
    expect(resultado).toBeNull();
    expect(collectionMock.findOne).not.toHaveBeenCalled();
  });

  test('buscarPorId() retorna Aluno quando o documento existe', async () => {
    const id = new ObjectId();
    collectionMock.findOne.mockResolvedValue({ ...dadosValidos(), _id: id });

    const resultado = await repositorio.buscarPorId(id.toHexString());
    expect(resultado).toBeInstanceOf(Aluno);
  });

  test('buscarPorId() retorna null quando o documento nao existe', async () => {
    collectionMock.findOne.mockResolvedValue(null);
    const resultado = await repositorio.buscarPorId(new ObjectId().toHexString());
    expect(resultado).toBeNull();
  });

  test('atualizar() retorna null para id invalido', async () => {
    const resultado = await repositorio.atualizar('id-invalido', { idade: 10 });
    expect(resultado).toBeNull();
    expect(collectionMock.findOneAndUpdate).not.toHaveBeenCalled();
  });

  test('atualizar() retorna Aluno atualizado (driver retorna {value})', async () => {
    const id = new ObjectId();
    collectionMock.findOneAndUpdate.mockResolvedValue({ value: { ...dadosValidos(), idade: 10, _id: id } });

    const resultado = await repositorio.atualizar(id.toHexString(), { idade: 10 });
    expect(resultado).toBeInstanceOf(Aluno);
    expect(resultado.idade).toBe(10);
  });

  test('atualizar() retorna null quando documento nao encontrado', async () => {
    collectionMock.findOneAndUpdate.mockResolvedValue({ value: null });
    const resultado = await repositorio.atualizar(new ObjectId().toHexString(), { idade: 10 });
    expect(resultado).toBeNull();
  });

  test('remover() retorna false para id invalido', async () => {
    const resultado = await repositorio.remover('id-invalido');
    expect(resultado).toBe(false);
    expect(collectionMock.deleteOne).not.toHaveBeenCalled();
  });

  test('remover() retorna true quando um documento e removido', async () => {
    collectionMock.deleteOne.mockResolvedValue({ deletedCount: 1 });
    const resultado = await repositorio.remover(new ObjectId().toHexString());
    expect(resultado).toBe(true);
  });

  test('remover() retorna false quando nada e removido', async () => {
    collectionMock.deleteOne.mockResolvedValue({ deletedCount: 0 });
    const resultado = await repositorio.remover(new ObjectId().toHexString());
    expect(resultado).toBe(false);
  });
});
