const request = require('supertest');
const criarApp = require('../../src/app');
const { AlunoValidationError } = require('../../src/models/Aluno');
const { AlunoNaoEncontradoError } = require('../../src/services/AlunoService');

function dadosValidos(overrides = {}) {
  return {
    nome: 'Lucas Rocha',
    idade: 11,
    escola: 'EM Nova Esperanca',
    serie: '6o ano',
    turno: 'noite',
    responsavel: 'Sonia Rocha',
    telefone: '44966665555',
    ...overrides,
  };
}

function criarServiceMock() {
  return {
    cadastrarAluno: jest.fn(),
    listarAlunos: jest.fn(),
    buscarAluno: jest.fn(),
    atualizarAluno: jest.fn(),
    removerAluno: jest.fn(),
  };
}

describe('Rotas de /alunos', () => {
  let serviceMock;
  let app;

  beforeEach(() => {
    serviceMock = criarServiceMock();
    app = criarApp(serviceMock);
  });

  test('GET /health responde 200', async () => {
    const resposta = await request(app).get('/health');
    expect(resposta.status).toBe(200);
    expect(resposta.body).toEqual({ status: 'ok' });
  });

  test('POST /alunos cria um aluno e retorna 201', async () => {
    serviceMock.cadastrarAluno.mockResolvedValue({ _id: '1', ...dadosValidos() });

    const resposta = await request(app).post('/alunos').send(dadosValidos());

    expect(resposta.status).toBe(201);
    expect(resposta.body.nome).toBe('Lucas Rocha');
  });

  test('POST /alunos retorna 400 em caso de erro de validacao', async () => {
    serviceMock.cadastrarAluno.mockRejectedValue(new AlunoValidationError('Nome do aluno e obrigatorio.'));

    const resposta = await request(app).post('/alunos').send(dadosValidos({ nome: '' }));

    expect(resposta.status).toBe(400);
    expect(resposta.body.erro).toMatch(/Nome/);
  });

  test('POST /alunos retorna 500 para erro inesperado', async () => {
    serviceMock.cadastrarAluno.mockRejectedValue(new Error('falha inesperada'));

    const resposta = await request(app).post('/alunos').send(dadosValidos());
    expect(resposta.status).toBe(500);
  });

  test('GET /alunos lista todos os alunos', async () => {
    serviceMock.listarAlunos.mockResolvedValue([dadosValidos()]);

    const resposta = await request(app).get('/alunos');

    expect(resposta.status).toBe(200);
    expect(serviceMock.listarAlunos).toHaveBeenCalledWith({ apenasAtivos: false });
    expect(resposta.body).toHaveLength(1);
  });

  test('GET /alunos?ativos=true repassa o filtro', async () => {
    serviceMock.listarAlunos.mockResolvedValue([]);
    await request(app).get('/alunos?ativos=true');
    expect(serviceMock.listarAlunos).toHaveBeenCalledWith({ apenasAtivos: true });
  });

  test('GET /alunos/:id retorna o aluno quando encontrado', async () => {
    serviceMock.buscarAluno.mockResolvedValue({ _id: '1', ...dadosValidos() });

    const resposta = await request(app).get('/alunos/1');
    expect(resposta.status).toBe(200);
  });

  test('GET /alunos/:id retorna 404 quando nao encontrado', async () => {
    serviceMock.buscarAluno.mockRejectedValue(new AlunoNaoEncontradoError('id-x'));

    const resposta = await request(app).get('/alunos/id-x');
    expect(resposta.status).toBe(404);
  });

  test('PUT /alunos/:id atualiza e retorna o aluno', async () => {
    serviceMock.atualizarAluno.mockResolvedValue({ _id: '1', ...dadosValidos({ idade: 12 }) });

    const resposta = await request(app).put('/alunos/1').send({ idade: 12 });
    expect(resposta.status).toBe(200);
    expect(resposta.body.idade).toBe(12);
  });

  test('DELETE /alunos/:id remove e retorna 204', async () => {
    serviceMock.removerAluno.mockResolvedValue(true);

    const resposta = await request(app).delete('/alunos/1');
    expect(resposta.status).toBe(204);
  });

  test('DELETE /alunos/:id retorna 404 quando nao encontrado', async () => {
    serviceMock.removerAluno.mockRejectedValue(new AlunoNaoEncontradoError('id-x'));

    const resposta = await request(app).delete('/alunos/id-x');
    expect(resposta.status).toBe(404);
  });
});
