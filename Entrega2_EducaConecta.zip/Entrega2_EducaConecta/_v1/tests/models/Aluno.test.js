const { Aluno, AlunoValidationError } = require('../../src/models/Aluno');

function dadosValidos(overrides = {}) {
  return {
    nome: 'Maria Silva',
    idade: 10,
    escola: 'EM Joao Paulo II',
    serie: '5o ano',
    turno: 'tarde',
    responsavel: 'Ana Silva',
    telefone: '44999998888',
    ...overrides,
  };
}

describe('Aluno', () => {
  test('cria um aluno valido com ativo=true por padrao', () => {
    const aluno = new Aluno(dadosValidos());
    expect(aluno.nome).toBe('Maria Silva');
    expect(aluno.ativo).toBe(true);
  });

  test('remove espacos extras de campos texto', () => {
    const aluno = new Aluno(dadosValidos({ nome: '  Maria Silva  ' }));
    expect(aluno.nome).toBe('Maria Silva');
  });

  test('rejeita nome vazio', () => {
    expect(() => new Aluno(dadosValidos({ nome: '' }))).toThrow(AlunoValidationError);
  });

  test('rejeita nome ausente', () => {
    const dados = dadosValidos();
    delete dados.nome;
    expect(() => new Aluno(dados)).toThrow(AlunoValidationError);
  });

  test('rejeita idade fora da faixa permitida (menor)', () => {
    expect(() => new Aluno(dadosValidos({ idade: 3 }))).toThrow(AlunoValidationError);
  });

  test('rejeita idade fora da faixa permitida (maior)', () => {
    expect(() => new Aluno(dadosValidos({ idade: 19 }))).toThrow(AlunoValidationError);
  });

  test('rejeita idade nao inteira', () => {
    expect(() => new Aluno(dadosValidos({ idade: 10.5 }))).toThrow(AlunoValidationError);
  });

  test('rejeita idade que nao e numero', () => {
    expect(() => new Aluno(dadosValidos({ idade: '10' }))).toThrow(AlunoValidationError);
  });

  test('rejeita escola vazia', () => {
    expect(() => new Aluno(dadosValidos({ escola: '   ' }))).toThrow(AlunoValidationError);
  });

  test('rejeita serie vazia', () => {
    expect(() => new Aluno(dadosValidos({ serie: '' }))).toThrow(AlunoValidationError);
  });

  test('rejeita turno invalido', () => {
    expect(() => new Aluno(dadosValidos({ turno: 'madrugada' }))).toThrow(AlunoValidationError);
  });

  test('rejeita responsavel vazio', () => {
    expect(() => new Aluno(dadosValidos({ responsavel: '' }))).toThrow(AlunoValidationError);
  });

  test('rejeita telefone com poucos digitos', () => {
    expect(() => new Aluno(dadosValidos({ telefone: '123' }))).toThrow(AlunoValidationError);
  });

  test('aceita telefone formatado com simbolos', () => {
    const aluno = new Aluno(dadosValidos({ telefone: '(44) 99999-8888' }));
    expect(aluno.telefone).toBe('(44) 99999-8888');
  });

  test('ativar() e inativar() alteram o campo ativo', () => {
    const aluno = new Aluno(dadosValidos());
    aluno.inativar();
    expect(aluno.ativo).toBe(false);
    aluno.ativar();
    expect(aluno.ativo).toBe(true);
  });

  test('toDocument() retorna objeto plano sem metodos', () => {
    const aluno = new Aluno(dadosValidos());
    const doc = aluno.toDocument();
    expect(doc).toEqual({
      nome: 'Maria Silva',
      idade: 10,
      escola: 'EM Joao Paulo II',
      serie: '5o ano',
      turno: 'tarde',
      responsavel: 'Ana Silva',
      telefone: '44999998888',
      ativo: true,
    });
  });

  test('fromDocument() reconstroi um Aluno preservando o _id', () => {
    const doc = { ...dadosValidos(), _id: 'abc123' };
    const aluno = Aluno.fromDocument(doc);
    expect(aluno).toBeInstanceOf(Aluno);
    expect(aluno._id).toBe('abc123');
  });
});
