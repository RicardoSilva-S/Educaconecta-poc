const { AlunoService, AlunoNaoEncontradoError } = require('../../src/services/AlunoService');
const { Aluno, AlunoValidationError } = require('../../src/models/Aluno');

function dadosValidos(overrides = {}) {
  return {
    nome: 'Joao Souza',
    idade: 12,
    escola: 'EM Central',
    serie: '7o ano',
    turno: 'manha',
    responsavel: 'Carla Souza',
    telefone: '44988887777',
    ...overrides,
  };
}

function criarRepositorioMock() {
  return {
    criar: jest.fn(),
    listarTodos: jest.fn(),
    buscarPorId: jest.fn(),
    atualizar: jest.fn(),
    remover: jest.fn(),
  };
}

describe('AlunoService', () => {
  let repositorioMock;
  let service;

  beforeEach(() => {
    repositorioMock = criarRepositorioMock();
    service = new AlunoService(repositorioMock);
  });

  test('cadastrarAluno cria um Aluno valido e delega ao repositorio', async () => {
    repositorioMock.criar.mockResolvedValue({ _id: '1', ...dadosValidos() });

    const resultado = await service.cadastrarAluno(dadosValidos());

    expect(repositorioMock.criar).toHaveBeenCalledWith(expect.any(Aluno));
    expect(resultado._id).toBe('1');
  });

  test('cadastrarAluno propaga erro de validacao sem chamar o repositorio', async () => {
    await expect(service.cadastrarAluno(dadosValidos({ nome: '' }))).rejects.toThrow(AlunoValidationError);
    expect(repositorioMock.criar).not.toHaveBeenCalled();
  });

  test('listarAlunos delega filtros ao repositorio', async () => {
    repositorioMock.listarTodos.mockResolvedValue([]);
    await service.listarAlunos({ apenasAtivos: true });
    expect(repositorioMock.listarTodos).toHaveBeenCalledWith({ apenasAtivos: true });
  });

  test('buscarAluno retorna o aluno quando encontrado', async () => {
    const alunoFake = new Aluno(dadosValidos());
    repositorioMock.buscarPorId.mockResolvedValue(alunoFake);

    const resultado = await service.buscarAluno('id-existente');
    expect(resultado).toBe(alunoFake);
  });

  test('buscarAluno lanca AlunoNaoEncontradoError quando nao existe', async () => {
    repositorioMock.buscarPorId.mockResolvedValue(null);
    await expect(service.buscarAluno('id-inexistente')).rejects.toThrow(AlunoNaoEncontradoError);
  });

  test('atualizarAluno mescla dados existentes com os novos e valida', async () => {
    const alunoExistente = new Aluno(dadosValidos());
    repositorioMock.buscarPorId.mockResolvedValue(alunoExistente);
    repositorioMock.atualizar.mockResolvedValue({ ...dadosValidos(), idade: 13, _id: '1' });

    const resultado = await service.atualizarAluno('1', { idade: 13 });

    expect(repositorioMock.atualizar).toHaveBeenCalledWith('1', expect.objectContaining({ idade: 13 }));
    expect(resultado.idade).toBe(13);
  });

  test('atualizarAluno lanca erro quando aluno nao existe', async () => {
    repositorioMock.buscarPorId.mockResolvedValue(null);
    await expect(service.atualizarAluno('id-inexistente', { idade: 13 })).rejects.toThrow(AlunoNaoEncontradoError);
  });

  test('atualizarAluno lanca erro se o update no repositorio nao encontrar o documento', async () => {
    const alunoExistente = new Aluno(dadosValidos());
    repositorioMock.buscarPorId.mockResolvedValue(alunoExistente);
    repositorioMock.atualizar.mockResolvedValue(null);

    await expect(service.atualizarAluno('1', { idade: 13 })).rejects.toThrow(AlunoNaoEncontradoError);
  });

  test('atualizarAluno propaga erro de validacao para dados invalidos', async () => {
    const alunoExistente = new Aluno(dadosValidos());
    repositorioMock.buscarPorId.mockResolvedValue(alunoExistente);

    await expect(service.atualizarAluno('1', { idade: 99 })).rejects.toThrow(AlunoValidationError);
  });

  test('inativarAluno chama atualizarAluno com ativo=false', async () => {
    const alunoExistente = new Aluno(dadosValidos());
    repositorioMock.buscarPorId.mockResolvedValue(alunoExistente);
    repositorioMock.atualizar.mockResolvedValue({ ...dadosValidos(), ativo: false, _id: '1' });

    const resultado = await service.inativarAluno('1');
    expect(resultado.ativo).toBe(false);
  });

  test('removerAluno retorna true quando remocao ocorre', async () => {
    repositorioMock.remover.mockResolvedValue(true);
    await expect(service.removerAluno('1')).resolves.toBe(true);
  });

  test('removerAluno lanca erro quando nada foi removido', async () => {
    repositorioMock.remover.mockResolvedValue(false);
    await expect(service.removerAluno('id-inexistente')).rejects.toThrow(AlunoNaoEncontradoError);
  });
});
