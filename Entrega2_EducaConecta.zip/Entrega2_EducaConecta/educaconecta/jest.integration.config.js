/**
 * Testes de integracao com um MongoDB REAL em memoria (mongodb-memory-server).
 * Na primeira execucao o pacote baixa o binario do MongoDB (precisa de internet).
 *
 *   npm run test:integration
 */
module.exports = {
  testEnvironment: 'node',
  testMatch: ['<rootDir>/tests/integration/**/*.test.js'],
  testTimeout: 60000,
};
