const { ObjectId } = require('mongodb');
const BaseRepository = require('../../src/repositories/BaseRepository');
const AlunoRepository = require('../../src/repositories/AlunoRepository');
const VoluntarioRepository = require('../../src/repositories/VoluntarioRepository');
const TurmaRepository = require('../../src/repositories/TurmaRepository');
const MatriculaRepository = require('../../src/repositories/MatriculaRepository');
const { Aluno } = require('../../src/models/Aluno');
const { Turma } = require('../../src/models/Turma');
const { Matricula } = require('../../src/models/Matricula');
const { dadosAluno, dadosVoluntario, dadosTurma } = require('../helpers/fabricas');

/** Duble da collection do driver: cada metodo e um jest.fn(). */
function criarCollectionMock() {
  const resultado = (valor) => ({ toArray: () => Promise.resolve(valor) });
  return {
    insertOne: jest.fn(),
    find: jest.fn(() => resultado([])),
    findOne: jest.fn(),
    findOneAndUpdate: jest.fn(),
    deleteOne: jest.fn(),
    deleteMany: jest.fn(),
    countDocuments: jest.fn(),
    aggregate: jest.fn(() => resultado([])),
    resultado,
  };
}

describe('BaseRepository (via AlunoRepository)', () => {
  let collection;
  let repo;

  beforeEach(() => {
    collection = criarCollectionMock();
    repo = new AlunoRepository(collection);
  });

  test('lanca erro sem collection', () => {
    expect(() => new AlunoRepository()).toThrow('AlunoRepository requer uma collection valida.');
  });

  test('paraObjectId aceita ObjectId e string de 24 hex; rejeita o resto', () => {
    const id = new ObjectId();
    expect(BaseRepository.paraObjectId(id)).toBe(id);
    expect(BaseRepository.paraObjectId(id.toHexString())).toEqual(id);
    expect(BaseRepository.paraObjectId('123')).toBeNull();
    expect(BaseRepository.paraObjectId('aaaaaaaaaaaa')).toBeNull();
    expect(BaseRepository.paraObjectId(undefined)).toBeNull();
  });

  test('criar insere o documento e devolve a entidade com _id em string', async () => {
    const id = new ObjectId();
    collection.insertOne.mockResolvedValue({ insertedId: id });
    const aluno = new Aluno(dadosAluno());

    const criado = await repo.criar(aluno);

    expect(collection.insertOne).toHaveBeenCalledWith(aluno.toDocument());
    expect(criado._id).toBe(id.toHexString());
  });

  test('listarTodos monta filtros de ativo e de cidade (campo aninhado)', async () => {
    const doc = { _id: new ObjectId(), ...new Aluno(dadosAluno()).toDocument() };
    collection.find.mockReturnValue(collection.resultado([doc]));

    const lista = await repo.listarTodos({ apenasAtivos: true, cidade: 'Maringa' });

    expect(collection.find).toHaveBeenCalledWith({ ativo: true, 'endereco.cidade': 'Maringa' });
    expect(lista[0]).toBeInstanceOf(Aluno);
    expect(lista[0]._id).toBe(doc._id.toHexString());
  });

  test('listarTodos sem filtros busca tudo', async () => {
    await repo.listarTodos();
    expect(collection.find).toHaveBeenCalledWith({});
  });

  test('buscarPorId retorna entidade, null se nao existir e null se id invalido', async () => {
    const id = new ObjectId();
    collection.findOne.mockResolvedValueOnce({ _id: id, ...new Aluno(dadosAluno()).toDocument() });
    expect((await repo.buscarPorId(id.toHexString())).nome).toBe('Maria Silva');
    expect(collection.findOne).toHaveBeenCalledWith({ _id: id });

    collection.findOne.mockResolvedValueOnce(null);
    expect(await repo.buscarPorId(id.toHexString())).toBeNull();

    expect(await repo.buscarPorId('invalido')).toBeNull();
    expect(collection.findOne).toHaveBeenCalledTimes(2);
  });

  test('atualizar usa $set e aceita retorno do driver 6 (documento) e antigo ({ value })', async () => {
    const id = new ObjectId();
    const aluno = new Aluno(dadosAluno({ nome: 'Novo Nome' }));
    const doc = { _id: id, ...aluno.toDocument() };

    collection.findOneAndUpdate.mockResolvedValueOnce(doc);
    expect((await repo.atualizar(id.toHexString(), aluno)).nome).toBe('Novo Nome');
    expect(collection.findOneAndUpdate).toHaveBeenCalledWith(
      { _id: id },
      { $set: aluno.toDocument() },
      { returnDocument: 'after' }
    );

    collection.findOneAndUpdate.mockResolvedValueOnce({ value: doc });
    expect((await repo.atualizar(id.toHexString(), aluno)).nome).toBe('Novo Nome');

    collection.findOneAndUpdate.mockResolvedValueOnce({ value: null });
    expect(await repo.atualizar(id.toHexString(), aluno)).toBeNull();

    expect(await repo.atualizar('invalido', aluno)).toBeNull();
  });

  test('remover retorna true/false conforme deletedCount e false para id invalido', async () => {
    const id = new ObjectId().toHexString();
    collection.deleteOne.mockResolvedValueOnce({ deletedCount: 1 });
    expect(await repo.remover(id)).toBe(true);
    collection.deleteOne.mockResolvedValueOnce({ deletedCount: 0 });
    expect(await repo.remover(id)).toBe(false);
    expect(await repo.remover('x')).toBe(false);
  });

  test('contar e existe usam countDocuments', async () => {
    collection.countDocuments.mockResolvedValueOnce(3).mockResolvedValueOnce(0);
    expect(await repo.contar()).toBe(3);
    expect(await repo.existe({ ativo: true })).toBe(false);
    expect(collection.countDocuments).toHaveBeenLastCalledWith({ ativo: true });
  });
});

describe('VoluntarioRepository', () => {
  let collection;
  let repo;

  beforeEach(() => {
    collection = criarCollectionMock();
    repo = new VoluntarioRepository(collection);
  });

  test('buscarPorEmail procura em minusculas', async () => {
    collection.findOne.mockResolvedValueOnce({ _id: new ObjectId(), email: 'bruno@educaconecta.org', ...dadosVoluntario() });
    const v = await repo.buscarPorEmail('BRUNO@educaconecta.org');
    expect(collection.findOne).toHaveBeenCalledWith({ email: 'bruno@educaconecta.org' });
    expect(v.nome).toBe('Bruno Costa');

    collection.findOne.mockResolvedValueOnce(null);
    expect(await repo.buscarPorEmail('x@y.com')).toBeNull();
  });

  test('listarTodos filtra por disciplina dentro do array', async () => {
    await repo.listarTodos({ disciplina: 'Matematica' });
    expect(collection.find).toHaveBeenCalledWith({ disciplinas: 'matematica' });
    await repo.listarTodos();
    expect(collection.find).toHaveBeenLastCalledWith({});
  });
});

describe('TurmaRepository', () => {
  let collection;
  let repo;

  beforeEach(() => {
    collection = criarCollectionMock();
    repo = new TurmaRepository(collection);
  });

  test('grava voluntarioId como ObjectId e devolve como string', async () => {
    const turma = new Turma(dadosTurma());
    collection.insertOne.mockResolvedValue({ insertedId: new ObjectId() });
    await repo.criar(turma);

    const gravado = collection.insertOne.mock.calls[0][0];
    expect(gravado.voluntarioId).toBeInstanceOf(ObjectId);

    collection.findOne.mockResolvedValue({ _id: new ObjectId(), ...gravado });
    const lida = await repo.buscarPorId(new ObjectId().toHexString());
    expect(lida.voluntarioId).toBe('64b000000000000000000001');
  });

  test('referencia com formato invalido e mantida como veio', () => {
    expect(repo.paraBanco({ voluntarioId: 'abc' }).voluntarioId).toBe('abc');
  });

  test('listarTodos aplica filtros de turno e disciplina', async () => {
    await repo.listarTodos({ turno: 'tarde', disciplina: 'Matematica' });
    expect(collection.find).toHaveBeenCalledWith({ turno: 'tarde', disciplina: 'matematica' });
    await repo.listarTodos();
    expect(collection.find).toHaveBeenLastCalledWith({});
  });

  test('pipeline do relatorio de vagas usa $lookup em matriculas ativas', () => {
    const pipeline = repo.pipelineRelatorioVagas({ turno: 'manha' });
    expect(pipeline[0]).toEqual({ $match: { ativa: true, turno: 'manha' } });
    expect(pipeline[1].$lookup.from).toBe('matriculas');
    expect(repo.pipelineRelatorioVagas()[0]).toEqual({ $match: { ativa: true } });
  });

  test('relatorioVagas converte turmaId para string', async () => {
    const id = new ObjectId();
    collection.aggregate.mockReturnValue(collection.resultado([{ turmaId: id, nome: 'T', vagas: 1 }]));
    const linhas = await repo.relatorioVagas();
    expect(linhas).toEqual([{ turmaId: id.toHexString(), nome: 'T', vagas: 1 }]);
  });
});

describe('MatriculaRepository', () => {
  let collection;
  let repo;
  const alunoId = new ObjectId();
  const turmaId = new ObjectId();

  beforeEach(() => {
    collection = criarCollectionMock();
    repo = new MatriculaRepository(collection);
  });

  test('listarTodas converte referencias para ObjectId no filtro', async () => {
    await repo.listarTodas({ alunoId: alunoId.toHexString(), turmaId: turmaId.toHexString(), status: 'ativa' });
    expect(collection.find).toHaveBeenCalledWith({ alunoId, turmaId, status: 'ativa' });
    await repo.listarTodas();
    expect(collection.find).toHaveBeenLastCalledWith({});
  });

  test('consultas de existencia/contagem filtram matriculas ativas', async () => {
    collection.countDocuments.mockResolvedValue(1);
    const a = alunoId.toHexString();
    const t = turmaId.toHexString();

    expect(await repo.contarAtivasDaTurma(t)).toBe(1);
    expect(collection.countDocuments).toHaveBeenLastCalledWith({ turmaId, status: 'ativa' });
    expect(await repo.existeAtivaDoAluno(a)).toBe(true);
    expect(collection.countDocuments).toHaveBeenLastCalledWith({ alunoId, status: 'ativa' });
    expect(await repo.existeAtivaDaTurma(t)).toBe(true);
    expect(await repo.existeAtiva(a, t)).toBe(true);
    expect(collection.countDocuments).toHaveBeenLastCalledWith({ alunoId, turmaId, status: 'ativa' });
  });

  test('removerHistorico usa deleteMany', async () => {
    collection.deleteMany.mockResolvedValue({ deletedCount: 2 });
    expect(await repo.removerHistorico({ alunoId: alunoId.toHexString() })).toBe(2);
    expect(collection.deleteMany).toHaveBeenCalledWith({ alunoId });
  });

  test('le matricula do banco com ids em string', async () => {
    const doc = { _id: new ObjectId(), alunoId, turmaId, status: 'ativa', dataMatricula: new Date(), frequencias: [] };
    collection.findOne.mockResolvedValue(doc);
    const m = await repo.buscarPorId(doc._id.toHexString());
    expect(m).toBeInstanceOf(Matricula);
    expect(m.alunoId).toBe(alunoId.toHexString());
  });

  test('listarAlunosDaTurma usa $lookup em alunos e converte ids', async () => {
    const matriculaId = new ObjectId();
    collection.aggregate.mockReturnValue(
      collection.resultado([{ matriculaId, alunoId, nome: 'Maria', presencas: 1, aulasRegistradas: 2 }])
    );
    const linhas = await repo.listarAlunosDaTurma(turmaId.toHexString());

    const pipeline = collection.aggregate.mock.calls[0][0];
    expect(pipeline[0]).toEqual({ $match: { turmaId, status: 'ativa' } });
    expect(pipeline[1].$lookup).toEqual({ from: 'alunos', localField: 'alunoId', foreignField: '_id', as: 'aluno' });
    expect(linhas[0]).toEqual(
      expect.objectContaining({ matriculaId: matriculaId.toHexString(), alunoId: alunoId.toHexString() })
    );
  });
});
