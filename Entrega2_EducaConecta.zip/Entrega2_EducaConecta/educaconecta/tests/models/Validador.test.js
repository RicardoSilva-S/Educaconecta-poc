const Validador = require('../../src/validation/Validador');
const { ValidationError } = require('../../src/errors/DomainError');

describe('Validador', () => {
  test('textoObrigatorio remove espacos e rejeita vazio/nao-texto', () => {
    expect(Validador.textoObrigatorio('  Ana ', 'Nome')).toBe('Ana');
    expect(() => Validador.textoObrigatorio('   ', 'Nome')).toThrow('Nome e obrigatorio.');
    expect(() => Validador.textoObrigatorio(10, 'Nome')).toThrow(ValidationError);
  });

  test('inteiroEntre aceita limites e rejeita decimais e fora da faixa', () => {
    expect(Validador.inteiroEntre(4, 4, 18, 'Idade')).toBe(4);
    expect(Validador.inteiroEntre(18, 4, 18, 'Idade')).toBe(18);
    expect(() => Validador.inteiroEntre(3, 4, 18, 'Idade')).toThrow(ValidationError);
    expect(() => Validador.inteiroEntre(10.5, 4, 18, 'Idade')).toThrow(ValidationError);
    expect(() => Validador.inteiroEntre('10', 4, 18, 'Idade')).toThrow(ValidationError);
  });

  test('umDe aceita apenas opcoes da lista', () => {
    expect(Validador.umDe('a', ['a', 'b'], 'Campo')).toBe('a');
    expect(() => Validador.umDe('c', ['a', 'b'], 'Campo')).toThrow('Campo deve ser um dos seguintes: a, b.');
  });

  test('telefone normaliza para digitos e exige 10 ou 11', () => {
    expect(Validador.telefone('(44) 99999-8888')).toBe('44999998888');
    expect(Validador.telefone('4433334444')).toBe('4433334444');
    expect(() => Validador.telefone('123')).toThrow(ValidationError);
    expect(() => Validador.telefone(undefined)).toThrow(ValidationError);
  });

  test('email normaliza para minusculas e valida formato', () => {
    expect(Validador.email(' Ana@ONG.org ')).toBe('ana@ong.org');
    expect(() => Validador.email('sem-arroba')).toThrow('E-mail invalido.');
    expect(() => Validador.email('')).toThrow(ValidationError);
  });

  test('booleano exige true/false', () => {
    expect(Validador.booleano(false, 'Ativo')).toBe(false);
    expect(() => Validador.booleano('true', 'Ativo')).toThrow(ValidationError);
  });

  test('listaNaoVazia exige array com itens', () => {
    expect(Validador.listaNaoVazia([1], 'Lista')).toEqual([1]);
    expect(() => Validador.listaNaoVazia([], 'Lista')).toThrow(ValidationError);
    expect(() => Validador.listaNaoVazia(null, 'Lista')).toThrow(ValidationError);
  });

  test('horario exige HH:MM valido', () => {
    expect(Validador.horario('08:30', 'Inicio')).toBe('08:30');
    expect(() => Validador.horario('24:00', 'Inicio')).toThrow(ValidationError);
    expect(() => Validador.horario('8:30', 'Inicio')).toThrow(ValidationError);
  });

  test('data exige AAAA-MM-DD e data existente', () => {
    expect(Validador.data('2026-02-28', 'Data')).toBe('2026-02-28');
    expect(() => Validador.data('2026-02-30', 'Data')).toThrow('Data nao e uma data valida.');
    expect(() => Validador.data('28/02/2026', 'Data')).toThrow(ValidationError);
  });

  test('idObrigatorio converte para string e rejeita ausente', () => {
    expect(Validador.idObrigatorio(123, 'Id')).toBe('123');
    expect(() => Validador.idObrigatorio(null, 'Id')).toThrow(ValidationError);
    expect(() => Validador.idObrigatorio(' ', 'Id')).toThrow(ValidationError);
  });
});
