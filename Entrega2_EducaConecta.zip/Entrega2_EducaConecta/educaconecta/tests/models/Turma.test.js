const { Turma } = require('../../src/models/Turma');
const { ValidationError } = require('../../src/errors/DomainError');
const { dadosTurma } = require('../helpers/fabricas');

describe('Turma', () => {
  test('cria turma valida com lista de horarios', () => {
    const turma = new Turma(dadosTurma({ disciplina: 'Matematica' }));
    expect(turma.toDocument()).toEqual({
      nome: 'Matematica Basica',
      disciplina: 'matematica',
      turno: 'tarde',
      capacidade: 2,
      voluntarioId: '64b000000000000000000001',
      horarios: [{ diaSemana: 'seg', inicio: '14:00', fim: '15:30' }],
      ativa: true,
    });
  });

  test('vagasDisponiveis nunca fica negativo', () => {
    const turma = new Turma(dadosTurma({ capacidade: 2 }));
    expect(turma.vagasDisponiveis(0)).toBe(2);
    expect(turma.vagasDisponiveis(2)).toBe(0);
    expect(turma.vagasDisponiveis(5)).toBe(0);
  });

  test.each([
    ['capacidade zero', { capacidade: 0 }],
    ['capacidade acima do maximo', { capacidade: 41 }],
    ['sem voluntario', { voluntarioId: undefined }],
    ['sem horarios', { horarios: [] }],
    ['turno invalido', { turno: 'x' }],
    ['dia invalido', { horarios: [{ diaSemana: 'dom', inicio: '10:00', fim: '11:00' }] }],
    ['horario mal formatado', { horarios: [{ diaSemana: 'seg', inicio: '10h', fim: '11:00' }] }],
    ['horario vazio', { horarios: [undefined] }],
  ])('rejeita %s', (_, override) => {
    expect(() => new Turma(dadosTurma(override))).toThrow(ValidationError);
  });

  test('rejeita inicio depois do fim', () => {
    const horarios = [{ diaSemana: 'seg', inicio: '16:00', fim: '15:00' }];
    expect(() => new Turma(dadosTurma({ horarios }))).toThrow('Horario de inicio deve ser anterior ao horario de fim.');
  });

  test('rejeita dia da semana repetido', () => {
    const horarios = [
      { diaSemana: 'seg', inicio: '14:00', fim: '15:00' },
      { diaSemana: 'seg', inicio: '16:00', fim: '17:00' },
    ];
    expect(() => new Turma(dadosTurma({ horarios }))).toThrow('Dia da semana repetido nos horarios: seg.');
  });

  test('rejeita objeto vazio', () => {
    expect(() => new Turma()).toThrow(ValidationError);
  });
});
