const Voluntario = require('../../src/models/Voluntario');
const { ValidationError } = require('../../src/errors/DomainError');
const { dadosVoluntario } = require('../helpers/fabricas');

describe('Voluntario', () => {
  test('normaliza e-mail, telefone e disciplinas (minusculas, sem repeticao)', () => {
    const v = new Voluntario(
      dadosVoluntario({ email: 'Bruno@ONG.org', telefone: '(44) 99111-2222', disciplinas: ['Matematica', 'matematica', 'Artes'] })
    );
    expect(v.toDocument()).toEqual({
      nome: 'Bruno Costa',
      email: 'bruno@ong.org',
      telefone: '44991112222',
      disciplinas: ['matematica', 'artes'],
      ativo: true,
    });
  });

  test('podeLecionar ignora maiusculas e espacos', () => {
    const v = new Voluntario(dadosVoluntario());
    expect(v.podeLecionar(' MATEMATICA ')).toBe(true);
    expect(v.podeLecionar('historia')).toBe(false);
    expect(v.podeLecionar(undefined)).toBe(false);
  });

  test.each([
    ['sem disciplinas', { disciplinas: [] }],
    ['disciplina vazia', { disciplinas: [''] }],
    ['e-mail invalido', { email: 'x' }],
    ['telefone invalido', { telefone: '1' }],
    ['nome vazio', { nome: '' }],
  ])('rejeita %s', (_, override) => {
    expect(() => new Voluntario(dadosVoluntario(override))).toThrow(ValidationError);
  });

  test('rejeita objeto vazio', () => {
    expect(() => new Voluntario()).toThrow(ValidationError);
  });
});
