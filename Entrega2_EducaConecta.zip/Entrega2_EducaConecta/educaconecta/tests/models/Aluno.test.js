const { Aluno } = require('../../src/models/Aluno');
const { Endereco } = require('../../src/models/Endereco');
const { Responsavel } = require('../../src/models/Responsavel');
const Entidade = require('../../src/models/Entidade');
const { ValidationError } = require('../../src/errors/DomainError');
const { dadosAluno, dadosEndereco, dadosResponsavel } = require('../helpers/fabricas');

describe('Entidade (classe base abstrata)', () => {
  test('nao pode ser instanciada diretamente', () => {
    expect(() => new Entidade()).toThrow(TypeError);
  });
});

describe('Endereco (documento aninhado)', () => {
  test('normaliza estado e CEP', () => {
    const e = new Endereco(dadosEndereco({ estado: 'pr', cep: '87.000-000' }));
    expect(e.toDocument()).toEqual(expect.objectContaining({ estado: 'PR', cep: '87000000' }));
  });

  test('numero ausente vira "s/n"', () => {
    expect(new Endereco(dadosEndereco({ numero: undefined })).numero).toBe('s/n');
    expect(new Endereco(dadosEndereco({ numero: ' ' })).numero).toBe('s/n');
  });

  test('rejeita UF e CEP invalidos', () => {
    expect(() => new Endereco(dadosEndereco({ estado: 'XX' }))).toThrow(ValidationError);
    expect(() => new Endereco(dadosEndereco({ cep: '123' }))).toThrow('CEP deve conter 8 digitos.');
    expect(() => new Endereco(dadosEndereco({ cep: undefined }))).toThrow(ValidationError);
    expect(() => new Endereco()).toThrow(ValidationError);
  });
});

describe('Responsavel (subdocumento)', () => {
  test('aplica valores padrao', () => {
    const r = new Responsavel({ nome: 'Jose', telefone: '44999990000' });
    expect(r.toDocument()).toEqual({ nome: 'Jose', parentesco: 'outro', telefone: '44999990000', principal: false });
  });

  test('rejeita parentesco invalido', () => {
    expect(() => new Responsavel(dadosResponsavel({ parentesco: 'vizinho' }))).toThrow(ValidationError);
    expect(() => new Responsavel()).toThrow(ValidationError);
  });
});

describe('Aluno', () => {
  test('cria aluno valido com endereco aninhado e lista de responsaveis', () => {
    const aluno = new Aluno(dadosAluno());

    expect(aluno.ativo).toBe(true);
    expect(aluno.endereco).toBeInstanceOf(Endereco);
    expect(aluno.responsaveis[0]).toBeInstanceOf(Responsavel);
    expect(aluno.toDocument()).toEqual({
      nome: 'Maria Silva',
      idade: 10,
      escola: 'EM Joao Paulo II',
      serie: '5o ano',
      turno: 'tarde',
      endereco: { rua: 'Rua A', numero: '100', bairro: 'Centro', cidade: 'Maringa', estado: 'PR', cep: '87000000' },
      responsaveis: [{ nome: 'Ana Silva', parentesco: 'mae', telefone: '44999998888', principal: true }],
      ativo: true,
    });
  });

  test('endereco e opcional', () => {
    expect(new Aluno(dadosAluno({ endereco: undefined })).toDocument().endereco).toBeNull();
  });

  test.each([
    ['nome vazio', { nome: '' }],
    ['idade abaixo de 4', { idade: 3 }],
    ['idade acima de 18', { idade: 19 }],
    ['escola ausente', { escola: undefined }],
    ['serie ausente', { serie: '' }],
    ['turno invalido', { turno: 'madrugada' }],
    ['sem responsaveis', { responsaveis: [] }],
    ['ativo nao booleano', { ativo: 'sim' }],
  ])('rejeita %s', (_, override) => {
    expect(() => new Aluno(dadosAluno(override))).toThrow(ValidationError);
  });

  test('rejeita objeto vazio', () => {
    expect(() => new Aluno()).toThrow(ValidationError);
  });

  test('marca o primeiro responsavel como principal quando nenhum foi marcado', () => {
    const aluno = new Aluno(
      dadosAluno({
        responsaveis: [
          dadosResponsavel({ principal: false }),
          dadosResponsavel({ nome: 'Jose', principal: false }),
        ],
      })
    );
    expect(aluno.responsavelPrincipal.nome).toBe('Ana Silva');
  });

  test('rejeita mais de um responsavel principal', () => {
    const responsaveis = [dadosResponsavel(), dadosResponsavel({ nome: 'Jose' })];
    expect(() => new Aluno(dadosAluno({ responsaveis }))).toThrow('Apenas um responsavel pode ser marcado como principal.');
  });

  test('inativar e ativar alteram o status', () => {
    const aluno = new Aluno(dadosAluno());
    aluno.inativar();
    expect(aluno.ativo).toBe(false);
    aluno.ativar();
    expect(aluno.ativo).toBe(true);
  });

  test('fromDocument reconstroi o aluno com _id e toJSON inclui o _id', () => {
    const aluno = Aluno.fromDocument({ _id: 'abc', ...new Aluno(dadosAluno()).toDocument() });
    expect(aluno).toBeInstanceOf(Aluno);
    expect(aluno.toJSON()._id).toBe('abc');
  });

  test('fromDocument converte documento no formato da 1a entrega', () => {
    const legado = {
      _id: 'x1',
      nome: 'Pedro Lima',
      idade: 9,
      escola: 'EM Sao Jose',
      serie: '4o ano',
      turno: 'tarde',
      responsavel: 'Fabio Lima',
      telefone: '44977776666',
      ativo: true,
    };
    const aluno = Aluno.fromDocument(legado);
    expect(aluno.responsaveis).toHaveLength(1);
    expect(aluno.responsavelPrincipal.toDocument()).toEqual({
      nome: 'Fabio Lima',
      parentesco: 'outro',
      telefone: '44977776666',
      principal: true,
    });
    expect(aluno.endereco).toBeNull();
    expect(aluno.toDocument()).not.toHaveProperty('responsavel');
  });
});
