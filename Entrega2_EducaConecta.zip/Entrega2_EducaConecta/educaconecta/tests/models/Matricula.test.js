const { Matricula, STATUS } = require('../../src/models/Matricula');
const { ValidationError, BusinessRuleError } = require('../../src/errors/DomainError');

const nova = (overrides = {}) => new Matricula({ alunoId: 'a1', turmaId: 't1', ...overrides });

describe('Matricula', () => {
  test('nasce ativa, sem frequencias e com data de matricula', () => {
    const m = nova();
    expect(m.status).toBe(STATUS.ATIVA);
    expect(m.ativa).toBe(true);
    expect(m.frequencias).toEqual([]);
    expect(m.dataMatricula).toBeInstanceOf(Date);
    expect(m.percentualFrequencia()).toBeNull();
  });

  test('exige aluno e turma', () => {
    expect(() => new Matricula({ turmaId: 't1' })).toThrow(ValidationError);
    expect(() => new Matricula({ alunoId: 'a1' })).toThrow(ValidationError);
    expect(() => new Matricula()).toThrow(ValidationError);
  });

  test('rejeita status invalido', () => {
    expect(() => nova({ status: 'pausada' })).toThrow(ValidationError);
  });

  test('registra frequencias em ordem de data e calcula percentual', () => {
    const m = nova();
    m.registrarFrequencia({ data: '2026-11-04', presente: false });
    m.registrarFrequencia({ data: '2026-11-02', presente: true });
    m.registrarFrequencia({ data: '2026-11-06', presente: true });

    expect(m.frequencias.map((f) => f.data)).toEqual(['2026-11-02', '2026-11-04', '2026-11-06']);
    expect(m.percentualFrequencia()).toBe(66.7);
  });

  test('nao permite duas frequencias na mesma data', () => {
    const m = nova();
    m.registrarFrequencia({ data: '2026-11-02', presente: true });
    expect(() => m.registrarFrequencia({ data: '2026-11-02', presente: false })).toThrow(BusinessRuleError);
  });

  test('valida dados da frequencia', () => {
    const m = nova();
    expect(() => m.registrarFrequencia({ data: '02/11/2026', presente: true })).toThrow(ValidationError);
    expect(() => m.registrarFrequencia({ data: '2026-11-02' })).toThrow(ValidationError);
    expect(() => m.registrarFrequencia()).toThrow(ValidationError);
  });

  test('cancelar muda o status e registra a data', () => {
    const m = nova();
    m.cancelar(new Date('2026-11-10T12:00:00Z'));
    expect(m.status).toBe(STATUS.CANCELADA);
    expect(m.dataCancelamento.toISOString()).toBe('2026-11-10T12:00:00.000Z');
  });

  test('cancelar usa a data atual por padrao', () => {
    const m = nova();
    m.cancelar();
    expect(m.dataCancelamento).toBeInstanceOf(Date);
  });

  test('nao cancela duas vezes nem registra frequencia em matricula cancelada', () => {
    const m = nova();
    m.cancelar();
    expect(() => m.cancelar()).toThrow('A matricula ja esta cancelada.');
    expect(() => m.registrarFrequencia({ data: '2026-11-02', presente: true })).toThrow(BusinessRuleError);
  });

  test('fromDocument reconstroi datas e frequencias; toJSON inclui percentual', () => {
    const m = Matricula.fromDocument({
      _id: 'm1',
      alunoId: 'a1',
      turmaId: 't1',
      status: 'cancelada',
      dataMatricula: '2026-11-01T00:00:00.000Z',
      dataCancelamento: '2026-11-09T00:00:00.000Z',
      frequencias: [{ data: '2026-11-02', presente: true }],
    });
    expect(m.dataMatricula).toBeInstanceOf(Date);
    expect(m.dataCancelamento).toBeInstanceOf(Date);
    expect(m.toJSON()).toEqual(expect.objectContaining({ _id: 'm1', status: 'cancelada', percentualFrequencia: 100 }));
  });

  test('fromDocument aceita frequencias nulas', () => {
    const m = Matricula.fromDocument({ _id: 'm1', alunoId: 'a1', turmaId: 't1', frequencias: null });
    expect(m.frequencias).toEqual([]);
  });
});
