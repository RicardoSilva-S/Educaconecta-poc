const AlunoService = require('../../src/services/AlunoService');
const VoluntarioService = require('../../src/services/VoluntarioService');
const TurmaService = require('../../src/services/TurmaService');
const MatriculaService = require('../../src/services/MatriculaService');
const { Aluno } = require('../../src/models/Aluno');
const Voluntario = require('../../src/models/Voluntario');
const { Turma } = require('../../src/models/Turma');
const { Matricula } = require('../../src/models/Matricula');
const { ValidationError, NotFoundError, BusinessRuleError } = require('../../src/errors/DomainError');
const { dadosAluno, dadosVoluntario, dadosTurma } = require('../helpers/fabricas');

/** Duble de repositorio: todos os metodos usados pelos services. */
const criarRepoMock = () => ({
  criar: jest.fn(async (e) => e.comId('novo-id')),
  listarTodos: jest.fn(async () => []),
  listarTodas: jest.fn(async () => []),
  buscarPorId: jest.fn(async () => null),
  buscarPorEmail: jest.fn(async () => null),
  atualizar: jest.fn(async (id, e) => e.comId(id)),
  remover: jest.fn(async () => true),
  existe: jest.fn(async () => false),
  existeAtiva: jest.fn(async () => false),
  existeAtivaDoAluno: jest.fn(async () => false),
  existeAtivaDaTurma: jest.fn(async () => false),
  contarAtivasDaTurma: jest.fn(async () => 0),
  removerHistorico: jest.fn(async () => 0),
  relatorioVagas: jest.fn(async () => []),
  listarAlunosDaTurma: jest.fn(async () => []),
});

const aluno = (o) => new Aluno(dadosAluno(o)).comId('a1');
const voluntario = (o) => new Voluntario(dadosVoluntario(o)).comId('v1');
const turma = (o) => new Turma(dadosTurma({ voluntarioId: 'v1', ...o })).comId('t1');

describe('CrudService (via AlunoService)', () => {
  let alunos;
  let matriculas;
  let service;

  beforeEach(() => {
    alunos = criarRepoMock();
    matriculas = criarRepoMock();
    service = new AlunoService(alunos, matriculas);
  });

  test('cadastrar valida e delega ao repositorio', async () => {
    const criado = await service.cadastrar(dadosAluno());
    expect(alunos.criar).toHaveBeenCalledWith(expect.any(Aluno));
    expect(criado._id).toBe('novo-id');
  });

  test('cadastrar com dados invalidos nao chama o repositorio', async () => {
    await expect(service.cadastrar(dadosAluno({ idade: 30 }))).rejects.toThrow(ValidationError);
    expect(alunos.criar).not.toHaveBeenCalled();
  });

  test('listar repassa filtros', async () => {
    await service.listar({ apenasAtivos: true });
    expect(alunos.listarTodos).toHaveBeenCalledWith({ apenasAtivos: true });
    await service.listar();
    expect(alunos.listarTodos).toHaveBeenLastCalledWith({});
  });

  test('buscar lanca NotFoundError quando nao existe', async () => {
    await expect(service.buscar('x')).rejects.toThrow(NotFoundError);
    alunos.buscarPorId.mockResolvedValue(aluno());
    expect((await service.buscar('a1')).nome).toBe('Maria Silva');
  });

  test('atualizar mescla dados parciais, ignora _id do corpo e revalida', async () => {
    alunos.buscarPorId.mockResolvedValue(aluno());
    const atualizado = await service.atualizar('a1', { _id: 'hack', serie: '6o ano' });
    expect(atualizado.serie).toBe('6o ano');
    expect(atualizado.nome).toBe('Maria Silva');
    expect(alunos.atualizar).toHaveBeenCalledWith('a1', expect.any(Aluno));
    expect(atualizado._id).toBe('a1');
  });

  test('atualizar aceita corpo vazio/nulo', async () => {
    alunos.buscarPorId.mockResolvedValue(aluno());
    await expect(service.atualizar('a1', null)).resolves.toBeInstanceOf(Aluno);
  });

  test('atualizar com dados invalidos nao grava', async () => {
    alunos.buscarPorId.mockResolvedValue(aluno());
    await expect(service.atualizar('a1', { turno: 'x' })).rejects.toThrow(ValidationError);
    expect(alunos.atualizar).not.toHaveBeenCalled();
  });

  test('atualizar lanca NotFound se o registro sumir durante a gravacao', async () => {
    alunos.buscarPorId.mockResolvedValue(aluno());
    alunos.atualizar.mockResolvedValue(null);
    await expect(service.atualizar('a1', {})).rejects.toThrow(NotFoundError);
  });

  test('inativar grava ativo=false', async () => {
    alunos.buscarPorId.mockResolvedValue(aluno());
    expect((await service.inativar('a1')).ativo).toBe(false);
  });

  test('remover exclui o historico de matriculas e o aluno', async () => {
    alunos.buscarPorId.mockResolvedValue(aluno());
    await expect(service.remover('a1')).resolves.toBe(true);
    expect(matriculas.removerHistorico).toHaveBeenCalledWith({ alunoId: 'a1' });
    expect(alunos.remover).toHaveBeenCalledWith('a1');
  });

  test('remover bloqueia aluno com matricula ativa', async () => {
    alunos.buscarPorId.mockResolvedValue(aluno());
    matriculas.existeAtivaDoAluno.mockResolvedValue(true);
    await expect(service.remover('a1')).rejects.toThrow(BusinessRuleError);
    expect(alunos.remover).not.toHaveBeenCalled();
  });

  test('remover lanca NotFound se inexistente ou se a exclusao falhar', async () => {
    await expect(service.remover('x')).rejects.toThrow(NotFoundError);
    alunos.buscarPorId.mockResolvedValue(aluno());
    alunos.remover.mockResolvedValue(false);
    await expect(service.remover('a1')).rejects.toThrow(NotFoundError);
  });
});

describe('VoluntarioService', () => {
  let voluntarios;
  let turmas;
  let service;

  beforeEach(() => {
    voluntarios = criarRepoMock();
    turmas = criarRepoMock();
    service = new VoluntarioService(voluntarios, turmas);
  });

  test('cadastra voluntario com e-mail novo', async () => {
    await expect(service.cadastrar(dadosVoluntario())).resolves.toBeInstanceOf(Voluntario);
  });

  test('rejeita e-mail ja usado por outro voluntario', async () => {
    voluntarios.buscarPorEmail.mockResolvedValue(voluntario());
    await expect(service.cadastrar(dadosVoluntario())).rejects.toThrow(BusinessRuleError);
  });

  test('permite atualizar mantendo o proprio e-mail', async () => {
    voluntarios.buscarPorId.mockResolvedValue(voluntario());
    voluntarios.buscarPorEmail.mockResolvedValue(voluntario());
    await expect(service.atualizar('v1', { nome: 'Bruno C.' })).resolves.toEqual(expect.objectContaining({ nome: 'Bruno C.' }));
  });

  test('nao remove voluntario responsavel por turma', async () => {
    voluntarios.buscarPorId.mockResolvedValue(voluntario());
    turmas.existe.mockResolvedValue(true);
    await expect(service.remover('v1')).rejects.toThrow(BusinessRuleError);
    expect(turmas.existe).toHaveBeenCalledWith({ voluntarioId: 'v1' });
  });

  test('remove voluntario sem turmas', async () => {
    voluntarios.buscarPorId.mockResolvedValue(voluntario());
    await expect(service.remover('v1')).resolves.toBe(true);
  });
});

describe('TurmaService', () => {
  let turmas;
  let voluntarios;
  let matriculas;
  let service;

  beforeEach(() => {
    turmas = criarRepoMock();
    voluntarios = criarRepoMock();
    matriculas = criarRepoMock();
    service = new TurmaService(turmas, voluntarios, matriculas);
    voluntarios.buscarPorId.mockResolvedValue(voluntario());
  });

  test('cadastra turma com voluntario valido', async () => {
    await expect(service.cadastrar(dadosTurma({ voluntarioId: 'v1' }))).resolves.toBeInstanceOf(Turma);
  });

  test('rejeita voluntario inexistente, inativo ou que nao leciona a disciplina', async () => {
    voluntarios.buscarPorId.mockResolvedValueOnce(null);
    await expect(service.cadastrar(dadosTurma())).rejects.toThrow(NotFoundError);

    voluntarios.buscarPorId.mockResolvedValueOnce(voluntario({ ativo: false }));
    await expect(service.cadastrar(dadosTurma())).rejects.toThrow('O voluntario informado esta inativo.');

    voluntarios.buscarPorId.mockResolvedValueOnce(voluntario({ disciplinas: ['artes'] }));
    await expect(service.cadastrar(dadosTurma())).rejects.toThrow('nao leciona matematica');
    expect(turmas.criar).not.toHaveBeenCalled();
  });

  test('na edicao nao deixa capacidade abaixo dos matriculados', async () => {
    turmas.buscarPorId.mockResolvedValue(turma({ capacidade: 5 }));
    matriculas.contarAtivasDaTurma.mockResolvedValue(3);
    await expect(service.atualizar('t1', { capacidade: 2 })).rejects.toThrow(BusinessRuleError);
    await expect(service.atualizar('t1', { capacidade: 3 })).resolves.toEqual(expect.objectContaining({ capacidade: 3 }));
  });

  test('remover bloqueia turma com matriculas ativas e limpa historico quando pode', async () => {
    turmas.buscarPorId.mockResolvedValue(turma());
    matriculas.existeAtivaDaTurma.mockResolvedValueOnce(true);
    await expect(service.remover('t1')).rejects.toThrow(BusinessRuleError);

    await expect(service.remover('t1')).resolves.toBe(true);
    expect(matriculas.removerHistorico).toHaveBeenCalledWith({ turmaId: 't1' });
  });

  test('relatorioVagas delega ao repositorio', async () => {
    turmas.relatorioVagas.mockResolvedValue([{ vagas: 1 }]);
    expect(await service.relatorioVagas({ turno: 'tarde' })).toEqual([{ vagas: 1 }]);
    expect(turmas.relatorioVagas).toHaveBeenCalledWith({ turno: 'tarde' });
    await service.relatorioVagas();
    expect(turmas.relatorioVagas).toHaveBeenLastCalledWith({});
  });

  test('listarAlunos exige turma existente', async () => {
    await expect(service.listarAlunos('t1')).rejects.toThrow(NotFoundError);
    turmas.buscarPorId.mockResolvedValue(turma());
    await service.listarAlunos('t1');
    expect(matriculas.listarAlunosDaTurma).toHaveBeenCalledWith('t1');
  });
});

describe('MatriculaService', () => {
  let matriculas;
  let alunos;
  let turmas;
  let service;

  beforeEach(() => {
    matriculas = criarRepoMock();
    alunos = criarRepoMock();
    turmas = criarRepoMock();
    service = new MatriculaService(matriculas, alunos, turmas);
    alunos.buscarPorId.mockResolvedValue(aluno());
    turmas.buscarPorId.mockResolvedValue(turma({ capacidade: 2 }));
  });

  test('matricula aluno ativo em turma do mesmo turno com vaga', async () => {
    const m = await service.matricular({ alunoId: 'a1', turmaId: 't1' });
    expect(m).toBeInstanceOf(Matricula);
    expect(matriculas.criar).toHaveBeenCalled();
  });

  test('valida ids obrigatorios', async () => {
    await expect(service.matricular({ alunoId: 'a1' })).rejects.toThrow(ValidationError);
    await expect(service.matricular()).rejects.toThrow(ValidationError);
  });

  test.each([
    ['aluno inexistente', () => alunos.buscarPorId.mockResolvedValue(null), NotFoundError],
    ['aluno inativo', () => alunos.buscarPorId.mockResolvedValue(aluno({ ativo: false })), BusinessRuleError],
    ['turma inexistente', () => turmas.buscarPorId.mockResolvedValue(null), NotFoundError],
    ['turma inativa', () => turmas.buscarPorId.mockResolvedValue(turma({ ativa: false })), BusinessRuleError],
    ['turno diferente', () => alunos.buscarPorId.mockResolvedValue(aluno({ turno: 'manha' })), BusinessRuleError],
    ['ja matriculado', () => matriculas.existeAtiva.mockResolvedValue(true), BusinessRuleError],
    ['turma lotada', () => matriculas.contarAtivasDaTurma.mockResolvedValue(2), BusinessRuleError],
  ])('rejeita matricula: %s', async (_, preparar, TipoErro) => {
    preparar();
    await expect(service.matricular({ alunoId: 'a1', turmaId: 't1' })).rejects.toThrow(TipoErro);
    expect(matriculas.criar).not.toHaveBeenCalled();
  });

  test('listar, buscar e listarDoAluno', async () => {
    await service.listar({ status: 'ativa' });
    expect(matriculas.listarTodas).toHaveBeenCalledWith({ status: 'ativa' });
    await service.listar();

    await expect(service.buscar('m1')).rejects.toThrow(NotFoundError);

    await service.listarDoAluno('a1');
    expect(matriculas.listarTodas).toHaveBeenLastCalledWith({ alunoId: 'a1' });
    alunos.buscarPorId.mockResolvedValue(null);
    await expect(service.listarDoAluno('zz')).rejects.toThrow(NotFoundError);
  });

  test('cancelar e registrarFrequencia persistem a matricula alterada', async () => {
    matriculas.buscarPorId.mockImplementation(async () => new Matricula({ alunoId: 'a1', turmaId: 't1' }).comId('m1'));

    const cancelada = await service.cancelar('m1');
    expect(cancelada.status).toBe('cancelada');

    const comFrequencia = await service.registrarFrequencia('m1', { data: '2026-11-02', presente: true });
    expect(comFrequencia.frequencias).toHaveLength(1);
    expect(matriculas.atualizar).toHaveBeenCalledTimes(2);

    await expect(service.registrarFrequencia('m1', undefined)).rejects.toThrow(ValidationError);
  });
});
