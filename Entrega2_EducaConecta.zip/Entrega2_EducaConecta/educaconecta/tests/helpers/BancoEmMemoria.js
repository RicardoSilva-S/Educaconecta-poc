const { ObjectId } = require('mongodb');
const mingo = require('mingo');

/**
 * Dublê (fake) do objeto "db" do driver do MongoDB, totalmente em memoria.
 * Implementa apenas os metodos usados pelos repositorios. Filtros e pipelines
 * de agregacao ($match, $lookup, $filter, $size...) sao executados pela
 * biblioteca "mingo", que segue a semantica de consulta do MongoDB.
 *
 * Usado nos testes de fluxo completo (HTTP -> controller -> service ->
 * repositorio -> "banco") sem precisar de um servidor MongoDB.
 */
function clonar(valor) {
  if (valor instanceof ObjectId) return new ObjectId(valor.toHexString());
  if (valor instanceof Date) return new Date(valor.getTime());
  if (Array.isArray(valor)) return valor.map(clonar);
  if (valor && typeof valor === 'object') {
    return Object.fromEntries(Object.entries(valor).map(([k, v]) => [k, clonar(v)]));
  }
  return valor;
}

const cursor = (docs) => ({ toArray: async () => docs.map(clonar) });

class ColecaoEmMemoria {
  constructor(banco) {
    this.banco = banco;
    this.documentos = [];
  }

  filtrar(filtro = {}) {
    return mingo.find(this.documentos, filtro).all();
  }

  async insertOne(doc) {
    const novo = { _id: new ObjectId(), ...clonar(doc) };
    this.documentos.push(novo);
    return { insertedId: novo._id };
  }

  find(filtro) {
    return cursor(this.filtrar(filtro));
  }

  async findOne(filtro) {
    const [doc] = this.filtrar(filtro);
    return doc ? clonar(doc) : null;
  }

  async findOneAndUpdate(filtro, { $set }) {
    const [doc] = this.filtrar(filtro);
    if (!doc) return null;
    Object.assign(doc, clonar($set));
    return clonar(doc);
  }

  async deleteOne(filtro) {
    const [doc] = this.filtrar(filtro);
    if (!doc) return { deletedCount: 0 };
    this.documentos = this.documentos.filter((d) => d !== doc);
    return { deletedCount: 1 };
  }

  async deleteMany(filtro) {
    const remover = new Set(this.filtrar(filtro));
    this.documentos = this.documentos.filter((d) => !remover.has(d));
    return { deletedCount: remover.size };
  }

  async countDocuments(filtro) {
    return this.filtrar(filtro).length;
  }

  aggregate(pipeline) {
    const resultado = mingo.aggregate(this.documentos, pipeline, {
      collectionResolver: (nome) => this.banco.collection(nome).documentos,
    });
    return cursor(resultado);
  }
}

class BancoEmMemoria {
  constructor() {
    this.colecoes = new Map();
  }

  collection(nome) {
    if (!this.colecoes.has(nome)) {
      this.colecoes.set(nome, new ColecaoEmMemoria(this));
    }
    return this.colecoes.get(nome);
  }
}

module.exports = BancoEmMemoria;
