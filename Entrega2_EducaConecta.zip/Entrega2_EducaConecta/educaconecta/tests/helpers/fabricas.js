/**
 * Fabricas de dados validos para os testes (evita repetir objetos grandes).
 * Cada uma aceita "overrides" para variar so o campo que interessa ao teste.
 */
const dadosEndereco = (overrides = {}) => ({
  rua: 'Rua A',
  numero: '100',
  bairro: 'Centro',
  cidade: 'Maringa',
  estado: 'PR',
  cep: '87000-000',
  ...overrides,
});

const dadosResponsavel = (overrides = {}) => ({
  nome: 'Ana Silva',
  parentesco: 'mae',
  telefone: '44999998888',
  principal: true,
  ...overrides,
});

const dadosAluno = (overrides = {}) => ({
  nome: 'Maria Silva',
  idade: 10,
  escola: 'EM Joao Paulo II',
  serie: '5o ano',
  turno: 'tarde',
  endereco: dadosEndereco(),
  responsaveis: [dadosResponsavel()],
  ...overrides,
});

const dadosVoluntario = (overrides = {}) => ({
  nome: 'Bruno Costa',
  email: 'bruno@educaconecta.org',
  telefone: '44991112222',
  disciplinas: ['Matematica', 'Portugues'],
  ...overrides,
});

const dadosTurma = (overrides = {}) => ({
  nome: 'Matematica Basica',
  disciplina: 'matematica',
  turno: 'tarde',
  capacidade: 2,
  voluntarioId: '64b000000000000000000001',
  horarios: [{ diaSemana: 'seg', inicio: '14:00', fim: '15:30' }],
  ...overrides,
});

module.exports = { dadosEndereco, dadosResponsavel, dadosAluno, dadosVoluntario, dadosTurma };
