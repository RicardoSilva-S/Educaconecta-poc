const request = require('supertest');
const criarApp = require('../../src/app');
const { ValidationError, NotFoundError, BusinessRuleError } = require('../../src/errors/DomainError');

/**
 * Testes da camada HTTP (rotas + controllers) com services dubles.
 * Verificam status HTTP, corpo e repasse correto de parametros.
 */
const criarCrudServiceMock = () => ({
  cadastrar: jest.fn(async (d) => ({ _id: '1', ...d })),
  listar: jest.fn(async () => []),
  buscar: jest.fn(async (id) => ({ _id: id })),
  atualizar: jest.fn(async (id, d) => ({ _id: id, ...d })),
  remover: jest.fn(async () => true),
});

describe('API HTTP', () => {
  let services;
  let app;

  beforeEach(() => {
    services = {
      alunoService: criarCrudServiceMock(),
      voluntarioService: criarCrudServiceMock(),
      turmaService: {
        ...criarCrudServiceMock(),
        relatorioVagas: jest.fn(async () => [{ nome: 'T', vagas: 2 }]),
        listarAlunos: jest.fn(async () => [{ nome: 'Maria' }]),
      },
      matriculaService: {
        matricular: jest.fn(async (d) => ({ _id: 'm1', ...d })),
        listar: jest.fn(async () => []),
        buscar: jest.fn(async (id) => ({ _id: id })),
        listarDoAluno: jest.fn(async () => [{ _id: 'm1' }]),
        cancelar: jest.fn(async (id) => ({ _id: id, status: 'cancelada' })),
        registrarFrequencia: jest.fn(async (id, f) => ({ _id: id, frequencias: [f] })),
      },
    };
    app = criarApp(services);
  });

  test('GET /health', async () => {
    const r = await request(app).get('/health');
    expect(r.status).toBe(200);
    expect(r.body).toEqual({ status: 'ok', versao: '2.0.0' });
  });

  describe.each([
    ['/alunos', 'alunoService'],
    ['/voluntarios', 'voluntarioService'],
    ['/turmas', 'turmaService'],
  ])('CRUD %s', (rota, nomeService) => {
    test('POST cria (201)', async () => {
      const r = await request(app).post(rota).send({ nome: 'X' });
      expect(r.status).toBe(201);
      expect(services[nomeService].cadastrar).toHaveBeenCalledWith({ nome: 'X' });
    });

    test('GET lista (200)', async () => {
      const r = await request(app).get(rota);
      expect(r.status).toBe(200);
      expect(r.body).toEqual([]);
    });

    test('GET /:id busca (200)', async () => {
      const r = await request(app).get(`${rota}/abc`);
      expect(r.status).toBe(200);
      expect(r.body._id).toBe('abc');
    });

    test('PUT /:id atualiza (200)', async () => {
      const r = await request(app).put(`${rota}/abc`).send({ nome: 'Y' });
      expect(r.status).toBe(200);
      expect(services[nomeService].atualizar).toHaveBeenCalledWith('abc', { nome: 'Y' });
    });

    test('DELETE /:id remove (204)', async () => {
      const r = await request(app).delete(`${rota}/abc`);
      expect(r.status).toBe(204);
      expect(r.text).toBe('');
    });
  });

  test('GET /alunos repassa filtros de ativos e cidade', async () => {
    await request(app).get('/alunos?ativos=true&cidade=Maringa');
    expect(services.alunoService.listar).toHaveBeenCalledWith({ apenasAtivos: true, cidade: 'Maringa' });
    await request(app).get('/alunos');
    expect(services.alunoService.listar).toHaveBeenLastCalledWith({ apenasAtivos: false, cidade: undefined });
  });

  test('GET /voluntarios e /turmas repassam filtros', async () => {
    await request(app).get('/voluntarios?disciplina=artes');
    expect(services.voluntarioService.listar).toHaveBeenCalledWith({ disciplina: 'artes' });
    await request(app).get('/turmas?turno=tarde&disciplina=matematica');
    expect(services.turmaService.listar).toHaveBeenCalledWith({ turno: 'tarde', disciplina: 'matematica' });
  });

  test('GET /alunos/:id/matriculas', async () => {
    const r = await request(app).get('/alunos/a1/matriculas');
    expect(r.status).toBe(200);
    expect(services.matriculaService.listarDoAluno).toHaveBeenCalledWith('a1');
  });

  test('GET /turmas/vagas nao e confundido com /turmas/:id', async () => {
    const r = await request(app).get('/turmas/vagas?turno=tarde');
    expect(r.status).toBe(200);
    expect(r.body).toEqual([{ nome: 'T', vagas: 2 }]);
    expect(services.turmaService.relatorioVagas).toHaveBeenCalledWith({ turno: 'tarde' });
    expect(services.turmaService.buscar).not.toHaveBeenCalled();
  });

  test('GET /turmas/:id/alunos', async () => {
    const r = await request(app).get('/turmas/t1/alunos');
    expect(r.status).toBe(200);
    expect(services.turmaService.listarAlunos).toHaveBeenCalledWith('t1');
  });

  test('rotas de matricula', async () => {
    expect((await request(app).post('/matriculas').send({ alunoId: 'a1', turmaId: 't1' })).status).toBe(201);
    expect((await request(app).get('/matriculas?turmaId=t1&status=ativa')).status).toBe(200);
    expect(services.matriculaService.listar).toHaveBeenCalledWith({ alunoId: undefined, turmaId: 't1', status: 'ativa' });
    expect((await request(app).get('/matriculas/m1')).body._id).toBe('m1');
    expect((await request(app).patch('/matriculas/m1/cancelar')).body.status).toBe('cancelada');

    const r = await request(app).post('/matriculas/m1/frequencias').send({ data: '2026-11-02', presente: true });
    expect(r.status).toBe(201);
    expect(services.matriculaService.registrarFrequencia).toHaveBeenCalledWith('m1', { data: '2026-11-02', presente: true });
  });

  describe('traducao de erros de dominio para HTTP', () => {
    test.each([
      [new ValidationError('dados invalidos'), 400],
      [new NotFoundError('Aluno', 'x'), 404],
      [new BusinessRuleError('regra violada'), 409],
      [new Error('falha inesperada'), 500],
    ])('%s -> %i', async (erro, status) => {
      services.alunoService.buscar.mockRejectedValue(erro);
      const r = await request(app).get('/alunos/x');
      expect(r.status).toBe(status);
      expect(r.body.erro).toBe(status === 500 ? 'Erro interno do servidor.' : erro.message);
    });

    test('chave duplicada do MongoDB (codigo 11000) -> 409', async () => {
      services.matriculaService.matricular.mockRejectedValue(Object.assign(new Error('E11000'), { code: 11000 }));
      const r = await request(app).post('/matriculas').send({});
      expect(r.status).toBe(409);
      expect(r.body.erro).toContain('Registro duplicado');
    });

    test('erro em DELETE tambem e tratado', async () => {
      services.turmaService.remover.mockRejectedValue(new BusinessRuleError('tem matriculas'));
      const r = await request(app).delete('/turmas/t1');
      expect(r.status).toBe(409);
    });
  });

  test('JSON malformado responde 400', async () => {
    const r = await request(app).post('/alunos').set('Content-Type', 'application/json').send('{"nome":');
    expect(r.status).toBe(400);
    expect(r.body.erro).toBe('JSON invalido no corpo da requisicao.');
  });

  test('corpo grande demais responde 413', async () => {
    const grande = JSON.stringify({ texto: 'x'.repeat(200 * 1024) });
    const r = await request(app).post('/alunos').set('Content-Type', 'application/json').send(grande);
    expect(r.status).toBe(413);
  });

  test('rota inexistente responde 404 em JSON', async () => {
    const r = await request(app).get('/nao-existe');
    expect(r.status).toBe(404);
    expect(r.body.erro).toContain('/nao-existe');
  });
});
