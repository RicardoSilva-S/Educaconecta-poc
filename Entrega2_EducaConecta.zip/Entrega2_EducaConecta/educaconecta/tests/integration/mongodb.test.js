/**
 * Testes de INTEGRACAO com um MongoDB real (mongodb-memory-server).
 * Validam o que os testes unitarios nao conseguem: indices, validacao
 * $jsonSchema e as agregacoes executadas pelo proprio servidor MongoDB.
 *
 *   npm run test:integration
 *
 * Na primeira execucao o pacote baixa o binario do MongoDB (~100 MB, precisa de internet).
 */
const { MongoMemoryServer } = require('mongodb-memory-server');
const { MongoClient, ObjectId } = require('mongodb');
const request = require('supertest');
const criarApp = require('../../src/app');
const { criarContainer } = require('../../src/container');
const { criarIndices } = require('../../src/db/indices');
const COLECOES = require('../../src/db/colecoes');
const { dadosAluno, dadosVoluntario, dadosTurma } = require('../helpers/fabricas');

let servidor;
let cliente;
let db;
let app;

beforeAll(async () => {
  servidor = await MongoMemoryServer.create();
  cliente = await MongoClient.connect(servidor.getUri());
});

afterAll(async () => {
  await cliente.close();
  await servidor.stop();
});

beforeEach(async () => {
  db = cliente.db(`educaconecta_teste_${Date.now()}`);
  await criarIndices(db);
  app = criarApp(criarContainer(db).services);
});

afterEach(async () => {
  await db.dropDatabase();
});

const post = (rota, corpo) => request(app).post(rota).send(corpo);

test('criarIndices e idempotente e cria o indice unico parcial de matriculas', async () => {
  await criarIndices(db);
  const indices = await db.collection(COLECOES.matriculas).indexes();
  const unico = indices.find((i) => i.name === 'matricula_ativa_unica');
  expect(unico.unique).toBe(true);
  expect(unico.partialFilterExpression).toEqual({ status: 'ativa' });
});

test('fluxo principal contra o MongoDB real', async () => {
  const voluntario = (await post('/voluntarios', dadosVoluntario())).body;
  const turma = (await post('/turmas', dadosTurma({ voluntarioId: voluntario._id }))).body;
  const maria = (await post('/alunos', dadosAluno())).body;
  const joao = (await post('/alunos', dadosAluno({ nome: 'Joao Souza' }))).body;

  const m = await post('/matriculas', { alunoId: maria._id, turmaId: turma._id });
  expect(m.status).toBe(201);
  await post('/matriculas', { alunoId: joao._id, turmaId: turma._id });
  await post(`/matriculas/${m.body._id}/frequencias`, { data: '2026-11-02', presente: true });

  const vagas = (await request(app).get('/turmas/vagas')).body;
  expect(vagas).toEqual([expect.objectContaining({ turmaId: turma._id, matriculados: 2, vagas: 0 })]);

  const alunos = (await request(app).get(`/turmas/${turma._id}/alunos`)).body;
  expect(alunos.map((a) => a.nome)).toEqual(['Joao Souza', 'Maria Silva']);
  expect(alunos[1]).toEqual(expect.objectContaining({ aulasRegistradas: 1, presencas: 1 }));

  const docTurma = await db.collection(COLECOES.turmas).findOne({ _id: new ObjectId(turma._id) });
  expect(docTurma.voluntarioId).toBeInstanceOf(ObjectId);

  const porCidade = (await request(app).get('/alunos?cidade=Maringa')).body;
  expect(porCidade).toHaveLength(2);
});

test('indice unico impede duas matriculas ativas iguais direto no banco', async () => {
  const doc = { alunoId: new ObjectId(), turmaId: new ObjectId(), status: 'ativa', frequencias: [] };
  const matriculas = db.collection(COLECOES.matriculas);
  await matriculas.insertOne({ ...doc });
  await expect(matriculas.insertOne({ ...doc })).rejects.toThrow(/duplicate key/);
  // cancelada nao conta para o indice parcial
  await expect(matriculas.insertOne({ ...doc, status: 'cancelada' })).resolves.toBeDefined();
});

test('validacao $jsonSchema rejeita documento invalido gravado fora da aplicacao', async () => {
  await expect(db.collection(COLECOES.turmas).insertOne({ nome: 'Sem campos obrigatorios' })).rejects.toThrow(
    /Document failed validation/
  );
});

test('indice unico de e-mail de voluntario', async () => {
  const voluntarios = db.collection(COLECOES.voluntarios);
  await voluntarios.insertOne({ email: 'a@b.com' });
  await expect(voluntarios.insertOne({ email: 'a@b.com' })).rejects.toThrow(/duplicate key/);
});
