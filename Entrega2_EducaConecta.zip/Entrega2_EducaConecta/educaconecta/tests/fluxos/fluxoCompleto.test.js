const request = require('supertest');
const criarApp = require('../../src/app');
const { criarContainer } = require('../../src/container');
const BancoEmMemoria = require('../helpers/BancoEmMemoria');
const { dadosAluno, dadosVoluntario, dadosTurma } = require('../helpers/fabricas');

/**
 * Fluxos principais da PoC de ponta a ponta:
 * HTTP -> controllers -> services -> repositorios -> "banco" em memoria.
 * Nenhum dublê nas camadas da aplicacao: so o banco e simulado.
 */
describe('Fluxo completo da PoC (v2)', () => {
  let app;
  let banco;

  beforeEach(() => {
    banco = new BancoEmMemoria();
    app = criarApp(criarContainer(banco).services);
  });

  const post = (rota, corpo) => request(app).post(rota).send(corpo);

  async function prepararCenario() {
    const voluntario = (await post('/voluntarios', dadosVoluntario())).body;
    const turma = (await post('/turmas', dadosTurma({ voluntarioId: voluntario._id, capacidade: 2 }))).body;
    const maria = (await post('/alunos', dadosAluno())).body;
    const joao = (await post('/alunos', dadosAluno({ nome: 'Joao Souza', idade: 12 }))).body;
    const pedro = (await post('/alunos', dadosAluno({ nome: 'Pedro Lima', idade: 9 }))).body;
    return { voluntario, turma, maria, joao, pedro };
  }

  test('cadastro de aluno com documento aninhado e lista de subdocumentos', async () => {
    const r = await post('/alunos', dadosAluno());
    expect(r.status).toBe(201);
    expect(r.body._id).toMatch(/^[a-f0-9]{24}$/);

    const salvo = banco.collection('alunos').documentos[0];
    expect(salvo.endereco.cidade).toBe('Maringa');
    expect(salvo.responsaveis[0]).toEqual(expect.objectContaining({ nome: 'Ana Silva', principal: true }));

    const filtrados = await request(app).get('/alunos?cidade=Maringa&ativos=true');
    expect(filtrados.body).toHaveLength(1);
    expect((await request(app).get('/alunos?cidade=Londrina')).body).toHaveLength(0);
  });

  test('referencias sao gravadas como ObjectId no banco', async () => {
    const { turma } = await prepararCenario();
    const doc = banco.collection('turmas').documentos.find((d) => String(d._id) === turma._id);
    expect(doc.voluntarioId.constructor.name).toBe('ObjectId');
  });

  test('matricula, lotacao, relatorio de vagas e alunos da turma', async () => {
    const { turma, maria, joao, pedro } = await prepararCenario();

    const m1 = await post('/matriculas', { alunoId: maria._id, turmaId: turma._id });
    expect(m1.status).toBe(201);
    expect(m1.body.status).toBe('ativa');

    const duplicada = await post('/matriculas', { alunoId: maria._id, turmaId: turma._id });
    expect(duplicada.status).toBe(409);

    expect((await post('/matriculas', { alunoId: joao._id, turmaId: turma._id })).status).toBe(201);

    const lotada = await post('/matriculas', { alunoId: pedro._id, turmaId: turma._id });
    expect(lotada.status).toBe(409);
    expect(lotada.body.erro).toContain('sem vagas');

    const vagas = await request(app).get('/turmas/vagas');
    expect(vagas.body).toEqual([
      expect.objectContaining({ turmaId: turma._id, capacidade: 2, matriculados: 2, vagas: 0 }),
    ]);

    const alunosDaTurma = await request(app).get(`/turmas/${turma._id}/alunos`);
    expect(alunosDaTurma.body.map((a) => a.nome)).toEqual(['Joao Souza', 'Maria Silva']);

    // cancelar libera a vaga
    const cancelada = await request(app).patch(`/matriculas/${m1.body._id}/cancelar`);
    expect(cancelada.body.status).toBe('cancelada');
    expect((await request(app).get('/turmas/vagas')).body[0].vagas).toBe(1);
    expect((await post('/matriculas', { alunoId: pedro._id, turmaId: turma._id })).status).toBe(201);
  });

  test('registro de frequencia e percentual calculado', async () => {
    const { turma, maria } = await prepararCenario();
    const m = (await post('/matriculas', { alunoId: maria._id, turmaId: turma._id })).body;

    await post(`/matriculas/${m._id}/frequencias`, { data: '2026-11-02', presente: true });
    const r = await post(`/matriculas/${m._id}/frequencias`, { data: '2026-11-04', presente: false });
    expect(r.status).toBe(201);
    expect(r.body.percentualFrequencia).toBe(50);

    const repetida = await post(`/matriculas/${m._id}/frequencias`, { data: '2026-11-04', presente: true });
    expect(repetida.status).toBe(409);

    const daTurma = await request(app).get(`/turmas/${turma._id}/alunos`);
    expect(daTurma.body[0]).toEqual(expect.objectContaining({ aulasRegistradas: 2, presencas: 1 }));

    const doAluno = await request(app).get(`/alunos/${maria._id}/matriculas`);
    expect(doAluno.body).toHaveLength(1);
    expect(doAluno.body[0].frequencias).toHaveLength(2);
  });

  test('regras de turno e de aluno inativo na matricula', async () => {
    const { turma, maria } = await prepararCenario();
    const julia = (await post('/alunos', dadosAluno({ nome: 'Julia', turno: 'manha' }))).body;
    expect((await post('/matriculas', { alunoId: julia._id, turmaId: turma._id })).status).toBe(409);

    await request(app).put(`/alunos/${maria._id}`).send({ ativo: false });
    const r = await post('/matriculas', { alunoId: maria._id, turmaId: turma._id });
    expect(r.status).toBe(409);
    expect(r.body.erro).toBe('Aluno inativo nao pode ser matriculado.');
  });

  test('integridade referencial ao remover', async () => {
    const { voluntario, turma, maria } = await prepararCenario();
    const m = (await post('/matriculas', { alunoId: maria._id, turmaId: turma._id })).body;

    expect((await request(app).delete(`/alunos/${maria._id}`)).status).toBe(409);
    expect((await request(app).delete(`/turmas/${turma._id}`)).status).toBe(409);
    expect((await request(app).delete(`/voluntarios/${voluntario._id}`)).status).toBe(409);

    await request(app).patch(`/matriculas/${m._id}/cancelar`);
    expect((await request(app).delete(`/alunos/${maria._id}`)).status).toBe(204);
    expect(banco.collection('matriculas').documentos).toHaveLength(0);

    expect((await request(app).delete(`/turmas/${turma._id}`)).status).toBe(204);
    expect((await request(app).delete(`/voluntarios/${voluntario._id}`)).status).toBe(204);
  });

  test('turma exige voluntario existente que lecione a disciplina; capacidade respeita matriculados', async () => {
    const semVoluntario = await post('/turmas', dadosTurma({ voluntarioId: '64b0000000000000000000ff' }));
    expect(semVoluntario.status).toBe(404);

    const { voluntario, turma, maria, joao } = await prepararCenario();
    const outra = await post('/turmas', dadosTurma({ voluntarioId: voluntario._id, disciplina: 'historia' }));
    expect(outra.status).toBe(409);

    await post('/matriculas', { alunoId: maria._id, turmaId: turma._id });
    await post('/matriculas', { alunoId: joao._id, turmaId: turma._id });
    expect((await request(app).put(`/turmas/${turma._id}`).send({ capacidade: 1 })).status).toBe(409);
    expect((await request(app).put(`/turmas/${turma._id}`).send({ capacidade: 5 })).body.capacidade).toBe(5);
  });

  test('voluntario com e-mail duplicado e recusado', async () => {
    await post('/voluntarios', dadosVoluntario());
    const r = await post('/voluntarios', dadosVoluntario({ nome: 'Outro', email: 'BRUNO@educaconecta.org' }));
    expect(r.status).toBe(409);
    expect((await request(app).get('/voluntarios?disciplina=Portugues')).body).toHaveLength(1);
  });

  test('ids inexistentes ou mal formatados retornam 404', async () => {
    expect((await request(app).get('/alunos/123')).status).toBe(404);
    expect((await request(app).get('/turmas/64b0000000000000000000ff')).status).toBe(404);
    expect((await request(app).get('/matriculas/xyz')).status).toBe(404);
    expect((await post('/matriculas', { alunoId: 'xyz', turmaId: 'abc' })).status).toBe(404);
  });

  test('dados invalidos retornam 400 com mensagem clara', async () => {
    const r = await post('/alunos', dadosAluno({ responsaveis: [] }));
    expect(r.status).toBe(400);
    expect(r.body.erro).toBe('Responsaveis deve conter pelo menos um item.');
  });
});
