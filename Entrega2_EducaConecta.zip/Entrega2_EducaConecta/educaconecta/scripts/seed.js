/**
 * Popula o banco com dados de exemplo para demonstracao da PoC.
 * Usa os proprios services, entao todas as regras de negocio sao aplicadas.
 *
 *   npm run seed
 *
 * ATENCAO: apaga os dados das 4 colecoes antes de inserir.
 */
require('dotenv').config();
const { conectar, desconectar } = require('../src/db/database');
const { criarIndices } = require('../src/db/indices');
const { criarContainer } = require('../src/container');
const COLECOES = require('../src/db/colecoes');

const endereco = (rua, numero, bairro) => ({
  rua,
  numero,
  bairro,
  cidade: 'Maringa',
  estado: 'PR',
  cep: '87000-000',
});

async function popular() {
  const db = await conectar();
  for (const nome of Object.values(COLECOES)) {
    await db.collection(nome).deleteMany({});
  }
  await criarIndices(db);
  const { alunoService, voluntarioService, turmaService, matriculaService } = criarContainer(db).services;

  const ana = await voluntarioService.cadastrar({
    nome: 'Ana Pereira',
    email: 'ana.pereira@educaconecta.org',
    telefone: '44991112222',
    disciplinas: ['Matematica', 'Ciencias'],
  });
  const bruno = await voluntarioService.cadastrar({
    nome: 'Bruno Costa',
    email: 'bruno.costa@educaconecta.org',
    telefone: '44993334444',
    disciplinas: ['Portugues'],
  });

  const matTarde = await turmaService.cadastrar({
    nome: 'Matematica Basica - Tarde',
    disciplina: 'matematica',
    turno: 'tarde',
    capacidade: 3,
    voluntarioId: ana._id,
    horarios: [
      { diaSemana: 'seg', inicio: '14:00', fim: '15:30' },
      { diaSemana: 'qua', inicio: '14:00', fim: '15:30' },
    ],
  });
  const portTarde = await turmaService.cadastrar({
    nome: 'Leitura e Escrita - Tarde',
    disciplina: 'portugues',
    turno: 'tarde',
    capacidade: 10,
    voluntarioId: bruno._id,
    horarios: [{ diaSemana: 'ter', inicio: '15:00', fim: '16:30' }],
  });
  await turmaService.cadastrar({
    nome: 'Ciencias - Manha',
    disciplina: 'ciencias',
    turno: 'manha',
    capacidade: 8,
    voluntarioId: ana._id,
    horarios: [{ diaSemana: 'qui', inicio: '09:00', fim: '10:30' }],
  });

  const dadosAlunos = [
    ['Maria Silva', 10, '5o ano', 'tarde', 'Ana Silva', 'mae', '44999998888', endereco('Rua A', '100', 'Centro')],
    ['Joao Souza', 12, '7o ano', 'tarde', 'Carla Souza', 'mae', '44988887777', endereco('Rua B', '25', 'Zona 7')],
    ['Pedro Lima', 9, '4o ano', 'tarde', 'Fabio Lima', 'pai', '44977776666', endereco('Rua C', '8', 'Jardim Alvorada')],
    ['Lucas Rocha', 11, '6o ano', 'tarde', 'Sonia Rocha', 'avo', '44966665555', null],
    ['Julia Alves', 8, '3o ano', 'manha', 'Rita Alves', 'mae', '44955554444', endereco('Rua D', '300', 'Zona 5')],
  ];
  const alunos = [];
  for (const [nome, idade, serie, turno, resp, parentesco, telefone, end] of dadosAlunos) {
    alunos.push(
      await alunoService.cadastrar({
        nome,
        idade,
        escola: 'EM Joao Paulo II',
        serie,
        turno,
        endereco: end,
        responsaveis: [{ nome: resp, parentesco, telefone, principal: true }],
      })
    );
  }

  const [maria, joao, pedro, lucas, julia] = alunos;
  const m1 = await matriculaService.matricular({ alunoId: maria._id, turmaId: matTarde._id });
  const m2 = await matriculaService.matricular({ alunoId: joao._id, turmaId: matTarde._id });
  await matriculaService.matricular({ alunoId: pedro._id, turmaId: matTarde._id });
  await matriculaService.matricular({ alunoId: lucas._id, turmaId: portTarde._id });
  await matriculaService.matricular({ alunoId: maria._id, turmaId: portTarde._id });

  await matriculaService.registrarFrequencia(m1._id, { data: '2026-11-02', presente: true });
  await matriculaService.registrarFrequencia(m1._id, { data: '2026-11-04', presente: true });
  await matriculaService.registrarFrequencia(m2._id, { data: '2026-11-02', presente: false });
  await matriculaService.registrarFrequencia(m2._id, { data: '2026-11-04', presente: true });

  console.log('Banco populado com sucesso!');
  console.log(`- ${alunos.length} alunos (Julia, id ${julia._id}, ainda sem turma)`);
  console.log('- 2 voluntarios, 3 turmas, 5 matriculas');
  console.log('\nRelatorio de vagas:');
  console.table(await turmaService.relatorioVagas());
}

popular()
  .catch((erro) => {
    console.error('Falha ao popular o banco:', erro.message);
    process.exitCode = 1;
  })
  .finally(desconectar);
