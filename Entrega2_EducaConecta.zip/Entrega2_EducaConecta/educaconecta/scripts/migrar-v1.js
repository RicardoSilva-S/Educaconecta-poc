/**
 * Migra alunos gravados no formato da 1a entrega
 *   { ..., responsavel: 'Ana', telefone: '44999998888' }
 * para o formato da 2a entrega
 *   { ..., endereco: null, responsaveis: [{ nome, parentesco, telefone, principal }] }
 *
 *   npm run migrar
 *
 * A conversao reaproveita Aluno.fromDocument, que ja entende o formato antigo.
 */
require('dotenv').config();
const { conectar, desconectar } = require('../src/db/database');
const { Aluno } = require('../src/models/Aluno');
const COLECOES = require('../src/db/colecoes');

async function migrar() {
  const db = await conectar();
  const alunos = db.collection(COLECOES.alunos);
  const antigos = await alunos.find({ responsavel: { $exists: true }, responsaveis: { $exists: false } }).toArray();

  for (const doc of antigos) {
    const novo = Aluno.fromDocument(doc).toDocument();
    await alunos.updateOne({ _id: doc._id }, { $set: novo, $unset: { responsavel: '', telefone: '' } });
  }
  console.log(`${antigos.length} aluno(s) migrado(s) para o formato v2.`);
}

migrar()
  .catch((erro) => {
    console.error('Falha na migracao:', erro.message);
    process.exitCode = 1;
  })
  .finally(desconectar);
