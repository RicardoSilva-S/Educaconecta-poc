# Testes automatizados e cobertura

## Como executar

```bash
npm install
npm test                    # unitários + fluxo completo + relatório de cobertura (não precisa de MongoDB)
npm run test:integration    # integração com MongoDB real em memória (baixa o MongoDB na 1ª execução)
```

O `npm test` **falha** se qualquer métrica de cobertura ficar abaixo de 70% (`coverageThreshold` no `package.json`).
Relatórios gerados: tabela no terminal, `coverage/lcov-report/index.html` (abra no navegador) e `coverage/lcov.info`.

## Resultado — versão 2.0.0

```
Test Suites: 9 passed, 9 total
Tests:       160 passed, 160 total

Statements   : 99.81% ( 542/543 )
Branches     : 97.95% ( 240/245 )
Functions    : 99.38% ( 162/163 )
Lines        : 99.79% ( 497/498 )
```

Ficam fora do cálculo, porque dependem de um MongoDB/servidor real: `src/server.js` (inicialização), `src/db/database.js` (conexão) e `src/db/indices.js` (criação de índices). Esses três são exercitados pelos testes de integração.

## Pirâmide de testes

| Nível | Suíte | O que verifica | Dublês |
|---|---|---|---|
| Unitário — domínio | `tests/models/*.test.js` (5 suítes) | Validações de cada entidade e objeto de valor, regras internas (responsável principal, horários, frequência, percentual, cancelamento), conversão do formato v1 | Nenhum |
| Unitário — persistência | `tests/repositories/repositorios.test.js` | Conversão string ↔ ObjectId, filtros (incluindo campo aninhado e array), pipelines de agregação, compatibilidade com o retorno do driver | Collection mockada (`jest.fn`) |
| Unitário — negócio | `tests/services/services.test.js` | Todas as regras de negócio e de integridade entre coleções | Repositórios mockados |
| Unitário — HTTP | `tests/controllers/rotas.test.js` | Rotas, status HTTP, filtros de query, tradução de erros (400/404/409/413/500), JSON malformado, 404 de rota | Services mockados |
| **Fluxo completo** | `tests/fluxos/fluxoCompleto.test.js` | Fluxos principais de ponta a ponta via HTTP: cadastro → matrícula → lotação → relatório de vagas → frequência → cancelamento → remoção com integridade | Só o banco: `BancoEmMemoria` executa filtros e agregações com a biblioteca *mingo* (semântica de consulta do MongoDB) |
| Integração | `tests/integration/mongodb.test.js` | Fluxo contra o **MongoDB real**, índice único parcial, validação `$jsonSchema`, unicidade de e-mail | Nenhum (mongodb-memory-server) |

## Casos de teste relevantes (amostra)

| Comportamento | Onde |
|---|---|
| Turma lotada recusa nova matrícula (409) e o cancelamento libera a vaga | fluxo completo |
| Aluno com turno diferente da turma não é matriculado | services, fluxo |
| Matrícula duplicada é recusada pela regra (service) e pelo índice do banco (integração) | services, fluxo, integração |
| Não é possível remover aluno/turma com matrícula ativa nem voluntário com turma | services, fluxo |
| Capacidade da turma não pode ficar menor que o número de matriculados | services, fluxo |
| Frequência: data inválida (400), data repetida (409), percentual calculado | models, fluxo |
| Documento no formato da 1ª entrega é lido e convertido | models |
| Ids mal formatados retornam 404, não 500 | repositórios, fluxo |
