# Banco de Dados — Modelagem NoSQL (MongoDB)

Banco: **MongoDB 7**, orientado a documentos. Nome padrão do banco: `educaconecta` (variável `DB_NAME`).

## 1. Visão geral

| Coleção | O que guarda | Objetos complexos | Referências |
|---|---|---|---|
| `alunos` | Crianças/adolescentes atendidos | `endereco` (documento aninhado), `responsaveis[]` (lista de subdocumentos) | — |
| `voluntarios` | Professores/tutores voluntários | `disciplinas[]` (lista de valores) | — |
| `turmas` | Turmas de reforço | `horarios[]` (lista de subdocumentos) | `voluntarioId → voluntarios._id` |
| `matriculas` | Vínculo aluno ↔ turma | `frequencias[]` (lista de subdocumentos) | `alunoId → alunos._id`, `turmaId → turmas._id` |

```mermaid
erDiagram
    VOLUNTARIOS ||--o{ TURMAS : "conduz (voluntarioId)"
    TURMAS ||--o{ MATRICULAS : "recebe (turmaId)"
    ALUNOS ||--o{ MATRICULAS : "possui (alunoId)"

    ALUNOS {
        ObjectId _id
        string nome
        int idade
        string escola
        string serie
        string turno
        object endereco "documento aninhado"
        array responsaveis "subdocumentos"
        bool ativo
    }
    VOLUNTARIOS {
        ObjectId _id
        string nome
        string email "unico"
        string telefone
        array disciplinas
        bool ativo
    }
    TURMAS {
        ObjectId _id
        string nome
        string disciplina
        string turno
        int capacidade
        ObjectId voluntarioId "referencia"
        array horarios "subdocumentos"
        bool ativa
    }
    MATRICULAS {
        ObjectId _id
        ObjectId alunoId "referencia"
        ObjectId turmaId "referencia"
        string status "ativa | cancelada"
        date dataMatricula
        date dataCancelamento
        array frequencias "subdocumentos"
    }
```

## 2. Documentos de exemplo

### `alunos`
```json
{
  "_id": { "$oid": "6730f1a2c9e77b1a2b3c4d01" },
  "nome": "Maria Silva",
  "idade": 10,
  "escola": "EM Joao Paulo II",
  "serie": "5o ano",
  "turno": "tarde",
  "endereco": {
    "rua": "Rua A", "numero": "100", "bairro": "Centro",
    "cidade": "Maringa", "estado": "PR", "cep": "87000000"
  },
  "responsaveis": [
    { "nome": "Ana Silva",  "parentesco": "mae", "telefone": "44999998888", "principal": true },
    { "nome": "Jose Silva", "parentesco": "pai", "telefone": "44988880000", "principal": false }
  ],
  "ativo": true
}
```
- `turno` é o turno em que o aluno está **disponível para o reforço** (contraturno da escola).
- `endereco` é opcional (`null`); quando informado, todos os campos são validados (UF válida, CEP com 8 dígitos).
- `responsaveis` tem pelo menos um item e **exatamente um** `principal: true`. Se nenhum vier marcado, o primeiro vira o principal.

### `voluntarios`
```json
{
  "_id": { "$oid": "6730f1a2c9e77b1a2b3c4d10" },
  "nome": "Ana Pereira",
  "email": "ana.pereira@educaconecta.org",
  "telefone": "44991112222",
  "disciplinas": ["matematica", "ciencias"],
  "ativo": true
}
```

### `turmas`
```json
{
  "_id": { "$oid": "6730f1a2c9e77b1a2b3c4d20" },
  "nome": "Matematica Basica - Tarde",
  "disciplina": "matematica",
  "turno": "tarde",
  "capacidade": 3,
  "voluntarioId": { "$oid": "6730f1a2c9e77b1a2b3c4d10" },
  "horarios": [
    { "diaSemana": "seg", "inicio": "14:00", "fim": "15:30" },
    { "diaSemana": "qua", "inicio": "14:00", "fim": "15:30" }
  ],
  "ativa": true
}
```

### `matriculas`
```json
{
  "_id": { "$oid": "6730f1a2c9e77b1a2b3c4d30" },
  "alunoId": { "$oid": "6730f1a2c9e77b1a2b3c4d01" },
  "turmaId": { "$oid": "6730f1a2c9e77b1a2b3c4d20" },
  "status": "ativa",
  "dataMatricula": { "$date": "2026-11-01T13:00:00.000Z" },
  "dataCancelamento": null,
  "frequencias": [
    { "data": "2026-11-02", "presente": true },
    { "data": "2026-11-04", "presente": false }
  ]
}
```

## 3. Embutir ou referenciar? (decisões de modelagem)

| Dado | Decisão | Motivo |
|---|---|---|
| Endereço e responsáveis do aluno | **Embutido** em `alunos` | Pertencem só ao aluno, são sempre lidos junto com ele e são poucos itens. Uma única leitura traz tudo. |
| Horários da turma | **Embutido** em `turmas` | Lista pequena (no máximo 6 dias) que não existe fora da turma. |
| Disciplinas do voluntário | **Embutido** (array de strings) | Valores simples; o MongoDB consulta direto dentro do array (`{ disciplinas: "matematica" }`). |
| Frequências | **Embutido** em `matriculas` | Cada presença só faz sentido dentro da matrícula. O volume por matrícula é limitado (cerca de 2 a 3 aulas por semana em um semestre fica bem abaixo do limite de 16 MB por documento). |
| Voluntário da turma | **Referência** (`voluntarioId`) | Um voluntário conduz várias turmas. Embutir duplicaria os dados dele e exigiria atualizar várias turmas a cada mudança. |
| Aluno ↔ Turma | **Coleção própria** `matriculas` com duas referências | É um relacionamento N:N com dados próprios (status, datas, frequências). Embutir nos dois lados duplicaria dados e geraria documentos crescendo sem limite. |

As referências são gravadas como **`ObjectId`** (convertidas no `BaseRepository`) e expostas na API como string.

## 4. Índices

Criados automaticamente na inicialização (`src/db/indices.js`); a criação é idempotente.

| Coleção | Índice | Para quê |
|---|---|---|
| `alunos` | `{ ativo: 1, turno: 1 }` | Listagem de alunos ativos (`?ativos=true`) |
| `alunos` | `{ "endereco.cidade": 1 }` | Filtro por cidade (campo de documento aninhado) |
| `voluntarios` | `{ email: 1 }` **único** | Impede e-mail duplicado |
| `turmas` | `{ turno: 1, disciplina: 1 }` | Filtros da listagem de turmas |
| `turmas` | `{ voluntarioId: 1 }` | Checar se um voluntário tem turmas antes de removê-lo |
| `matriculas` | `{ turmaId: 1, status: 1 }` | Contagem de matriculados (vagas) e `$lookup` |
| `matriculas` | `{ alunoId: 1, turmaId: 1 }` **único parcial** (`status: "ativa"`) | Garante **no próprio banco** que um aluno não tenha duas matrículas ativas na mesma turma, mesmo com requisições simultâneas. Matrículas canceladas ficam fora do índice, então o aluno pode se matricular de novo. |

## 5. Validação de esquema (`$jsonSchema`)

Além da validação feita pelas classes do domínio, o banco valida a estrutura mínima de `alunos`, `turmas` e `matriculas` (campos obrigatórios, tipos `objectId` das referências, `enum` de turno e status, arrays com tamanho mínimo). Assim, documentos inválidos são recusados mesmo quando gravados por fora da aplicação (por exemplo, pelo MongoDB Compass).

## 6. Agregações utilizadas

### Relatório de vagas — `GET /turmas/vagas` (`TurmaRepository.pipelineRelatorioVagas`)
```js
[
  { $match: { ativa: true /*, turno */ } },
  { $lookup: {
      from: 'matriculas',
      let: { idTurma: '$_id' },
      pipeline: [{ $match: { $expr: { $and: [
        { $eq: ['$turmaId', '$$idTurma'] }, { $eq: ['$status', 'ativa'] } ] } } }],
      as: 'matriculasAtivas' } },
  { $project: { _id: 0, turmaId: '$_id', nome: 1, disciplina: 1, turno: 1, capacidade: 1,
                matriculados: { $size: '$matriculasAtivas' } } },
  { $addFields: { vagas: { $max: [{ $subtract: ['$capacidade', '$matriculados'] }, 0] } } },
  { $sort: { turno: 1, nome: 1 } }
]
```

### Alunos de uma turma com resumo de frequência — `GET /turmas/:id/alunos` (`MatriculaRepository.pipelineAlunosDaTurma`)
```js
[
  { $match: { turmaId: ObjectId(id), status: 'ativa' } },
  { $lookup: { from: 'alunos', localField: 'alunoId', foreignField: '_id', as: 'aluno' } },
  { $unwind: '$aluno' },
  { $project: { _id: 0, matriculaId: '$_id', alunoId: '$aluno._id', nome: '$aluno.nome',
                idade: '$aluno.idade', serie: '$aluno.serie',
                aulasRegistradas: { $size: '$frequencias' },
                presencas: { $size: { $filter: { input: '$frequencias', as: 'f',
                                                  cond: { $eq: ['$$f.presente', true] } } } } } },
  { $sort: { nome: 1 } }
]
```

## 7. Integridade entre coleções

O MongoDB não tem chaves estrangeiras, então a integridade é garantida pelos services:

| Operação | Regra |
|---|---|
| Criar/editar turma | O voluntário precisa existir, estar ativo e lecionar a disciplina |
| Editar turma | A capacidade não pode ficar abaixo do número de matriculados |
| Matricular | O aluno e a turma precisam existir e estar ativos, com o mesmo turno, sem matrícula ativa repetida e com vaga |
| Remover aluno | Bloqueado se houver matrícula ativa; o histórico cancelado é apagado junto |
| Remover turma | Bloqueado se houver matrícula ativa; o histórico cancelado é apagado junto |
| Remover voluntário | Bloqueado se ele for responsável por alguma turma |

## 8. Migração da 1ª entrega

Na 1ª entrega o aluno tinha os campos planos `responsavel` e `telefone`. O comando `npm run migrar` (`scripts/migrar-v1.js`) converte esses documentos para `responsaveis: [{ nome, telefone, parentesco: "outro", principal: true }]`. Além disso, `Aluno.fromDocument` entende os dois formatos, então dados antigos continuam legíveis mesmo antes da migração.

## 9. Dados de exemplo

`npm run seed` apaga as quatro coleções e insere 2 voluntários, 3 turmas, 5 alunos, 5 matrículas e 4 registros de frequência. A inserção passa pelos services, então respeita todas as regras. Uma das turmas fica **lotada**, para demonstrar a regra de vagas.
