# Metodologia de trabalho

## Kanban com iterações curtas

A equipe usou **Kanban** num quadro de tarefas (GitHub Projects), organizado em iterações de cerca de 2 semanas, uma para cada marco da AEP.

**Quadro:** _(cole aqui o link público do quadro)_

### Colunas
| Coluna | Significado |
|---|---|
| **Backlog** | Tarefas identificadas, ainda não priorizadas |
| **A fazer** | Priorizadas para a iteração atual |
| **Em andamento** | Alguém está trabalhando (limite de 2 tarefas por pessoa) |
| **Em revisão / testes** | Código pronto aguardando testes e revisão de outro integrante |
| **Concluído** | Testes passando, cobertura ≥ 70% e documentação atualizada |

### Definição de pronto (DoD)
1. O código segue a arquitetura em camadas e não duplica lógica existente.
2. Testes automatizados novos ou ajustados, com `npm test` passando e cobertura ≥ 70%.
3. Documentação (README/docs) atualizada quando o comportamento mudou.
4. Commit com mensagem no padrão *Conventional Commits*.

### Rótulos
`banco`, `dominio`, `api`, `testes`, `docs`, `infra`, `video`

## Iterações e tarefas

A lista completa está em [`quadro-de-tarefas.csv`](quadro-de-tarefas.csv), que pode ser importado no GitHub Projects ou no Trello.

### Iteração 1 — Entrega 1 (v1.0.0)
| # | Tarefa | Rótulo | Status |
|---|---|---|---|
| 1 | Definir problema, público e ODS | docs | Concluído |
| 2 | Criar repositório e estrutura do projeto Node/Express | infra | Concluído |
| 3 | Modelar a coleção `alunos` | banco | Concluído |
| 4 | Classe `Aluno` com validações | dominio | Concluído |
| 5 | Repository, service, controller e rotas do CRUD de alunos | api | Concluído |
| 6 | Testes unitários e de rotas (cobertura ≥ 70%) | testes | Concluído |
| 7 | README inicial | docs | Concluído |
| 8 | Vídeo da 1ª entrega (2 a 3 min) | video | Concluído |

### Iteração 2 — Entrega 2 (v2.0.0)
| # | Tarefa | Rótulo | Status |
|---|---|---|---|
| 9 | Modelar coleções `voluntarios`, `turmas`, `matriculas` e relacionamentos | banco | Concluído |
| 10 | Endereço aninhado e lista de responsáveis no aluno (+ migração v1) | banco | Concluído |
| 11 | Refatorar: `Entidade`, `BaseRepository`, `CrudService`, `BaseController`, `DomainError`, `Validador` | dominio | Concluído |
| 12 | CRUD de voluntários (e-mail único) | api | Concluído |
| 13 | CRUD de turmas (horários, voluntário, capacidade) | api | Concluído |
| 14 | Matrícula com regras de vaga, turno e duplicidade | api | Concluído |
| 15 | Registro de frequência e percentual | api | Concluído |
| 16 | Relatório de vagas e alunos por turma (agregações) | banco | Concluído |
| 17 | Índices e validação `$jsonSchema` | banco | Concluído |
| 18 | Integridade referencial nas remoções | api | Concluído |
| 19 | Testes de modelos, repositórios, services e rotas | testes | Concluído |
| 20 | Teste de fluxo completo com banco em memória | testes | Concluído |
| 21 | Testes de integração com MongoDB real | testes | Concluído |
| 22 | Script de dados de exemplo e docker-compose | infra | Concluído |
| 23 | Documentação técnica (arquitetura, banco, API, testes) | docs | Concluído |
| 24 | Tag `v2.0.0` e release | infra | Concluído |
| 25 | Vídeo da 2ª entrega (3 a 5 min) | video | Concluído |
