# Arquitetura

## 1. Camadas

```
HTTP ──> routes ──> controllers ──> services ──> repositories ──> MongoDB
                        │               │              │
                        │               └── models (entidades + validação)
                        └── errors (DomainError → status HTTP)
```

| Camada | Responsabilidade | Não faz |
|---|---|---|
| `routes/` | Mapear URL + verbo → método do controller | Lógica |
| `controllers/` | Ler `req` (params, query, body), chamar o service, devolver status/JSON | Regras de negócio, acesso ao banco |
| `services/` | Regras de negócio que envolvem mais de uma entidade/coleção | Conhecer HTTP ou o driver do Mongo |
| `models/` | Estado e invariantes de cada entidade (validação no construtor, comportamentos como `cancelar()` e `registrarFrequencia()`) | Acesso a banco |
| `repositories/` | Converter entidade ↔ documento, consultas e agregações | Regras de negócio |
| `container.js` | Criar e ligar todos os objetos (composition root) | — |

Todas as dependências entram **pelo construtor** (injeção de dependência). Por isso cada camada é testada isoladamente com dublês, e o fluxo completo é testado trocando só o banco por uma versão em memória.

## 2. Diagrama de classes

```mermaid
classDiagram
    class Entidade {
        <<abstract>>
        +_id
        +toDocument()*
        +toJSON()
        +comId(id)
        +fromDocument(doc)$
    }
    Entidade <|-- Aluno
    Entidade <|-- Voluntario
    Entidade <|-- Turma
    Entidade <|-- Matricula
    Aluno *-- "0..1" Endereco
    Aluno *-- "1..*" Responsavel
    class Aluno {
        +nome, idade, escola, serie, turno, ativo
        +responsavelPrincipal
        +inativar()
        +ativar()
        +fromDocument(doc)$ aceita formato v1
    }
    class Voluntario { +email, disciplinas[] +podeLecionar(disciplina) }
    class Turma { +capacidade, turno, voluntarioId, horarios[] +vagasDisponiveis(n) }
    class Matricula {
        +alunoId, turmaId, status, frequencias[]
        +cancelar()
        +registrarFrequencia(dados)
        +percentualFrequencia()
    }

    class BaseRepository {
        #collection
        #camposReferencia
        +criar() listar() buscarPorId() atualizar() remover() contar() existe()
        +paraBanco() paraEntidade()
    }
    BaseRepository <|-- AlunoRepository
    BaseRepository <|-- VoluntarioRepository
    BaseRepository <|-- TurmaRepository
    BaseRepository <|-- MatriculaRepository
    class TurmaRepository { +relatorioVagas() }
    class MatriculaRepository { +listarAlunosDaTurma() +contarAtivasDaTurma() +removerHistorico() }

    class CrudService {
        +cadastrar() listar() buscar() atualizar() remover()
        #validarRelacionamentos(entidade, idAtual)
        #antesDeRemover(entidade)
    }
    CrudService <|-- AlunoService
    CrudService <|-- VoluntarioService
    CrudService <|-- TurmaService
    class MatriculaService { +matricular() cancelar() registrarFrequencia() }

    class BaseController { +responder() +tratarErro() }
    BaseController <|-- CrudController
    BaseController <|-- MatriculaController
    CrudController <|-- AlunoController
    CrudController <|-- VoluntarioController
    CrudController <|-- TurmaController

    class DomainError { +statusHttp }
    DomainError <|-- ValidationError
    DomainError <|-- NotFoundError
    DomainError <|-- BusinessRuleError
```

## 3. Conceitos de POO aplicados

| Conceito | Onde |
|---|---|
| **Encapsulamento** | Cada entidade valida o próprio estado no construtor e expõe comportamentos (`Matricula.cancelar()`, `registrarFrequencia()`) em vez de deixar o service alterar campos soltos. |
| **Herança** | `Entidade`, `BaseRepository`, `CrudService`, `BaseController/CrudController` e `DomainError` concentram o código comum. Na 1ª entrega esse código existia só para `Aluno`; replicá-lo para 4 coleções teria gerado muita duplicação. |
| **Polimorfismo** | `Entidade.fromDocument` usa `new this(...)` e cria o tipo certo para cada subclasse. `Aluno.fromDocument` sobrescreve o método para aceitar o formato da v1. `Matricula.toJSON` acrescenta o percentual de frequência. Cada `DomainError` carrega seu `statusHttp`, então o `BaseController` trata qualquer erro sem `if` por tipo. |
| **Abstração** | `Entidade` é abstrata (não pode ser instanciada). Os services dependem só do "contrato" do repositório, não do MongoDB. |
| **Composição** | `Aluno` é composto por `Endereco` e uma lista de `Responsavel` (objetos de valor). |

## 4. Padrões de projeto

- **Repository**: isola o acesso ao MongoDB.
- **Template Method**: `CrudService` define o fluxo (`cadastrar`, `atualizar`, `remover`) e as subclasses preenchem os ganchos `validarRelacionamentos` e `antesDeRemover`.
- **Injeção de dependência + Composition Root** (`container.js`): um único ponto liga coleções, repositórios e services.
- **Value Object**: `Endereco` e `Responsavel`.

## 5. Decisões e limitações conhecidas

- **Atualização parcial (PUT)**: o service mescla os dados novos com o registro atual e **revalida a entidade inteira**, assim nenhuma atualização deixa o documento inválido. Listas (`responsaveis`, `horarios`) são substituídas por completo quando enviadas.
- **Concorrência na contagem de vagas**: a checagem "tem vaga?" e a inserção são duas operações. Em teoria, duas matrículas simultâneas na última vaga poderiam passar. Para a escala de uma ONG isso é aceitável. A duplicidade aluno+turma é garantida pelo índice único parcial, que vira **HTTP 409**. Numa evolução futura, a contagem poderia usar uma transação ou um contador atômico na turma.
- **Sem autenticação**: fora do escopo da PoC.
