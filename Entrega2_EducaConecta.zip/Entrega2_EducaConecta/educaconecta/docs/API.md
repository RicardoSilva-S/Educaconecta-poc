# Referência da API

Base: `http://localhost:3000`. Corpo e respostas em JSON. Todos os erros seguem o formato `{ "erro": "mensagem" }`.

| Status | Quando |
|---|---|
| 200 / 201 / 204 | Sucesso (consulta/atualização, criação, remoção) |
| 400 | Dados inválidos (`ValidationError`) ou JSON malformado |
| 404 | Registro ou rota inexistente (`NotFoundError`); ids mal formatados também caem aqui |
| 409 | Regra de negócio violada (`BusinessRuleError`) ou chave duplicada no banco |
| 413 | Corpo da requisição grande demais |
| 500 | Erro inesperado |

---

## Alunos — `/alunos`

**POST /alunos**
```json
{
  "nome": "Maria Silva",
  "idade": 10,
  "escola": "EM Joao Paulo II",
  "serie": "5o ano",
  "turno": "tarde",
  "endereco": { "rua": "Rua A", "numero": "100", "bairro": "Centro", "cidade": "Maringa", "estado": "PR", "cep": "87000-000" },
  "responsaveis": [
    { "nome": "Ana Silva", "parentesco": "mae", "telefone": "(44) 99999-8888", "principal": true }
  ]
}
```
| Campo | Regra |
|---|---|
| `nome`, `escola`, `serie` | obrigatórios |
| `idade` | inteiro de 4 a 18 |
| `turno` | `manha` \| `tarde` \| `noite` (turno disponível para o reforço) |
| `endereco` | opcional; `estado` = UF válida; `cep` com 8 dígitos; `numero` padrão `s/n` |
| `responsaveis` | ≥ 1 item; `parentesco` ∈ `mae, pai, avo, tio, irmao, tutor legal, outro`; telefone com 10 ou 11 dígitos; no máximo 1 `principal` |
| `ativo` | booleano, padrão `true` |

- **GET /alunos**: filtros `?ativos=true` e `?cidade=Maringa`
- **GET /alunos/:id**
- **PUT /alunos/:id**: atualização parcial, ex.: `{ "serie": "6o ano" }` ou `{ "ativo": false }`
- **DELETE /alunos/:id**: 409 se o aluno tiver matrícula ativa
- **GET /alunos/:id/matriculas**: matrículas do aluno

## Voluntários — `/voluntarios`

**POST /voluntarios**
```json
{ "nome": "Ana Pereira", "email": "ana@ong.org", "telefone": "44991112222", "disciplinas": ["Matematica", "Ciencias"] }
```
O e-mail é único (409 se repetido). As disciplinas são gravadas em minúsculas e sem repetição.
- **GET /voluntarios?disciplina=matematica**, **GET/PUT/DELETE /voluntarios/:id** (DELETE retorna 409 se o voluntário for responsável por alguma turma)

## Turmas — `/turmas`

**POST /turmas**
```json
{
  "nome": "Matematica Basica - Tarde",
  "disciplina": "matematica",
  "turno": "tarde",
  "capacidade": 3,
  "voluntarioId": "<_id do voluntario>",
  "horarios": [
    { "diaSemana": "seg", "inicio": "14:00", "fim": "15:30" },
    { "diaSemana": "qua", "inicio": "14:00", "fim": "15:30" }
  ]
}
```
| Campo | Regra |
|---|---|
| `capacidade` | inteiro de 1 a 40; na edição, não pode ser menor que o número de matriculados (409) |
| `voluntarioId` | voluntário existente (404), ativo e que lecione a disciplina (409) |
| `horarios` | ≥ 1; `diaSemana` ∈ `seg..sab`, sem repetir o dia; `inicio` < `fim` (HH:MM) |

- **GET /turmas?turno=tarde&disciplina=matematica**
- **GET /turmas/vagas?turno=tarde**: relatório de vagas
  ```json
  [{ "turmaId": "...", "nome": "Matematica Basica - Tarde", "disciplina": "matematica",
     "turno": "tarde", "capacidade": 3, "matriculados": 3, "vagas": 0 }]
  ```
- **GET /turmas/:id/alunos**
  ```json
  [{ "matriculaId": "...", "alunoId": "...", "nome": "Maria Silva", "idade": 10, "serie": "5o ano",
     "aulasRegistradas": 2, "presencas": 2 }]
  ```
- **GET/PUT/DELETE /turmas/:id** (DELETE retorna 409 se houver matrícula ativa)

## Matrículas — `/matriculas`

**POST /matriculas** `{ "alunoId": "...", "turmaId": "..." }`

Regras (409 quando violadas): aluno ativo, turma ativa, mesmo turno, sem matrícula ativa repetida, turma com vaga.

Resposta:
```json
{ "_id": "...", "alunoId": "...", "turmaId": "...", "status": "ativa",
  "dataMatricula": "2026-11-11T12:00:00.000Z", "dataCancelamento": null,
  "frequencias": [], "percentualFrequencia": null }
```
- **GET /matriculas?alunoId=&turmaId=&status=ativa**
- **GET /matriculas/:id**
- **PATCH /matriculas/:id/cancelar**: libera a vaga (409 se já estiver cancelada)
- **POST /matriculas/:id/frequencias** `{ "data": "2026-11-02", "presente": true }`: 201. Retorna 409 se já houver registro nessa data ou se a matrícula estiver cancelada.
