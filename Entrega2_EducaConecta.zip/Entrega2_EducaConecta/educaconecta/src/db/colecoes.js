/** Nomes das colecoes do banco (fonte unica, usada pelo container, indices e scripts). */
const COLECOES = Object.freeze({
  alunos: 'alunos',
  voluntarios: 'voluntarios',
  turmas: 'turmas',
  matriculas: 'matriculas',
});

module.exports = COLECOES;
