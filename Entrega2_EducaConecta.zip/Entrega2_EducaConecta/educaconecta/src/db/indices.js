const COLECOES = require('./colecoes');

/**
 * Indices e validacao de esquema ($jsonSchema) das colecoes.
 * Executado na inicializacao (idempotente: pode rodar varias vezes).
 */
const INDICES = [
  { colecao: COLECOES.alunos, chave: { ativo: 1, turno: 1 } },
  { colecao: COLECOES.alunos, chave: { 'endereco.cidade': 1 } },
  { colecao: COLECOES.voluntarios, chave: { email: 1 }, opcoes: { unique: true } },
  { colecao: COLECOES.turmas, chave: { turno: 1, disciplina: 1 } },
  { colecao: COLECOES.turmas, chave: { voluntarioId: 1 } },
  { colecao: COLECOES.matriculas, chave: { turmaId: 1, status: 1 } },
  {
    // impede (no proprio banco) duas matriculas ATIVAS do mesmo aluno na mesma turma
    colecao: COLECOES.matriculas,
    chave: { alunoId: 1, turmaId: 1 },
    opcoes: { unique: true, partialFilterExpression: { status: 'ativa' }, name: 'matricula_ativa_unica' },
  },
];

const VALIDADORES = {
  [COLECOES.alunos]: {
    $jsonSchema: {
      bsonType: 'object',
      required: ['nome', 'idade', 'turno', 'responsaveis', 'ativo'],
      properties: {
        idade: { bsonType: ['int', 'long', 'double'], minimum: 4, maximum: 18 },
        turno: { enum: ['manha', 'tarde', 'noite'] },
        endereco: { bsonType: ['object', 'null'] },
        responsaveis: { bsonType: 'array', minItems: 1 },
      },
    },
  },
  [COLECOES.turmas]: {
    $jsonSchema: {
      bsonType: 'object',
      required: ['nome', 'turno', 'capacidade', 'voluntarioId', 'horarios'],
      properties: {
        voluntarioId: { bsonType: 'objectId' },
        horarios: { bsonType: 'array', minItems: 1 },
      },
    },
  },
  [COLECOES.matriculas]: {
    $jsonSchema: {
      bsonType: 'object',
      required: ['alunoId', 'turmaId', 'status', 'frequencias'],
      properties: {
        alunoId: { bsonType: 'objectId' },
        turmaId: { bsonType: 'objectId' },
        status: { enum: ['ativa', 'cancelada'] },
        frequencias: { bsonType: 'array' },
      },
    },
  },
};

async function aplicarValidador(db, colecao, validator) {
  const existentes = await db.listCollections({ name: colecao }).toArray();
  if (existentes.length === 0) {
    await db.createCollection(colecao, { validator });
  } else {
    await db.command({ collMod: colecao, validator });
  }
}

async function criarIndices(db) {
  for (const [colecao, validator] of Object.entries(VALIDADORES)) {
    await aplicarValidador(db, colecao, validator);
  }
  for (const { colecao, chave, opcoes = {} } of INDICES) {
    await db.collection(colecao).createIndex(chave, opcoes);
  }
}

module.exports = { criarIndices, INDICES, VALIDADORES };
