const CrudController = require('./crudController');

class AlunoController extends CrudController {
  constructor(alunoService, matriculaService) {
    super(alunoService);
    this.matriculaService = matriculaService;
  }

  filtrosDaQuery(query) {
    return { apenasAtivos: query.ativos === 'true', cidade: query.cidade };
  }

  listarMatriculas(req, res) {
    return this.responder(res, 200, () => this.matriculaService.listarDoAluno(req.params.id));
  }
}

module.exports = AlunoController;
