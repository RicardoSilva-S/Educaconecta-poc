const CrudController = require('./crudController');

class TurmaController extends CrudController {
  filtrosDaQuery(query) {
    return { turno: query.turno, disciplina: query.disciplina };
  }

  relatorioVagas(req, res) {
    return this.responder(res, 200, () => this.service.relatorioVagas({ turno: req.query.turno }));
  }

  listarAlunos(req, res) {
    return this.responder(res, 200, () => this.service.listarAlunos(req.params.id));
  }
}

module.exports = TurmaController;
