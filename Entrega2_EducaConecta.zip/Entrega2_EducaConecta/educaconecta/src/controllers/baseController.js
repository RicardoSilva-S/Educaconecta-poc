const { DomainError } = require('../errors/DomainError');

const CODIGO_CHAVE_DUPLICADA = 11000;

/**
 * Base de todos os controllers: traduz HTTP <-> service.
 *
 * - Faz o "bind" automatico dos metodos, para poderem ser passados direto ao
 *   Express (router.get('/', controller.listar)).
 * - Centraliza o tratamento de erros: qualquer DomainError ja sabe seu status
 *   HTTP (polimorfismo), entao nao ha um "if instanceof" por entidade.
 */
class BaseController {
  constructor() {
    let prototipo = Object.getPrototypeOf(this);
    while (prototipo && prototipo !== Object.prototype) {
      for (const nome of Object.getOwnPropertyNames(prototipo)) {
        if (nome !== 'constructor' && typeof this[nome] === 'function' && !Object.hasOwn(this, nome)) {
          this[nome] = this[nome].bind(this);
        }
      }
      prototipo = Object.getPrototypeOf(prototipo);
    }
  }

  /** Executa a acao e responde com o status informado, tratando erros. */
  async responder(res, status, acao) {
    try {
      const resultado = await acao();
      return status === 204 ? res.status(204).send() : res.status(status).json(resultado);
    } catch (erro) {
      return this.tratarErro(erro, res);
    }
  }

  tratarErro(erro, res) {
    if (erro instanceof DomainError) {
      return res.status(erro.statusHttp).json({ erro: erro.message });
    }
    if (erro && erro.code === CODIGO_CHAVE_DUPLICADA) {
      // violacao de indice unico no MongoDB (ex.: duas requisicoes simultaneas)
      return res.status(409).json({ erro: 'Registro duplicado: ja existe um registro com esses dados.' });
    }
    return res.status(500).json({ erro: 'Erro interno do servidor.' });
  }
}

module.exports = BaseController;
