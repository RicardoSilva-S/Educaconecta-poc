const CrudController = require('./crudController');

class VoluntarioController extends CrudController {
  filtrosDaQuery(query) {
    return { disciplina: query.disciplina };
  }
}

module.exports = VoluntarioController;
