const BaseController = require('./baseController');

class MatriculaController extends BaseController {
  constructor(matriculaService) {
    super();
    this.service = matriculaService;
  }

  matricular(req, res) {
    return this.responder(res, 201, () => this.service.matricular(req.body));
  }

  listar(req, res) {
    const { alunoId, turmaId, status } = req.query;
    return this.responder(res, 200, () => this.service.listar({ alunoId, turmaId, status }));
  }

  buscar(req, res) {
    return this.responder(res, 200, () => this.service.buscar(req.params.id));
  }

  cancelar(req, res) {
    return this.responder(res, 200, () => this.service.cancelar(req.params.id));
  }

  registrarFrequencia(req, res) {
    return this.responder(res, 201, () => this.service.registrarFrequencia(req.params.id, req.body));
  }
}

module.exports = MatriculaController;
