const BaseController = require('./baseController');

/**
 * Controller generico para recursos com CRUD completo.
 * Recebe qualquer service que siga o contrato do CrudService.
 * As subclasses so precisam dizer como ler os filtros da query string.
 */
class CrudController extends BaseController {
  constructor(service) {
    super();
    this.service = service;
  }

  /* istanbul ignore next -- sobrescrito pelas subclasses */
  filtrosDaQuery() {
    return {};
  }

  criar(req, res) {
    return this.responder(res, 201, () => this.service.cadastrar(req.body));
  }

  listar(req, res) {
    return this.responder(res, 200, () => this.service.listar(this.filtrosDaQuery(req.query)));
  }

  buscar(req, res) {
    return this.responder(res, 200, () => this.service.buscar(req.params.id));
  }

  atualizar(req, res) {
    return this.responder(res, 200, () => this.service.atualizar(req.params.id, req.body));
  }

  remover(req, res) {
    return this.responder(res, 204, () => this.service.remover(req.params.id));
  }
}

module.exports = CrudController;
