const { NotFoundError } = require('../errors/DomainError');

/**
 * Service base com o fluxo CRUD comum (Template Method).
 *
 * As subclasses podem sobrescrever os "ganchos" para incluir regras de negocio
 * especificas sem reescrever o fluxo inteiro:
 *  - validarRelacionamentos(entidade, idAtual): checa referencias/unicidade;
 *  - antesDeRemover(entidade): bloqueia ou prepara a exclusao.
 */
class CrudService {
  constructor(repository, ClasseEntidade, nomeEntidade) {
    this.repository = repository;
    this.ClasseEntidade = ClasseEntidade;
    this.nomeEntidade = nomeEntidade;
  }

  async cadastrar(dados) {
    const entidade = new this.ClasseEntidade(dados);
    await this.validarRelacionamentos(entidade, null);
    return this.repository.criar(entidade);
  }

  async listar(filtros = {}) {
    return this.repository.listarTodos(filtros);
  }

  async buscar(id) {
    const entidade = await this.repository.buscarPorId(id);
    if (!entidade) {
      throw new NotFoundError(this.nomeEntidade, id);
    }
    return entidade;
  }

  /** Atualizacao parcial: mescla os dados novos e revalida a entidade inteira. */
  async atualizar(id, dadosParciais) {
    const existente = await this.buscar(id);
    const { _id, ...semId } = dadosParciais || {};
    const entidade = new this.ClasseEntidade({ ...existente.toDocument(), ...semId });
    await this.validarRelacionamentos(entidade, id);

    const atualizada = await this.repository.atualizar(id, entidade);
    if (!atualizada) {
      throw new NotFoundError(this.nomeEntidade, id);
    }
    return atualizada;
  }

  async remover(id) {
    const entidade = await this.buscar(id);
    await this.antesDeRemover(entidade);
    const removido = await this.repository.remover(id);
    if (!removido) {
      throw new NotFoundError(this.nomeEntidade, id);
    }
    return true;
  }

  // ---- ganchos (implementacao padrao: nao faz nada) ----

  // eslint-disable-next-line no-unused-vars
  async validarRelacionamentos(entidade, idAtual) {}

  // eslint-disable-next-line no-unused-vars
  async antesDeRemover(entidade) {}
}

module.exports = CrudService;
