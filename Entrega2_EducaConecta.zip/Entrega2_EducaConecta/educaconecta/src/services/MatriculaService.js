const { Matricula } = require('../models/Matricula');
const { BusinessRuleError, NotFoundError } = require('../errors/DomainError');

/**
 * Regras de negocio da matricula de alunos em turmas.
 * Coordena tres repositorios (alunos, turmas, matriculas).
 */
class MatriculaService {
  constructor(matriculaRepository, alunoRepository, turmaRepository) {
    this.matriculaRepository = matriculaRepository;
    this.alunoRepository = alunoRepository;
    this.turmaRepository = turmaRepository;
  }

  async matricular({ alunoId, turmaId } = {}) {
    const matricula = new Matricula({ alunoId, turmaId });

    const aluno = await this.alunoRepository.buscarPorId(matricula.alunoId);
    if (!aluno) throw new NotFoundError('Aluno', matricula.alunoId);
    if (!aluno.ativo) throw new BusinessRuleError('Aluno inativo nao pode ser matriculado.');

    const turma = await this.turmaRepository.buscarPorId(matricula.turmaId);
    if (!turma) throw new NotFoundError('Turma', matricula.turmaId);
    if (!turma.ativa) throw new BusinessRuleError('Turma inativa nao aceita matriculas.');

    if (aluno.turno !== turma.turno) {
      throw new BusinessRuleError(
        `Aluno disponivel no turno "${aluno.turno}", mas a turma e do turno "${turma.turno}".`
      );
    }
    if (await this.matriculaRepository.existeAtiva(aluno._id, turma._id)) {
      throw new BusinessRuleError('Aluno ja esta matriculado nesta turma.');
    }
    const matriculados = await this.matriculaRepository.contarAtivasDaTurma(turma._id);
    if (turma.vagasDisponiveis(matriculados) === 0) {
      throw new BusinessRuleError(`Turma ${turma.nome} sem vagas (capacidade ${turma.capacidade}).`);
    }

    return this.matriculaRepository.criar(matricula);
  }

  async listar(filtros = {}) {
    return this.matriculaRepository.listarTodas(filtros);
  }

  async buscar(id) {
    const matricula = await this.matriculaRepository.buscarPorId(id);
    if (!matricula) throw new NotFoundError('Matricula', id);
    return matricula;
  }

  async listarDoAluno(alunoId) {
    const aluno = await this.alunoRepository.buscarPorId(alunoId);
    if (!aluno) throw new NotFoundError('Aluno', alunoId);
    return this.matriculaRepository.listarTodas({ alunoId: aluno._id });
  }

  async cancelar(id) {
    const matricula = await this.buscar(id);
    matricula.cancelar();
    return this.matriculaRepository.atualizar(id, matricula);
  }

  async registrarFrequencia(id, dadosFrequencia) {
    const matricula = await this.buscar(id);
    matricula.registrarFrequencia(dadosFrequencia || {});
    return this.matriculaRepository.atualizar(id, matricula);
  }
}

module.exports = MatriculaService;
