const CrudService = require('./CrudService');
const Voluntario = require('../models/Voluntario');
const { BusinessRuleError } = require('../errors/DomainError');

/** Regras de negocio do cadastro de voluntarios. */
class VoluntarioService extends CrudService {
  constructor(voluntarioRepository, turmaRepository) {
    super(voluntarioRepository, Voluntario, 'Voluntario');
    this.turmaRepository = turmaRepository;
  }

  /** E-mail unico entre voluntarios. */
  async validarRelacionamentos(voluntario, idAtual) {
    const comMesmoEmail = await this.repository.buscarPorEmail(voluntario.email);
    if (comMesmoEmail && comMesmoEmail._id !== idAtual) {
      throw new BusinessRuleError(`Ja existe voluntario cadastrado com o e-mail ${voluntario.email}.`);
    }
  }

  /** Nao permite excluir voluntario que ainda e responsavel por alguma turma. */
  async antesDeRemover(voluntario) {
    if (await this.turmaRepository.existe({ voluntarioId: voluntario._id })) {
      throw new BusinessRuleError('Voluntario e responsavel por turma(s). Troque o responsavel antes de remover.');
    }
  }
}

module.exports = VoluntarioService;
