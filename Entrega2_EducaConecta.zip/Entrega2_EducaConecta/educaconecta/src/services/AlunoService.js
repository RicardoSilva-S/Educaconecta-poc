const CrudService = require('./CrudService');
const { Aluno } = require('../models/Aluno');
const { BusinessRuleError } = require('../errors/DomainError');

/** Regras de negocio do cadastro de alunos. */
class AlunoService extends CrudService {
  constructor(alunoRepository, matriculaRepository) {
    super(alunoRepository, Aluno, 'Aluno');
    this.matriculaRepository = matriculaRepository;
  }

  async inativar(id) {
    return this.atualizar(id, { ativo: false });
  }

  /** Nao permite excluir aluno com matricula ativa (integridade entre colecoes). */
  async antesDeRemover(aluno) {
    if (await this.matriculaRepository.existeAtivaDoAluno(aluno._id)) {
      throw new BusinessRuleError('Aluno possui matricula ativa. Cancele as matriculas antes de remover.');
    }
    await this.matriculaRepository.removerHistorico({ alunoId: aluno._id });
  }
}

module.exports = AlunoService;
