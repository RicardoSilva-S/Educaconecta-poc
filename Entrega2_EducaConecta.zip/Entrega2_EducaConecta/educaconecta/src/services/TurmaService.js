const CrudService = require('./CrudService');
const { Turma } = require('../models/Turma');
const { BusinessRuleError, NotFoundError } = require('../errors/DomainError');

/** Regras de negocio das turmas de reforco. */
class TurmaService extends CrudService {
  constructor(turmaRepository, voluntarioRepository, matriculaRepository) {
    super(turmaRepository, Turma, 'Turma');
    this.voluntarioRepository = voluntarioRepository;
    this.matriculaRepository = matriculaRepository;
  }

  /**
   * - o voluntario referenciado deve existir, estar ativo e lecionar a disciplina;
   * - na edicao, a capacidade nao pode ficar abaixo do numero de matriculados.
   */
  async validarRelacionamentos(turma, idAtual) {
    const voluntario = await this.voluntarioRepository.buscarPorId(turma.voluntarioId);
    if (!voluntario) {
      throw new NotFoundError('Voluntario', turma.voluntarioId);
    }
    if (!voluntario.ativo) {
      throw new BusinessRuleError('O voluntario informado esta inativo.');
    }
    if (!voluntario.podeLecionar(turma.disciplina)) {
      throw new BusinessRuleError(`O voluntario ${voluntario.nome} nao leciona ${turma.disciplina}.`);
    }

    if (idAtual) {
      const matriculados = await this.matriculaRepository.contarAtivasDaTurma(idAtual);
      if (turma.capacidade < matriculados) {
        throw new BusinessRuleError(
          `Capacidade (${turma.capacidade}) menor que o numero de alunos matriculados (${matriculados}).`
        );
      }
    }
  }

  async antesDeRemover(turma) {
    if (await this.matriculaRepository.existeAtivaDaTurma(turma._id)) {
      throw new BusinessRuleError('Turma possui alunos matriculados. Cancele as matriculas antes de remover.');
    }
    await this.matriculaRepository.removerHistorico({ turmaId: turma._id });
  }

  async relatorioVagas(filtros = {}) {
    return this.repository.relatorioVagas(filtros);
  }

  async listarAlunos(turmaId) {
    await this.buscar(turmaId);
    return this.matriculaRepository.listarAlunosDaTurma(turmaId);
  }
}

module.exports = TurmaService;
