const AlunoRepository = require('./repositories/AlunoRepository');
const VoluntarioRepository = require('./repositories/VoluntarioRepository');
const TurmaRepository = require('./repositories/TurmaRepository');
const MatriculaRepository = require('./repositories/MatriculaRepository');
const AlunoService = require('./services/AlunoService');
const VoluntarioService = require('./services/VoluntarioService');
const TurmaService = require('./services/TurmaService');
const MatriculaService = require('./services/MatriculaService');
const COLECOES = require('./db/colecoes');


/**
 * Composition root: o unico lugar que sabe como ligar colecoes,
 * repositorios e services. Recebe um "db" do driver do MongoDB.
 */
function criarContainer(db) {
  const repositorios = {
    alunoRepository: new AlunoRepository(db.collection(COLECOES.alunos)),
    voluntarioRepository: new VoluntarioRepository(db.collection(COLECOES.voluntarios)),
    turmaRepository: new TurmaRepository(db.collection(COLECOES.turmas), {
      colecaoMatriculas: COLECOES.matriculas,
    }),
    matriculaRepository: new MatriculaRepository(db.collection(COLECOES.matriculas), {
      colecaoAlunos: COLECOES.alunos,
    }),
  };
  const { alunoRepository, voluntarioRepository, turmaRepository, matriculaRepository } = repositorios;

  const services = {
    alunoService: new AlunoService(alunoRepository, matriculaRepository),
    voluntarioService: new VoluntarioService(voluntarioRepository, turmaRepository),
    turmaService: new TurmaService(turmaRepository, voluntarioRepository, matriculaRepository),
    matriculaService: new MatriculaService(matriculaRepository, alunoRepository, turmaRepository),
  };

  return { repositorios, services };
}

module.exports = { criarContainer, COLECOES };
