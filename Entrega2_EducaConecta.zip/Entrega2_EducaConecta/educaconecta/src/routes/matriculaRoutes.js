const express = require('express');

function criarMatriculaRoutes(matriculaController) {
  const router = express.Router();

  router.post('/', matriculaController.matricular);
  router.get('/', matriculaController.listar);
  router.get('/:id', matriculaController.buscar);
  router.patch('/:id/cancelar', matriculaController.cancelar);
  router.post('/:id/frequencias', matriculaController.registrarFrequencia);

  return router;
}

module.exports = criarMatriculaRoutes;
