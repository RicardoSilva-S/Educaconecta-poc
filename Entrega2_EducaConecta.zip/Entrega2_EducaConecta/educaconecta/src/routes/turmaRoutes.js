const criarCrudRoutes = require('./crudRoutes');

function criarTurmaRoutes(turmaController) {
  return criarCrudRoutes(turmaController, (router) => {
    router.get('/vagas', turmaController.relatorioVagas);
    router.get('/:id/alunos', turmaController.listarAlunos);
  });
}

module.exports = criarTurmaRoutes;
