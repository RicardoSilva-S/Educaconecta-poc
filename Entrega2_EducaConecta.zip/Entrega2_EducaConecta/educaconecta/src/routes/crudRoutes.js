const express = require('express');

/**
 * Cria um Router com as 5 rotas CRUD padrao.
 * "extras" recebe o router antes das rotas com ":id", para que rotas fixas
 * (ex.: /turmas/vagas) nao sejam confundidas com um id.
 */
function criarCrudRoutes(controller, extras = () => {}) {
  const router = express.Router();
  extras(router);

  router.post('/', controller.criar);
  router.get('/', controller.listar);
  router.get('/:id', controller.buscar);
  router.put('/:id', controller.atualizar);
  router.delete('/:id', controller.remover);

  return router;
}

module.exports = criarCrudRoutes;
