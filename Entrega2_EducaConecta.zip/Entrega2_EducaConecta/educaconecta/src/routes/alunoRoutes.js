const criarCrudRoutes = require('./crudRoutes');

function criarAlunoRoutes(alunoController) {
  return criarCrudRoutes(alunoController, (router) => {
    router.get('/:id/matriculas', alunoController.listarMatriculas);
  });
}

module.exports = criarAlunoRoutes;
