require('dotenv').config();
const { conectar } = require('./db/database');
const { criarIndices } = require('./db/indices');
const { criarContainer } = require('./container');
const criarApp = require('./app');

const PORT = process.env.PORT || 3000;

async function iniciar() {
  const db = await conectar();
  await criarIndices(db);

  const { services } = criarContainer(db);
  const app = criarApp(services);

  app.listen(PORT, () => {
    console.log(`EducaConecta v2 rodando em http://localhost:${PORT}`);
  });
}

iniciar().catch((erro) => {
  console.error('Falha ao iniciar a aplicacao:', erro);
  process.exit(1);
});
