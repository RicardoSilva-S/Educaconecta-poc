const Validador = require('../validation/Validador');
const { ValidationError } = require('../errors/DomainError');

const UFS = [
  'AC', 'AL', 'AP', 'AM', 'BA', 'CE', 'DF', 'ES', 'GO', 'MA', 'MT', 'MS', 'MG', 'PA',
  'PB', 'PR', 'PE', 'PI', 'RJ', 'RN', 'RS', 'RO', 'RR', 'SC', 'SP', 'SE', 'TO',
];

/**
 * Objeto de valor (value object) embutido no documento do aluno.
 * Nao tem _id proprio: so existe dentro de um Aluno.
 */
class Endereco {
  constructor({ rua, numero, bairro, cidade, estado, cep } = {}) {
    this.rua = Validador.textoObrigatorio(rua, 'Rua');
    this.numero = numero === undefined || numero === null ? 's/n' : String(numero).trim() || 's/n';
    this.bairro = Validador.textoObrigatorio(bairro, 'Bairro');
    this.cidade = Validador.textoObrigatorio(cidade, 'Cidade');
    this.estado = Validador.umDe(typeof estado === 'string' ? estado.trim().toUpperCase() : estado, UFS, 'Estado');
    this.cep = Endereco.validarCep(cep);
  }

  static validarCep(cep) {
    const digitos = typeof cep === 'string' ? cep.replace(/\D/g, '') : '';
    if (digitos.length !== 8) {
      throw new ValidationError('CEP deve conter 8 digitos.');
    }
    return digitos;
  }

  toDocument() {
    return {
      rua: this.rua,
      numero: this.numero,
      bairro: this.bairro,
      cidade: this.cidade,
      estado: this.estado,
      cep: this.cep,
    };
  }
}

module.exports = { Endereco, UFS };
