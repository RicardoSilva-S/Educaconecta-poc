const Validador = require('../validation/Validador');

const PARENTESCOS = ['mae', 'pai', 'avo', 'tio', 'irmao', 'tutor legal', 'outro'];

/**
 * Subdocumento da lista "responsaveis" do aluno.
 * Na 1a entrega o aluno tinha apenas os campos planos "responsavel" e "telefone";
 * agora um aluno pode ter varios responsaveis, um deles marcado como principal.
 */
class Responsavel {
  constructor({ nome, parentesco = 'outro', telefone, principal = false } = {}) {
    this.nome = Validador.textoObrigatorio(nome, 'Nome do responsavel');
    this.parentesco = Validador.umDe(parentesco, PARENTESCOS, 'Parentesco');
    this.telefone = Validador.telefone(telefone, 'Telefone do responsavel');
    this.principal = Validador.booleano(principal, 'Principal');
  }

  toDocument() {
    return {
      nome: this.nome,
      parentesco: this.parentesco,
      telefone: this.telefone,
      principal: this.principal,
    };
  }
}

module.exports = { Responsavel, PARENTESCOS };
