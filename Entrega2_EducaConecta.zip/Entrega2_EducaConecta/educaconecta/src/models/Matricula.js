const Entidade = require('./Entidade');
const Validador = require('../validation/Validador');
const { BusinessRuleError } = require('../errors/DomainError');

const STATUS = { ATIVA: 'ativa', CANCELADA: 'cancelada' };

/**
 * Relacionamento N:N entre Aluno e Turma.
 *  - alunoId -> colecao alunos; turmaId -> colecao turmas;
 *  - "frequencias" e uma lista de subdocumentos ({ data, presente }),
 *    embutida porque so faz sentido dentro da matricula e e lida junto com ela.
 */
class Matricula extends Entidade {
  constructor({
    alunoId,
    turmaId,
    status = STATUS.ATIVA,
    dataMatricula = new Date(),
    dataCancelamento = null,
    frequencias = [],
  } = {}) {
    super();
    this.alunoId = Validador.idObrigatorio(alunoId, 'Aluno');
    this.turmaId = Validador.idObrigatorio(turmaId, 'Turma');
    this.status = Validador.umDe(status, Object.values(STATUS), 'Status');
    this.dataMatricula = new Date(dataMatricula);
    this.dataCancelamento = dataCancelamento ? new Date(dataCancelamento) : null;
    this.frequencias = (frequencias || []).map((f) => Matricula.criarFrequencia(f));
  }

  static criarFrequencia({ data, presente } = {}) {
    return {
      data: Validador.data(data, 'Data da aula'),
      presente: Validador.booleano(presente, 'Presente'),
    };
  }

  get ativa() {
    return this.status === STATUS.ATIVA;
  }

  cancelar(data = new Date()) {
    if (!this.ativa) {
      throw new BusinessRuleError('A matricula ja esta cancelada.');
    }
    this.status = STATUS.CANCELADA;
    this.dataCancelamento = new Date(data);
  }

  registrarFrequencia(dados) {
    if (!this.ativa) {
      throw new BusinessRuleError('Nao e possivel registrar frequencia em matricula cancelada.');
    }
    const frequencia = Matricula.criarFrequencia(dados);
    if (this.frequencias.some((f) => f.data === frequencia.data)) {
      throw new BusinessRuleError(`Ja existe frequencia registrada para ${frequencia.data}.`);
    }
    this.frequencias.push(frequencia);
    this.frequencias.sort((a, b) => a.data.localeCompare(b.data));
    return frequencia;
  }

  /** Percentual de presenca (0-100), com uma casa decimal. */
  percentualFrequencia() {
    if (this.frequencias.length === 0) return null;
    const presencas = this.frequencias.filter((f) => f.presente).length;
    return Math.round((presencas / this.frequencias.length) * 1000) / 10;
  }

  toDocument() {
    return {
      alunoId: this.alunoId,
      turmaId: this.turmaId,
      status: this.status,
      dataMatricula: this.dataMatricula,
      dataCancelamento: this.dataCancelamento,
      frequencias: this.frequencias.map((f) => ({ ...f })),
    };
  }

  toJSON() {
    return { ...super.toJSON(), percentualFrequencia: this.percentualFrequencia() };
  }
}

module.exports = { Matricula, STATUS };
