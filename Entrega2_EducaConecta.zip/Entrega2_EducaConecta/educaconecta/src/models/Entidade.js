/**
 * Classe base (abstrata) de todas as entidades persistidas.
 *
 * Define o contrato usado pelo BaseRepository e pelo CrudService:
 *  - toDocument(): converte a entidade no documento salvo no MongoDB;
 *  - static fromDocument(doc): reconstroi a entidade a partir do banco;
 *  - toJSON(): formato devolvido pela API (documento + _id).
 */
class Entidade {
  constructor() {
    if (new.target === Entidade) {
      throw new TypeError('Entidade e abstrata e nao pode ser instanciada diretamente.');
    }
    this._id = undefined;
  }

  /* istanbul ignore next -- metodo abstrato, sempre sobrescrito */
  toDocument() {
    throw new Error('toDocument() deve ser implementado pela subclasse.');
  }

  toJSON() {
    return { _id: this._id, ...this.toDocument() };
  }

  /** Atribui o _id vindo do banco e devolve a propria entidade. */
  comId(id) {
    this._id = id;
    return this;
  }

  /**
   * Cria a entidade a partir de um documento do banco.
   * Usa "this" (a subclasse que chamou) para instanciar o tipo correto.
   */
  static fromDocument(doc) {
    const { _id, ...dados } = doc;
    return new this(dados).comId(_id);
  }
}

module.exports = Entidade;
