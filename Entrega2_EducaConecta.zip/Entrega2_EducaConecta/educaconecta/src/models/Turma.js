const Entidade = require('./Entidade');
const Validador = require('../validation/Validador');
const { ValidationError } = require('../errors/DomainError');
const { TURNOS_VALIDOS } = require('./Aluno');

const DIAS_SEMANA = ['seg', 'ter', 'qua', 'qui', 'sex', 'sab'];
const CAPACIDADE_MAXIMA = 40;

/**
 * Turma de reforco escolar.
 *  - referencia o voluntario responsavel (voluntarioId -> colecao voluntarios);
 *  - contem a lista de subdocumentos "horarios" ({ diaSemana, inicio, fim }).
 */
class Turma extends Entidade {
  constructor({ nome, disciplina, turno, capacidade, voluntarioId, horarios, ativa = true } = {}) {
    super();
    this.nome = Validador.textoObrigatorio(nome, 'Nome da turma');
    this.disciplina = Validador.textoObrigatorio(disciplina, 'Disciplina').toLowerCase();
    this.turno = Validador.umDe(turno, TURNOS_VALIDOS, 'Turno');
    this.capacidade = Validador.inteiroEntre(capacidade, 1, CAPACIDADE_MAXIMA, 'Capacidade');
    this.voluntarioId = Validador.idObrigatorio(voluntarioId, 'Voluntario responsavel');
    this.horarios = Turma.criarHorarios(horarios);
    this.ativa = Validador.booleano(ativa, 'Ativa');
  }

  static criarHorarios(lista) {
    Validador.listaNaoVazia(lista, 'Horarios');
    const vistos = new Set();
    return lista.map((h = {}) => {
      const diaSemana = Validador.umDe(h.diaSemana, DIAS_SEMANA, 'Dia da semana');
      const inicio = Validador.horario(h.inicio, 'Horario de inicio');
      const fim = Validador.horario(h.fim, 'Horario de fim');
      if (inicio >= fim) {
        throw new ValidationError('Horario de inicio deve ser anterior ao horario de fim.');
      }
      if (vistos.has(diaSemana)) {
        throw new ValidationError(`Dia da semana repetido nos horarios: ${diaSemana}.`);
      }
      vistos.add(diaSemana);
      return { diaSemana, inicio, fim };
    });
  }

  vagasDisponiveis(matriculasAtivas) {
    return Math.max(this.capacidade - matriculasAtivas, 0);
  }

  toDocument() {
    return {
      nome: this.nome,
      disciplina: this.disciplina,
      turno: this.turno,
      capacidade: this.capacidade,
      voluntarioId: this.voluntarioId,
      horarios: this.horarios.map((h) => ({ ...h })),
      ativa: this.ativa,
    };
  }
}

module.exports = { Turma, DIAS_SEMANA, CAPACIDADE_MAXIMA };
