const Entidade = require('./Entidade');
const Validador = require('../validation/Validador');

/**
 * Voluntario (professor/tutor) que conduz turmas de reforco.
 * "disciplinas" e uma lista simples de strings embutida no documento.
 */
class Voluntario extends Entidade {
  constructor({ nome, email, telefone, disciplinas, ativo = true } = {}) {
    super();
    this.nome = Validador.textoObrigatorio(nome, 'Nome do voluntario');
    this.email = Validador.email(email);
    this.telefone = Validador.telefone(telefone);
    this.disciplinas = Voluntario.normalizarDisciplinas(disciplinas);
    this.ativo = Validador.booleano(ativo, 'Ativo');
  }

  static normalizarDisciplinas(lista) {
    Validador.listaNaoVazia(lista, 'Disciplinas');
    const normalizadas = lista.map((d) => Validador.textoObrigatorio(d, 'Disciplina').toLowerCase());
    return [...new Set(normalizadas)];
  }

  podeLecionar(disciplina) {
    return typeof disciplina === 'string' && this.disciplinas.includes(disciplina.trim().toLowerCase());
  }

  toDocument() {
    return {
      nome: this.nome,
      email: this.email,
      telefone: this.telefone,
      disciplinas: [...this.disciplinas],
      ativo: this.ativo,
    };
  }
}

module.exports = Voluntario;
