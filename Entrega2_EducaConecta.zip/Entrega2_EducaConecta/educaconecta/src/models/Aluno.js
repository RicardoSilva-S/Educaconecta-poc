const Entidade = require('./Entidade');
const { Endereco } = require('./Endereco');
const { Responsavel } = require('./Responsavel');
const Validador = require('../validation/Validador');
const { ValidationError } = require('../errors/DomainError');

const TURNOS_VALIDOS = ['manha', 'tarde', 'noite'];

/**
 * Aluno inscrito no programa de reforco escolar.
 *
 * Evolucao em relacao a 1a entrega:
 *  - "endereco" passa a ser um documento aninhado (objeto Endereco);
 *  - "responsaveis" passa a ser uma lista de subdocumentos (Responsavel),
 *    com exatamente um responsavel principal;
 *  - "turno" indica o turno em que o aluno esta disponivel para o reforco
 *    (contraturno escolar) e e usado na matricula em turmas.
 */
class Aluno extends Entidade {
  constructor({ nome, idade, escola, serie, turno, endereco = null, responsaveis, ativo = true } = {}) {
    super();
    this.nome = Validador.textoObrigatorio(nome, 'Nome do aluno');
    this.idade = Validador.inteiroEntre(idade, 4, 18, 'Idade');
    this.escola = Validador.textoObrigatorio(escola, 'Escola de origem');
    this.serie = Validador.textoObrigatorio(serie, 'Serie/ano escolar');
    this.turno = Validador.umDe(turno, TURNOS_VALIDOS, 'Turno');
    this.endereco = endereco ? new Endereco(endereco) : null;
    this.responsaveis = Aluno.criarResponsaveis(responsaveis);
    this.ativo = Validador.booleano(ativo, 'Ativo');
  }

  static criarResponsaveis(lista) {
    Validador.listaNaoVazia(lista, 'Responsaveis');
    const responsaveis = lista.map((dados) => new Responsavel(dados));

    const principais = responsaveis.filter((r) => r.principal).length;
    if (principais > 1) {
      throw new ValidationError('Apenas um responsavel pode ser marcado como principal.');
    }
    if (principais === 0) {
      responsaveis[0].principal = true;
    }
    return responsaveis;
  }

  get responsavelPrincipal() {
    return this.responsaveis.find((r) => r.principal);
  }

  inativar() {
    this.ativo = false;
  }

  ativar() {
    this.ativo = true;
  }

  toDocument() {
    return {
      nome: this.nome,
      idade: this.idade,
      escola: this.escola,
      serie: this.serie,
      turno: this.turno,
      endereco: this.endereco ? this.endereco.toDocument() : null,
      responsaveis: this.responsaveis.map((r) => r.toDocument()),
      ativo: this.ativo,
    };
  }

  /**
   * Aceita tambem documentos no formato da 1a entrega
   * ({ responsavel, telefone }) e os converte para a lista de responsaveis.
   */
  static fromDocument(doc) {
    if (!doc.responsaveis && doc.responsavel) {
      const { responsavel, telefone, ...resto } = doc;
      return super.fromDocument({
        ...resto,
        responsaveis: [{ nome: responsavel, telefone, parentesco: 'outro', principal: true }],
      });
    }
    return super.fromDocument(doc);
  }
}

module.exports = { Aluno, TURNOS_VALIDOS };
