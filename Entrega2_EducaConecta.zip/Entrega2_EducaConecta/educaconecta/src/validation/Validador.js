const { ValidationError } = require('../errors/DomainError');

/**
 * Regras de validacao reutilizadas por todas as entidades.
 * Centralizar aqui evita repetir o mesmo "if (!x || typeof x !== 'string' ...)"
 * em cada modelo (na 1a entrega essas regras ficavam duplicadas dentro de Aluno).
 */
class Validador {
  static textoObrigatorio(valor, campo) {
    if (typeof valor !== 'string' || !valor.trim()) {
      throw new ValidationError(`${campo} e obrigatorio.`);
    }
    return valor.trim();
  }

  static inteiroEntre(valor, min, max, campo) {
    if (!Number.isInteger(valor) || valor < min || valor > max) {
      throw new ValidationError(`${campo} deve ser um numero inteiro entre ${min} e ${max}.`);
    }
    return valor;
  }

  static umDe(valor, opcoes, campo) {
    if (!opcoes.includes(valor)) {
      throw new ValidationError(`${campo} deve ser um dos seguintes: ${opcoes.join(', ')}.`);
    }
    return valor;
  }

  static telefone(valor, campo = 'Telefone') {
    const digitos = typeof valor === 'string' ? valor.replace(/\D/g, '') : '';
    if (!/^\d{10,11}$/.test(digitos)) {
      throw new ValidationError(`${campo} deve conter 10 ou 11 digitos numericos.`);
    }
    return digitos;
  }

  static email(valor, campo = 'E-mail') {
    const texto = Validador.textoObrigatorio(valor, campo).toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(texto)) {
      throw new ValidationError(`${campo} invalido.`);
    }
    return texto;
  }

  static booleano(valor, campo) {
    if (typeof valor !== 'boolean') {
      throw new ValidationError(`${campo} deve ser verdadeiro ou falso.`);
    }
    return valor;
  }

  static listaNaoVazia(valor, campo) {
    if (!Array.isArray(valor) || valor.length === 0) {
      throw new ValidationError(`${campo} deve conter pelo menos um item.`);
    }
    return valor;
  }

  /** Formato HH:MM (00:00 a 23:59). */
  static horario(valor, campo) {
    if (typeof valor !== 'string' || !/^([01]\d|2[0-3]):[0-5]\d$/.test(valor)) {
      throw new ValidationError(`${campo} deve estar no formato HH:MM.`);
    }
    return valor;
  }

  /** Data no formato AAAA-MM-DD e existente no calendario. */
  static data(valor, campo) {
    if (typeof valor !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(valor)) {
      throw new ValidationError(`${campo} deve estar no formato AAAA-MM-DD.`);
    }
    const data = new Date(`${valor}T00:00:00Z`);
    if (Number.isNaN(data.getTime()) || data.toISOString().slice(0, 10) !== valor) {
      throw new ValidationError(`${campo} nao e uma data valida.`);
    }
    return valor;
  }

  static idObrigatorio(valor, campo) {
    if (valor === undefined || valor === null || String(valor).trim() === '') {
      throw new ValidationError(`${campo} e obrigatorio.`);
    }
    return String(valor);
  }
}

module.exports = Validador;
