/**
 * Hierarquia de erros de dominio.
 *
 * Cada subclasse carrega o status HTTP correspondente, o que permite ao
 * BaseController traduzir qualquer erro de negocio em resposta HTTP sem
 * uma cadeia de "if instanceof" por entidade (polimorfismo).
 */
class DomainError extends Error {
  constructor(message, statusHttp = 500) {
    super(message);
    this.name = this.constructor.name;
    this.statusHttp = statusHttp;
  }
}

/** Dados de entrada invalidos (400). */
class ValidationError extends DomainError {
  constructor(message) {
    super(message, 400);
  }
}

/** Recurso inexistente (404). */
class NotFoundError extends DomainError {
  constructor(entidade, id) {
    super(`${entidade} com id ${id} nao foi encontrado(a).`, 404);
    this.entidade = entidade;
  }
}

/** Operacao valida em formato, mas que viola uma regra de negocio (409). */
class BusinessRuleError extends DomainError {
  constructor(message) {
    super(message, 409);
  }
}

module.exports = { DomainError, ValidationError, NotFoundError, BusinessRuleError };
