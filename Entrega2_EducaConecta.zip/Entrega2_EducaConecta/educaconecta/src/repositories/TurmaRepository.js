const BaseRepository = require('./BaseRepository');
const { Turma } = require('../models/Turma');

/** Acesso a colecao "turmas". */
class TurmaRepository extends BaseRepository {
  constructor(collection, { colecaoMatriculas = 'matriculas' } = {}) {
    super(collection, Turma, { camposReferencia: ['voluntarioId'] });
    this.colecaoMatriculas = colecaoMatriculas;
  }

  async listarTodos({ turno, disciplina } = {}) {
    const filtro = {};
    if (turno) filtro.turno = turno;
    if (disciplina) filtro.disciplina = disciplina.toLowerCase();
    return this.listar(filtro);
  }

  /**
   * Relatorio de vagas por turma (agregacao com $lookup em "matriculas").
   * Resolve o problema original da ONG: saber quantas vagas restam por turno.
   */
  pipelineRelatorioVagas({ turno } = {}) {
    const filtro = { ativa: true };
    if (turno) filtro.turno = turno;
    return [
      { $match: filtro },
      {
        $lookup: {
          from: this.colecaoMatriculas,
          let: { idTurma: '$_id' },
          pipeline: [
            {
              $match: {
                $expr: { $and: [{ $eq: ['$turmaId', '$$idTurma'] }, { $eq: ['$status', 'ativa'] }] },
              },
            },
          ],
          as: 'matriculasAtivas',
        },
      },
      {
        $project: {
          _id: 0,
          turmaId: '$_id',
          nome: 1,
          disciplina: 1,
          turno: 1,
          capacidade: 1,
          matriculados: { $size: '$matriculasAtivas' },
        },
      },
      { $addFields: { vagas: { $max: [{ $subtract: ['$capacidade', '$matriculados'] }, 0] } } },
      { $sort: { turno: 1, nome: 1 } },
    ];
  }

  async relatorioVagas(filtros) {
    const linhas = await this.collection.aggregate(this.pipelineRelatorioVagas(filtros)).toArray();
    return linhas.map((linha) => ({ ...linha, turmaId: String(linha.turmaId) }));
  }
}

module.exports = TurmaRepository;
