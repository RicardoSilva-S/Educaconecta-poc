const BaseRepository = require('./BaseRepository');
const Voluntario = require('../models/Voluntario');

/** Acesso a colecao "voluntarios". */
class VoluntarioRepository extends BaseRepository {
  constructor(collection) {
    super(collection, Voluntario);
  }

  async buscarPorEmail(email) {
    const documento = await this.collection.findOne({ email: String(email).toLowerCase() });
    return documento ? this.paraEntidade(documento) : null;
  }

  async listarTodos({ disciplina } = {}) {
    // consulta em array de strings: casa se a lista contem o valor
    return this.listar(disciplina ? { disciplinas: disciplina.toLowerCase() } : {});
  }
}

module.exports = VoluntarioRepository;
