const BaseRepository = require('./BaseRepository');
const { Matricula, STATUS } = require('../models/Matricula');

/** Acesso a colecao "matriculas" (relacionamento aluno <-> turma). */
class MatriculaRepository extends BaseRepository {
  constructor(collection, { colecaoAlunos = 'alunos' } = {}) {
    super(collection, Matricula, { camposReferencia: ['alunoId', 'turmaId'] });
    this.colecaoAlunos = colecaoAlunos;
  }

  async listarTodas({ alunoId, turmaId, status } = {}) {
    const filtro = {};
    if (alunoId) filtro.alunoId = alunoId;
    if (turmaId) filtro.turmaId = turmaId;
    if (status) filtro.status = status;
    return this.listar(filtro);
  }

  async contarAtivasDaTurma(turmaId) {
    return this.contar({ turmaId, status: STATUS.ATIVA });
  }

  async existeAtivaDoAluno(alunoId) {
    return this.existe({ alunoId, status: STATUS.ATIVA });
  }

  async existeAtivaDaTurma(turmaId) {
    return this.existe({ turmaId, status: STATUS.ATIVA });
  }

  async existeAtiva(alunoId, turmaId) {
    return this.existe({ alunoId, turmaId, status: STATUS.ATIVA });
  }

  /**
   * Remove o historico de matriculas (ja canceladas) de um aluno ou turma
   * antes de exclui-lo, para nao deixar referencias orfas.
   * Ex.: removerHistorico({ alunoId }) ou removerHistorico({ turmaId }).
   */
  async removerHistorico(filtro) {
    const resultado = await this.collection.deleteMany(this.paraBanco(filtro));
    return resultado.deletedCount;
  }

  /**
   * Alunos de uma turma: $lookup em "alunos" + resumo de frequencia
   * calculado no proprio banco a partir da lista de subdocumentos.
   */
  pipelineAlunosDaTurma(turmaId) {
    return [
      { $match: this.paraBanco({ turmaId, status: STATUS.ATIVA }) },
      { $lookup: { from: this.colecaoAlunos, localField: 'alunoId', foreignField: '_id', as: 'aluno' } },
      { $unwind: '$aluno' },
      {
        $project: {
          _id: 0,
          matriculaId: '$_id',
          alunoId: '$aluno._id',
          nome: '$aluno.nome',
          idade: '$aluno.idade',
          serie: '$aluno.serie',
          aulasRegistradas: { $size: '$frequencias' },
          presencas: {
            $size: { $filter: { input: '$frequencias', as: 'f', cond: { $eq: ['$$f.presente', true] } } },
          },
        },
      },
      { $sort: { nome: 1 } },
    ];
  }

  async listarAlunosDaTurma(turmaId) {
    const linhas = await this.collection.aggregate(this.pipelineAlunosDaTurma(turmaId)).toArray();
    return linhas.map((linha) => ({
      ...linha,
      matriculaId: String(linha.matriculaId),
      alunoId: String(linha.alunoId),
    }));
  }
}

module.exports = MatriculaRepository;
