const BaseRepository = require('./BaseRepository');
const { Aluno } = require('../models/Aluno');

/** Acesso a colecao "alunos". */
class AlunoRepository extends BaseRepository {
  constructor(collection) {
    super(collection, Aluno);
  }

  async listarTodos({ apenasAtivos = false, cidade } = {}) {
    const filtro = {};
    if (apenasAtivos) filtro.ativo = true;
    // consulta em campo de documento aninhado (notacao de ponto)
    if (cidade) filtro['endereco.cidade'] = cidade;
    return this.listar(filtro);
  }
}

module.exports = AlunoRepository;
