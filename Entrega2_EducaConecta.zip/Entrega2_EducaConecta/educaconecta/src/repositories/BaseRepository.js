const { ObjectId } = require('mongodb');

/**
 * Repositorio generico sobre uma colecao do MongoDB.
 *
 * Concentra o CRUD comum a todas as colecoes (na 1a entrega ele existia apenas
 * para "alunos"). As subclasses informam:
 *  - a classe da entidade (para converter documento <-> objeto);
 *  - os campos que sao referencias a outras colecoes (camposReferencia),
 *    gravados como ObjectId no banco e expostos como string na aplicacao.
 *
 * A collection e recebida por injecao de dependencia, o que permite testar
 * sem um MongoDB real.
 */
class BaseRepository {
  constructor(collection, ClasseEntidade, { camposReferencia = [] } = {}) {
    if (!collection) {
      throw new Error(`${this.constructor.name} requer uma collection valida.`);
    }
    this.collection = collection;
    this.ClasseEntidade = ClasseEntidade;
    this.camposReferencia = camposReferencia;
  }

  /** Converte string/ObjectId em ObjectId; devolve null se o id for invalido. */
  static paraObjectId(id) {
    if (id instanceof ObjectId) return id;
    return typeof id === 'string' && ObjectId.isValid(id) && id.length === 24 ? new ObjectId(id) : null;
  }

  /** Objeto da aplicacao -> documento/filtro do banco (referencias viram ObjectId). */
  paraBanco(dados) {
    const convertido = { ...dados };
    for (const campo of this.camposReferencia) {
      if (typeof convertido[campo] === 'string') {
        convertido[campo] = BaseRepository.paraObjectId(convertido[campo]) || convertido[campo];
      }
    }
    return convertido;
  }

  /** Documento do banco -> entidade (ids viram string). */
  paraEntidade(documento) {
    const dados = { ...documento, _id: String(documento._id) };
    for (const campo of this.camposReferencia) {
      if (dados[campo] !== undefined && dados[campo] !== null) {
        dados[campo] = String(dados[campo]);
      }
    }
    return this.ClasseEntidade.fromDocument(dados);
  }

  async criar(entidade) {
    const resultado = await this.collection.insertOne(this.paraBanco(entidade.toDocument()));
    return entidade.comId(String(resultado.insertedId));
  }

  async listar(filtro = {}) {
    const documentos = await this.collection.find(this.paraBanco(filtro)).toArray();
    return documentos.map((doc) => this.paraEntidade(doc));
  }

  async buscarPorId(id) {
    const objectId = BaseRepository.paraObjectId(id);
    if (!objectId) return null;
    const documento = await this.collection.findOne({ _id: objectId });
    return documento ? this.paraEntidade(documento) : null;
  }

  async atualizar(id, entidade) {
    const objectId = BaseRepository.paraObjectId(id);
    if (!objectId) return null;
    const resultado = await this.collection.findOneAndUpdate(
      { _id: objectId },
      { $set: this.paraBanco(entidade.toDocument()) },
      { returnDocument: 'after' }
    );
    // driver 6.x devolve o documento; versoes antigas devolviam { value }
    const documento = resultado && resultado.value !== undefined ? resultado.value : resultado;
    return documento ? this.paraEntidade(documento) : null;
  }

  async remover(id) {
    const objectId = BaseRepository.paraObjectId(id);
    if (!objectId) return false;
    const resultado = await this.collection.deleteOne({ _id: objectId });
    return resultado.deletedCount === 1;
  }

  async contar(filtro = {}) {
    return this.collection.countDocuments(this.paraBanco(filtro));
  }

  async existe(filtro) {
    return (await this.contar(filtro)) > 0;
  }
}

module.exports = BaseRepository;
