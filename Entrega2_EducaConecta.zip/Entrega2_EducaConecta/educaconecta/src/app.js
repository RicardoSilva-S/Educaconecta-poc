const express = require('express');
const criarCrudRoutes = require('./routes/crudRoutes');
const criarAlunoRoutes = require('./routes/alunoRoutes');
const criarTurmaRoutes = require('./routes/turmaRoutes');
const criarMatriculaRoutes = require('./routes/matriculaRoutes');
const AlunoController = require('./controllers/alunoController');
const VoluntarioController = require('./controllers/voluntarioController');
const TurmaController = require('./controllers/turmaController');
const MatriculaController = require('./controllers/matriculaController');

/**
 * Monta o app Express recebendo os services ja prontos (injecao de dependencia).
 * Nos testes os services podem ser dubles; em producao vem do container.
 */
function criarApp({ alunoService, voluntarioService, turmaService, matriculaService }) {
  const app = express();
  app.use(express.json());

  app.get('/health', (req, res) => res.status(200).json({ status: 'ok', versao: '2.0.0' }));

  app.use('/alunos', criarAlunoRoutes(new AlunoController(alunoService, matriculaService)));
  app.use('/voluntarios', criarCrudRoutes(new VoluntarioController(voluntarioService)));
  app.use('/turmas', criarTurmaRoutes(new TurmaController(turmaService)));
  app.use('/matriculas', criarMatriculaRoutes(new MatriculaController(matriculaService)));

  // Erros do leitor de corpo do Express (JSON malformado, corpo grande demais...)
  // eslint-disable-next-line no-unused-vars
  app.use((erro, req, res, next) => {
    if (erro.type === 'entity.parse.failed') {
      return res.status(400).json({ erro: 'JSON invalido no corpo da requisicao.' });
    }
    if (erro.status >= 400 && erro.status < 500) {
      return res.status(erro.status).json({ erro: erro.message });
    }
    return res.status(500).json({ erro: 'Erro interno do servidor.' });
  });

  app.use((req, res) => res.status(404).json({ erro: `Rota ${req.method} ${req.path} nao encontrada.` }));

  return app;
}

module.exports = criarApp;
