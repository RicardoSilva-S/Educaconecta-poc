# Changelog

Formato baseado em [Keep a Changelog](https://keepachangelog.com/pt-BR/1.1.0/) e versionamento semântico.

## [2.0.0] — Entrega 2 (versão final)

### Adicionado
- Coleções `voluntarios`, `turmas` e `matriculas`, com relacionamentos por referência (`voluntarioId`, `alunoId`, `turmaId`).
- Objetos complexos: `endereco` (documento aninhado) e `responsaveis[]` em alunos, `horarios[]` em turmas, `frequencias[]` em matrículas.
- Matrícula de alunos em turmas com regras de vaga, turno, duplicidade e status.
- Registro de frequência e cálculo do percentual de presença.
- Relatório de vagas por turma (`GET /turmas/vagas`) e lista de alunos da turma (`GET /turmas/:id/alunos`), feitos com agregação (`$lookup`, `$filter`, `$size`).
- Índices (incluindo um único parcial para matrícula ativa) e validação `$jsonSchema` no banco.
- Integridade referencial nas remoções (aluno, turma, voluntário).
- Scripts `npm run seed` (dados de exemplo) e `npm run migrar` (converte alunos da v1).
- `docker-compose.yml` para subir o MongoDB.
- Testes de fluxo completo (banco em memória) e de integração (MongoDB real em memória).
- Documentação técnica em `docs/` e requisições prontas em `requests.http`.

### Alterado
- `Aluno`: `responsavel`/`telefone` (campos planos) viraram `responsaveis[]`; `endereco` foi incluído.
- Código comum extraído para classes base: `Entidade`, `BaseRepository`, `CrudService`, `BaseController`/`CrudController`, `DomainError`.
- Validações centralizadas em `Validador`, removendo duplicação.
- Tratamento de erros por polimorfismo (cada erro conhece o próprio status HTTP).
- `app.js` recebe todos os services; a montagem dos objetos foi para `container.js`.
- Erros de JSON malformado (400) e de corpo grande demais (413) agora são tratados, e rotas inexistentes retornam 404 em JSON.

### Testes
- De 53 para 160 testes; cobertura de 98,5% para 99,8% (linhas).

## [1.0.0] — Entrega 1

- PoC inicial: coleção única `alunos` com CRUD completo via API REST (Express + MongoDB).
- Arquitetura em camadas (model, repository, service, controller, routes) com injeção de dependência.
- 53 testes (Jest + Supertest), 98,5% de cobertura de linhas.
