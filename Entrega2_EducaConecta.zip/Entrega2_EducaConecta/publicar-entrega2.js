#!/usr/bin/env node
/**
 * Aplica a Entrega 2 no repositorio Educonecta com um historico de commits
 * incremental, e marca as versoes com as tags v1.0.0 e v2.0.0.
 *
 * Uso (Windows, Linux ou Mac; precisa de Node 18+ e Git):
 *   node publicar-entrega2.js "CAMINHO/DO/CLONE/Educonecta"
 *
 * O script NAO faz push. No final ele mostra os comandos para enviar ao GitHub.
 */
const { execFileSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const AQUI = __dirname;
const ORIGEM_V1 = path.join(AQUI, '_v1');
const ORIGEM_V2 = path.join(AQUI, 'educaconecta');
const IGNORAR = new Set(['node_modules', 'coverage', '.env', '.git']);

const repo = process.argv[2] ? path.resolve(process.argv[2]) : null;
if (!repo || !fs.existsSync(path.join(repo, '.git'))) {
  console.error('Informe o caminho do clone do repositorio. Ex.: node publicar-entrega2.js ../Educonecta');
  process.exit(1);
}

const git = (...args) => execFileSync('git', args, { cwd: repo, encoding: 'utf8' }).trim();

function listarArquivos(base, relativo = '') {
  const pasta = path.join(base, relativo);
  if (!fs.existsSync(pasta)) return [];
  if (fs.statSync(pasta).isFile()) return [relativo];
  return fs.readdirSync(pasta).flatMap((nome) =>
    IGNORAR.has(nome) ? [] : listarArquivos(base, path.join(relativo, nome))
  );
}

/** Sincroniza os caminhos informados: copia da origem e apaga do repo o que nao existe mais. */
function sincronizar(origem, caminhos) {
  for (const caminho of caminhos) {
    const novos = new Set(listarArquivos(origem, caminho));
    for (const antigo of listarArquivos(repo, caminho)) {
      if (!novos.has(antigo)) fs.rmSync(path.join(repo, antigo));
    }
    for (const arquivo of novos) {
      const destino = path.join(repo, arquivo);
      fs.mkdirSync(path.dirname(destino), { recursive: true });
      fs.copyFileSync(path.join(origem, arquivo), destino);
    }
  }
}

function commit(mensagem) {
  git('add', '-A');
  if (!git('status', '--porcelain')) {
    console.log(`  (sem alteracoes) ${mensagem}`);
    return;
  }
  git('commit', '-q', '-m', mensagem);
  console.log(`  commit: ${mensagem}`);
}

const tagExiste = (tag) => git('tag', '--list', tag) === tag;

// ---------------------------------------------------------------------------
if (git('status', '--porcelain')) {
  console.error('O repositorio tem alteracoes nao commitadas. Faca commit ou descarte antes de rodar o script.');
  process.exit(1);
}
if (tagExiste('v2.0.0')) {
  console.error('A tag v2.0.0 ja existe: a entrega 2 parece ja ter sido aplicada.');
  process.exit(1);
}
try {
  git('config', 'user.name');
} catch {
  console.error('Configure seu nome no git antes: git config --global user.name "Seu Nome"');
  process.exit(1);
}

console.log('1) Marcando a 1a entrega');
if (!tagExiste('v1.0.0')) {
  git('tag', '-a', 'v1.0.0', '-m', 'Entrega 1 - primeira versao funcional da PoC');
  console.log('  tag v1.0.0 criada no commit atual');
}

console.log('2) Extraindo o codigo da v1 do zip para a raiz (para o diff v1 -> v2 ficar visivel)');
sincronizar(ORIGEM_V1, listarArquivos(ORIGEM_V1));
fs.rmSync(path.join(repo, 'educaconecta-poc.zip'), { force: true });
commit('chore: extrai o codigo da PoC v1 do zip para a raiz do repositorio');

console.log('3) Aplicando a 2a entrega em etapas');
const etapas = [
  [
    'refactor(dominio): classes base, hierarquia de erros e validador; aluno com endereco e lista de responsaveis',
    ['src/errors', 'src/validation', 'src/models', 'tests/models', 'tests/helpers/fabricas.js'],
  ],
  [
    'feat(banco): BaseRepository e repositorios de voluntarios, turmas e matriculas com agregacoes, indices e $jsonSchema',
    ['src/repositories', 'src/db', 'tests/repositories'],
  ],
  [
    'feat(regras): services de voluntarios, turmas e matriculas (vagas, turno, frequencia, integridade)',
    ['src/services', 'tests/services'],
  ],
  [
    'feat(api): controllers e rotas genericas, novos endpoints e composition root',
    ['src/controllers', 'src/routes', 'src/app.js', 'src/container.js', 'src/server.js', 'tests/controllers'],
  ],
  [
    'test: fluxo completo com banco em memoria e integracao com MongoDB real',
    [
      'tests/fluxos',
      'tests/integration',
      'tests/helpers',
      'jest.integration.config.js',
      'package.json',
      'package-lock.json',
    ],
  ],
  [
    'chore: scripts de seed e migracao v1, docker-compose e requisicoes de exemplo',
    ['scripts', 'docker-compose.yml', 'requests.http', '.env.example', '.gitignore'],
  ],
  ['docs: documentacao tecnica completa, metodologia e changelog da v2.0.0', ['README.md', 'CHANGELOG.md', 'docs']],
];
for (const [mensagem, caminhos] of etapas) {
  sincronizar(ORIGEM_V2, caminhos);
  commit(mensagem);
}

// garante que o repo ficou identico a versao final (arquivos fora das etapas)
sincronizar(ORIGEM_V2, listarArquivos(ORIGEM_V2));
for (const arquivo of listarArquivos(repo)) {
  if (!fs.existsSync(path.join(ORIGEM_V2, arquivo))) fs.rmSync(path.join(repo, arquivo));
}
commit('chore: ajustes finais da versao 2.0.0');

console.log('4) Marcando a versao final');
git('tag', '-a', 'v2.0.0', '-m', 'Entrega 2 - versao final da PoC');
console.log('  tag v2.0.0 criada');

const ramo = git('rev-parse', '--abbrev-ref', 'HEAD');
console.log(`
Pronto! Historico local:
${git('log', '--oneline', '-12')}

Agora envie para o GitHub:
  cd "${repo}"
  git push origin ${ramo}
  git push origin v1.0.0 v2.0.0
`);
